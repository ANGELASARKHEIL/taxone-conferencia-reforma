import json
import os
import re
import time
import unicodedata
from urllib.parse import urlsplit

from playwright.sync_api import Error as PWError
from playwright.sync_api import TimeoutError as PWTimeout

import robo_taxone as rt
from robo_taxone import ErroRobo, NavegadorFechou, PrecisaJanela, passo


class ErroTela(ErroRobo):
    pass


HOST_AUTH = "auth.thomsonreuters.com"
HOST_CONTA = "account.thomsonreuters.com"
LIMITE_S = 600
LIMITE_TRANSICAO_S = 120
LIMITE_LISTA_S = 40
SEL_RADIO = "input[type=radio], [role=radio], saf-radio"
RX_BOTAO_TR = re.compile(r"Thomson\s+Reuters\s+(sign-?\s?in|log-?\s?in|iniciar\s+sess|entrar|acesso)", re.I)
RX_CONTINUAR = re.compile(r"^\s*(Continue|Continuar)\s*$", re.I)
RX_PROXIMA = re.compile(r"^\s*(Next|Próxima|Proxima|Seguinte)\s*[>›»]?\s*$", re.I)
RX_ANTERIOR = re.compile(r"^\s*[<‹«]?\s*(Previous|Anterior)\s*$", re.I)
RX_LINK_UNIVERSAL = re.compile(r"Click here to login|Clique aqui", re.I)
RX_ERRO_PLATAFORMA = "text=/error has occurred|ocorreu um erro/i"
MARCA_CLOSE = "__taxone_close__ "
JS_CLOSE = ("(() => { try { const orig = window.close; window.close = function () { try { console.debug('" + MARCA_CLOSE
            + "' + location.host + location.pathname); } catch (e) {} return orig.apply(this, arguments); }; } catch (e) {} })();")

JS_BASE = r"""
const norm = t => (t || '').replace(/\s+/g, ' ').trim();
const vis = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e);
  return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
const rot = /^(Account ID|ID da conta|ID de conta)\s*:/i;
const ehRotulo = e => rot.test(norm(e.textContent)) && norm(e.textContent).length < 80
  && ![...e.children].some(c => rot.test(norm(c.textContent)));
const contar = e => [...e.querySelectorAll('*')].filter(ehRotulo).length;
const fora = /Continue|Continuar|Page \d+ of|Items per page|Go to page|Minimum 3|Mínimo 3/i;
const ligado = x => x.tagName === 'INPUT' ? x.checked === true
  : (x.checked === true || x.getAttribute('aria-checked') === 'true' || x.hasAttribute('checked'));
const detectar = () => [...document.querySelectorAll('body *')].filter(e => vis(e) && ehRotulo(e)).map(r => {
  let c = r;
  while (c.parentElement && c.parentElement !== document.body && contar(c.parentElement) === 1
         && !fora.test(norm(c.parentElement.innerText))) c = c.parentElement;
  const radio = c.querySelector('input[type=radio], [role=radio], saf-radio');
  const interno = radio && (radio.shadowRoot || radio).querySelector('input[type=radio], [role=radio]');
  const marcado = !!radio && (ligado(radio) || (!!interno && ligado(interno)));
  const texto = norm(c.innerText);
  return {el: c, texto, radio: !!radio, marcado, universal: /Universal\s*Id/i.test(texto)};
});
"""
JS_CARTOES = "() => {" + JS_BASE + "return detectar().map(c => ({texto: c.texto, radio: c.radio, marcado: c.marcado, universal: c.universal}));}"
JS_CARTAO = "(texto) => {" + JS_BASE + "const c = detectar().find(c => c.texto === texto); return c ? c.el : null;}"
JS_DIAGNOSTICO = r"""
() => {
  const vis = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const raizes = [document];
  for (let i = 0; i < raizes.length && i < 300; i++)
    raizes[i].querySelectorAll('*').forEach(e => { if (e.shadowRoot) raizes.push(e.shadowRoot); });
  const elementos = [], custom = {};
  raizes.forEach((raiz, i) => {
    raiz.querySelectorAll('*').forEach(e => { const t = e.tagName.toLowerCase(); if (t.includes('-')) custom[t] = (custom[t] || 0) + 1; });
    raiz.querySelectorAll('input, button, a, select, h1, h2, label, [role=button], [role=radio], [role=alert]').forEach(e => {
      if (!vis(e) || elementos.length >= 120) return;
      elementos.push({tag: e.tagName.toLowerCase(), shadow: i > 0, id: e.id || '', name: e.getAttribute('name') || '',
                      tipo: e.getAttribute('type') || '', papel: e.getAttribute('role') || '',
                      texto: (e.innerText || '').trim().replace(/\s+/g, ' ').slice(0, 90)});
    });
  });
  return {raizes_shadow: raizes.length - 1, custom_elements: custom, elementos,
          corpo: (document.body ? document.body.innerText : '').replace(/\s+/g, ' ').trim().slice(0, 1500)};
}
"""


def _log(log, msg):
    rt._log(log, msg)


def sem_acento(texto):
    return "".join(c for c in unicodedata.normalize("NFKD", texto or "") if not unicodedata.combining(c)).lower()


def combina(termo, texto):
    alvo = sem_acento(texto)
    termos = [t for t in sem_acento(termo).split() if t]
    if not termos:
        return False
    for t in termos:
        if len(t) < 4:
            if not re.search(rf"(?<![a-z0-9]){re.escape(t)}(?![a-z0-9])", alvo):
                return False
        elif t not in alvo:
            return False
    return True


def id_conta(texto):
    m = re.search(r"(?:Account ID|ID da conta|ID de conta)\s*:\s*([A-Za-z0-9]+)", texto or "", re.I)
    return m.group(1) if m else ""


def resumo_conta(texto):
    t = re.sub(r"\b(Active|Ativo|Ativa)\s*(?=Account ID|ID da conta|ID de conta)", "", texto or "")
    t = re.sub(r"\s*Use Universal Id login.*$", " (Universal ID)", t, flags=re.I)
    t = re.sub(r"(?:Account ID|ID da conta|ID de conta)\s*:\s*(\S+)", r"\1 -", t, count=1, flags=re.I)
    return re.sub(r"\s+", " ", t).strip()[:110]


def lista_contas(contas, limite=12):
    return "; ".join(resumo_conta(c["texto"]) for c in contas[:limite]) + (" ..." if len(contas) > limite else "")


def estado(pg, host_os):
    partes = urlsplit(pg.url)
    host, caminho = partes.netloc.lower(), partes.path.lower()
    if host == host_os:
        if "/platform/" in caminho:
            return "home"
        return "onesource" if "/auth/signin" in caminho else "transicao"
    if host == HOST_AUTH:
        if "/u/login/identifier" in caminho:
            return "identificador"
        if "/u/login/password" in caminho and "/password-reset" not in caminho:
            return "senha"
        return "interativo" if caminho.startswith("/u/") else "transicao"
    if host == HOST_CONTA:
        return "conta" if "product-options" in caminho else "transicao"
    if partes.scheme in ("http", "https") and host:
        return "externo"
    return "transicao"


def _botao_tr(pg):
    for loc in (pg.get_by_text(RX_BOTAO_TR), pg.get_by_role("button", name=RX_BOTAO_TR)):
        loc = loc.locator("visible=true")
        if loc.count():
            return loc.first
    return None


def _erro_visivel(pg):
    try:
        loc = pg.locator("[id^=error-element], .ulp-input-error-message, #prompt-alert, .ulp-error-info, [role=alert]").locator("visible=true")
        if loc.count():
            return re.sub(r"\s+", " ", " ".join(t.strip() for t in loc.all_inner_texts() if t.strip()))[:200]
    except PWError:
        pass
    return ""


def _enviar(pg):
    botoes = pg.locator("button[type=submit]").locator("visible=true")
    principal = botoes.locator("[data-action-button-primary=true]")
    alvo = principal if principal.count() else botoes
    if alvo.count():
        alvo.first.click(timeout=15000)
    else:
        pg.keyboard.press("Enter")


def _esperar_pagina(pg, url_antes, segundos, com_erro=False):
    t0 = time.time()
    while time.time() - t0 < segundos:
        if pg.url != url_antes:
            pg.wait_for_timeout(800)
            return True
        if com_erro and _erro_visivel(pg):
            return False
        pg.wait_for_timeout(500)
    return False


def _alertar(pg):
    try:
        pg.bring_to_front()
    except PWError:
        pass
    try:
        import winsound
        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
    except Exception:
        pass


def _cartoes(pg):
    try:
        return pg.evaluate(JS_CARTOES)
    except PWError:
        return []


def _elemento_cartao(pg, texto):
    try:
        return pg.evaluate_handle(JS_CARTAO, texto).as_element()
    except PWError:
        return None


def _mudar_pagina(pg, rx):
    ctl = pg.get_by_role("button", name=rx).locator("visible=true")
    if not ctl.count():
        ctl = pg.get_by_text(rx).locator("visible=true")
    if not ctl.count():
        return False
    alvo = ctl.first
    if alvo.evaluate("""e => { const b = e.closest('button, a, [role=button]') || e;
        return b.disabled === true || b.getAttribute('aria-disabled') === 'true' || /disabled/i.test(b.className || ''); }"""):
        return False
    antes = [c["texto"] for c in _cartoes(pg)]
    alvo.click(timeout=10000)
    t0 = time.time()
    while time.time() - t0 < 10:
        pg.wait_for_timeout(500)
        if [c["texto"] for c in _cartoes(pg)] != antes:
            return True
    return False


def _marcar(pg, texto):
    cartao = _elemento_cartao(pg, texto)
    if cartao is None:
        return False
    cartao.scroll_into_view_if_needed(timeout=5000)
    for tentativa in range(2):
        radio = cartao.query_selector(SEL_RADIO)
        try:
            (radio if radio and tentativa == 0 else cartao).click(force=True, timeout=5000)
        except PWError:
            pass
        pg.wait_for_timeout(700)
        atual = next((c for c in _cartoes(pg) if c["texto"] == texto), None)
        if atual and (atual["marcado"] or not atual["radio"]):
            return True
        cartao = _elemento_cartao(pg, texto) or cartao
    return False


def escolher_conta(pg, cliente, log):
    t0 = time.time()
    while time.time() - t0 < LIMITE_LISTA_S and not _cartoes(pg):
        pg.wait_for_timeout(1000)
    if not _cartoes(pg):
        raise ErroTela("A lista de contas (clientes) da Thomson Reuters não carregou ou está em um formato que o robô não reconhece.")
    pg.wait_for_timeout(1500)
    vistas, achadas, pagina = [], [], 1
    while True:
        for c in _cartoes(pg):
            conta = {"pagina": pagina, "texto": c["texto"], "id": id_conta(c["texto"]), "universal": c["universal"]}
            vistas.append(conta)
            if cliente and combina(cliente, c["texto"]):
                achadas.append(conta)
        if pagina >= 60 or not _mudar_pagina(pg, RX_PROXIMA):
            break
        pagina += 1
    if not cliente:
        if len(vistas) != 1:
            raise ErroRobo("Informe o cliente (conta) a escolher. Contas encontradas: " + lista_contas(vistas))
        achadas = vistas
    if len(achadas) > 1:
        exatas = [a for a in achadas if a["id"] and a["id"].lower() == cliente.strip().lower()]
        achadas = exatas if len(exatas) == 1 else achadas
    if not achadas:
        raise ErroRobo(f"Não achei o cliente '{cliente}' na lista de contas da Thomson Reuters. Contas encontradas: "
                       + lista_contas(vistas))
    if len(achadas) > 1:
        raise ErroRobo(f"Mais de uma conta combina com '{cliente}': {lista_contas(achadas, 8)}. "
                       "Informe um nome mais específico ou o ID da conta (ex.: QRE).")
    alvo = achadas[0]
    for _ in range(pagina - alvo["pagina"]):
        _mudar_pagina(pg, RX_ANTERIOR)
    nome = resumo_conta(alvo["texto"])
    cartao = _elemento_cartao(pg, alvo["texto"])
    if cartao is None:
        raise ErroTela(f"Não consegui voltar à conta '{nome}' na lista da Thomson Reuters.")
    cartao.scroll_into_view_if_needed(timeout=5000)
    if alvo["universal"]:
        candidatos = cartao.query_selector_all("a, button, [role=link], [role=button], saf-link, saf-anchor, saf-button")
        link = next((l for l in candidatos if RX_LINK_UNIVERSAL.search(l.inner_text() or "")), None)
        link = link or cartao.query_selector("text=/Click here to login|Clique aqui/i")
        if link is None:
            raise ErroTela(f"A conta '{nome}' usa Universal ID, mas não achei o link 'Click here to login'.")
        _log(log, f"A conta '{nome}' usa Universal ID: abrindo pelo link 'Click here to login'...")
        host_os = urlsplit(rt.base_url()).netloc.lower()
        try:
            with pg.context.expect_page(timeout=8000) as nova:
                link.click(timeout=10000)
            outra = nova.value
            t1 = time.time()
            while time.time() - t1 < 90 and not (urlsplit(outra.url).netloc.lower() == host_os and "/platform/" in outra.url):
                outra.wait_for_timeout(1000)
            outra.close()
            pg.goto(rt.base_url() + "/platform/home", wait_until="domcontentloaded", timeout=90000)
        except PWTimeout:
            pass
        return ""
    if not _marcar(pg, alvo["texto"]):
        raise ErroTela(f"Não consegui marcar a conta '{nome}' na lista da Thomson Reuters.")
    _log(log, f"Cliente escolhido: {nome}")
    botao = pg.get_by_role("button", name=RX_CONTINUAR).locator("visible=true")
    if not botao.count():
        botao = pg.get_by_text(RX_CONTINUAR).locator("visible=true")
    if not botao.count():
        raise ErroTela("Não achei o botão Continue na lista de contas da Thomson Reuters.")
    botao.first.scroll_into_view_if_needed(timeout=5000)
    botao.first.click(timeout=10000)
    return alvo["id"]


def _pasta_diagnostico():
    return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TaxOneConferencia", "diagnostico")


def _diagnostico(pg):
    try:
        pasta = _pasta_diagnostico()
        os.makedirs(pasta, exist_ok=True)
        base = os.path.join(pasta, "login_ciam_" + time.strftime("%Y%m%d_%H%M%S"))
        partes = urlsplit(pg.url)
        info = {"url": f"{partes.scheme}://{partes.netloc}{partes.path}", "titulo": (pg.title() or "")[:120]}
        info.update(pg.evaluate(JS_DIAGNOSTICO))
        info["contas"] = [c["texto"] for c in _cartoes(pg)]
        with open(base + ".json", "w", encoding="utf-8") as f:
            json.dump(info, f, ensure_ascii=False, indent=1)
        pg.screenshot(path=base + ".png", timeout=15000)
        _podar(pasta)
        return base + ".json"
    except Exception:
        return None


def _podar(pasta):
    try:
        antigos = sorted((os.path.join(pasta, n) for n in os.listdir(pasta) if n.startswith("login_ciam_")), key=os.path.getmtime)
        for arq in antigos[:-24]:
            os.remove(arq)
    except Exception:
        pass


class Eventos:
    def __init__(self):
        self.t0 = time.time()
        self.itens = []
        self.ultimo = ""
        self.destino = ""

    def add(self, tipo, detalhe=""):
        self.itens.append({"s": round(time.time() - self.t0, 1), "evento": tipo, "detalhe": str(detalhe)[:160]})
        del self.itens[:-300]


def _local(url):
    p = urlsplit(url or "")
    if not p.netloc:
        return (url or "")[:40]
    partes = ["*" if re.fullmatch(r"[A-Za-z0-9_-]{8,}", s) and re.search(r"\d", s) else s for s in p.path.split("/")]
    return (p.netloc + "/".join(partes))[:140]


def _seguro(fn):
    def interno(*a, **k):
        try:
            fn(*a, **k)
        except Exception:
            pass
    return interno


def _observar(pg, ev):
    ctx = pg.context
    rotulos = {}

    def rotulo(pagina):
        return rotulos.setdefault(id(pagina), f"aba{len(rotulos) + 1}")

    def navegou(frame):
        if frame == frame.page.main_frame:
            ev.ultimo = _local(frame.url)
            ev.add("navegou", f"{rotulo(frame.page)}: {ev.ultimo}")

    def registrar(pagina):
        pagina.on("framenavigated", _seguro(navegou))
        pagina.on("close", _seguro(lambda p: ev.add("aba fechou", f"{rotulo(p)}: {_local(p.url)}")))
        pagina.on("crash", _seguro(lambda p: ev.add("aba travou", rotulo(p))))
        pagina.on("download", _seguro(lambda d: ev.add("download", f"{rotulo(d.page)}: {d.suggested_filename}")))

    def nova(pagina):
        ev.add("aba nova", f"{rotulo(pagina)}: {_local(pagina.url)}")
        registrar(pagina)

    def pedido(r):
        if r.is_navigation_request():
            ev.destino = _local(r.url)
            ev.add("pedido", f"{r.method} {ev.destino}")

    def resposta(r):
        if r.request.is_navigation_request():
            ev.add("resposta", f"{r.status} {r.request.method} {_local(r.url)}")

    def falhou(r):
        if r.is_navigation_request():
            ev.add("navegacao falhou", f"{r.failure} {_local(r.url)}")

    for pagina in list(ctx.pages):
        rotulo(pagina)
        registrar(pagina)
    ctx.on("page", _seguro(nova))
    ctx.on("request", _seguro(pedido))
    ctx.on("response", _seguro(resposta))
    ctx.on("requestfailed", _seguro(falhou))
    ctx.on("console", _seguro(lambda m: m.text.startswith(MARCA_CLOSE) and ev.add("pagina chamou window.close()", m.text[len(MARCA_CLOSE):])))
    ctx.on("close", _seguro(lambda c: ev.add("contexto fechou")))
    if ctx.browser:
        ctx.browser.on("disconnected", _seguro(lambda b: ev.add("navegador encerrou")))
    try:
        ctx.add_init_script(JS_CLOSE)
    except PWError:
        pass


def _janelas():
    achadas = {}
    try:
        import win32gui

        def cb(h, _):
            try:
                if win32gui.IsWindowVisible(h) and win32gui.GetClassName(h) in ("Chrome_WidgetWin_1", "IEFrame"):
                    titulo = win32gui.GetWindowText(h)
                    if titulo:
                        achadas[h] = f"{win32gui.GetClassName(h)}: {titulo[:70]}"
            except Exception:
                pass
        win32gui.EnumWindows(cb, None)
    except Exception:
        pass
    return achadas


def _comparar_janelas(antes, agora0, agora1):
    a, x, y = set(antes.values()), set(agora0.values()), set(agora1.values())
    return {"sumiram_antes_de_o_robo_perceber": sorted(a - x)[:8], "sumiram_nos_2s_seguintes": sorted(x - y)[:8],
            "novas_ate_o_fim": sorted(y - a)[:8]}


def _situacao(pg):
    info = {}
    try:
        b = pg.context.browser
        info["navegador_conectado"] = bool(b and b.is_connected())
        if b and b.is_connected():
            info["versao"] = b.version
    except Exception:
        pass
    try:
        info["outras_abas_abertas"] = [_local(p.url) for p in pg.context.pages if not p.is_closed()]
    except Exception:
        info["outras_abas_abertas"] = "indisponivel"
    return info


def _salvar_eventos(ev, extra=None):
    try:
        pasta = _pasta_diagnostico()
        os.makedirs(pasta, exist_ok=True)
        base = os.path.join(pasta, "login_ciam_eventos_" + time.strftime("%Y%m%d_%H%M%S"))
        dados = {"navegador": getattr(rt._cfg, "canal_usado", ""), "escolha": rt._cfg.acesso.get("navegador", ""), **(extra or {}),
                 "eventos": ev.itens}
        with open(base + ".json", "w", encoding="utf-8") as f:
            json.dump(dados, f, ensure_ascii=False, indent=1)
        _podar(pasta)
        return base + ".json"
    except Exception:
        return None


def entrar(pg, email, senha, log):
    cliente = rt._cfg.acesso.get("cliente", "")
    host_os = urlsplit(rt.base_url()).netloc.lower()
    cont = {"tr": 0, "email": 0, "senha": 0, "conta": 0, "troca": 0}
    est = {"via_conta": False, "id_conta": "", "manual": False, "aguardo": 0.0, "aviso": 0.0, "sem_botao": 0.0, "transicao": 0.0,
           "situacao": "", "janelas": _janelas()}
    inicio = time.time()
    ev = Eventos()
    try:
        _observar(pg, ev)
    except Exception:
        pass

    def fechou():
        ev.add("robo percebeu o fechamento")
        agora0 = _janelas()
        time.sleep(2.5)
        est["diag_janelas"] = _comparar_janelas(est["janelas"], agora0, _janelas())
        canal = getattr(rt._cfg, "canal_usado", "") or "navegador"
        visto = ev.ultimo or _local(pg.url) or "nenhum"
        indo = f"; tentava abrir: {ev.destino}" if ev.destino and ev.destino != visto else ""
        return NavegadorFechou(f"A janela do {canal} do robô fechou durante o login Thomson Reuters (último endereço visto: {visto}{indo}).")

    def substituta():
        fim = time.time() + 3
        while True:
            try:
                vivas = [p for p in pg.context.pages if not p.is_closed() and urlsplit(p.url).scheme in ("http", "https")]
            except Exception:
                vivas = []
            if vivas or time.time() > fim:
                break
            time.sleep(0.5)
        if not vivas:
            return None
        ev.add("robo seguiu na aba que ficou aberta", _local(vivas[-1].url))
        _log(log, "A aba do login foi fechada pelo próprio site; o robô segue na aba que ficou aberta.")
        est["situacao"], est["janelas"] = "", _janelas()
        return vivas[-1]

    def aguardar(inicial, lembrete):
        if not rt._navegador_visivel():
            raise PrecisaJanela("O acesso salvo não vale mais e o login precisa de você (ID, senha e PingID).")
        agora = time.time()
        if not est["aguardo"]:
            _log(log, inicial)
            _alertar(pg)
            est["aguardo"] = est["aviso"] = agora
        elif agora - est["aviso"] > 60:
            faltam = max(1, int((LIMITE_S - (agora - inicio)) / 60))
            _log(log, f"{lembrete} faltam cerca de {faltam} min.")
            est["aviso"] = agora
        pg.wait_for_timeout(1500)
        return False

    def outra_aba_pronta():
        for outra in pg.context.pages:
            if outra is not pg and urlsplit(outra.url).netloc.lower() == host_os and "/platform/" in outra.url:
                try:
                    outra.close()
                except PWError:
                    pass
                pg.goto(rt.base_url() + "/platform/home", wait_until="domcontentloaded", timeout=90000)
                return True
        return False

    def agir(situacao):
        if situacao == "transicao":
            est["transicao"] = est["transicao"] or time.time()
            if time.time() - est["transicao"] > LIMITE_TRANSICAO_S:
                p = urlsplit(pg.url)
                raise ErroRobo(f"O login Thomson Reuters ficou parado em {p.netloc}{p.path}.")
        else:
            est["transicao"] = 0.0
        if est["manual"] and situacao == "conta":
            if outra_aba_pronta():
                return False
            alvo = f"o cliente '{cliente}'" if cliente else "o cliente"
            return aguardar(f"Escolha {alvo} na janela do robô e clique em Continue (conta com Universal ID: use o link "
                            "'Click here to login'). Depois disso o robô segue sozinho.",
                            "Ainda aguardando você escolher o cliente na janela do robô...")
        if situacao in ("externo", "interativo"):
            return aguardar("Aguardando você concluir o login corporativo (ID, senha e PingID) na janela do navegador do robô...",
                            "Ainda aguardando o login corporativo (SSO/PingID) na janela do robô...")
        est["aguardo"] = 0.0
        if situacao in ("onesource", "transicao") and urlsplit(pg.url).netloc.lower() == host_os:
            falha = pg.locator(RX_ERRO_PLATAFORMA).first
            if falha.count() and falha.is_visible():
                raise ErroRobo("O ONESOURCE respondeu \"An error has occurred\" no login. É instabilidade da plataforma "
                               "(veja o aviso na tela de login). Tente novamente em alguns minutos.")
        if situacao == "home":
            pg.wait_for_timeout(4000)
            if estado(pg, host_os) != "home":
                return False
            ativo = rt.info_ambiente(pg).get("ambiente_completo", "") if (cliente or est["id_conta"]) else ""
            if est["via_conta"]:
                achado = re.search(r"\((\w+)\)\s*$", ativo)
                if est["id_conta"] and achado and achado.group(1).lower() != est["id_conta"].lower():
                    raise ErroRobo(f"O robô escolheu a conta {est['id_conta']}, mas o ONESOURCE abriu '{ativo}'. "
                                   "Rode de novo ou escolha a conta à mão na janela do robô.")
            elif ativo and not combina(cliente, ativo):
                if cont["troca"]:
                    raise ErroRobo(f"O ONESOURCE entrou no cliente '{ativo}', diferente do informado ('{cliente}'). "
                                   "Informe o cliente como aparece no topo do ONESOURCE (nome ou ID da conta). "
                                   "Se o cliente informado está certo, clique em 'Esquecer acessos salvos' e rode de novo.")
                cont["troca"] += 1
                _log(log, f"O acesso salvo era de outro cliente ({ativo}); refazendo a escolha de '{cliente}'...")
                rt._limpar_cookies(pg)
                pg.goto(rt.base_url() + "/auth/signin", wait_until="domcontentloaded", timeout=90000)
                return False
            passo(pg, "Login realizado – portal ONESOURCE (Thomson Reuters sign-in)")
            rt._cfg.login_ok = True
            rt._salvar_acesso(pg.context)
            if rt._cfg.acesso.get("troca"):
                rt.salvar_preferencia_navegador(rt._cfg.acesso.get("navegador"))
                _log(log, f"Login concluído no {rt._cfg.canal_usado}: o robô vai usar esse navegador nas próximas execuções.")
            return True
        if situacao == "onesource":
            botao = _botao_tr(pg)
            if botao is None:
                est["sem_botao"] = est["sem_botao"] or time.time()
                if time.time() - est["sem_botao"] > 45:
                    raise ErroRobo("Não achei o botão 'Thomson Reuters sign-in' na tela de login do ONESOURCE. "
                                   "Use o login clássico (usuário e senha).")
                pg.wait_for_timeout(1000)
                return False
            est["sem_botao"] = 0.0
            if cont["tr"] >= 3:
                raise ErroRobo("O botão 'Thomson Reuters sign-in' não levou à tela de e-mail da Thomson Reuters.")
            if cont["tr"] == 0:
                passo(pg, f"Tela de login do ONESOURCE ({host_os}) – opção Thomson Reuters sign-in")
            cont["tr"] += 1
            _log(log, "Clicando em Thomson Reuters sign-in...")
            url0 = pg.url
            botao.click(timeout=15000)
            _esperar_pagina(pg, url0, 30)
            return False
        if situacao == "identificador":
            if cont["email"] >= 2:
                raise ErroRobo("O login Thomson Reuters voltou para a tela de e-mail depois de informado. " + _erro_visivel(pg))
            campo = pg.locator("input#username, input[name=username], input[type=email]").locator("visible=true").first
            campo.wait_for(timeout=20000)
            campo.fill(email)
            passo(pg, "Login Thomson Reuters – e-mail informado")
            cont["email"] += 1
            url0 = pg.url
            _enviar(pg)
            _esperar_pagina(pg, url0, 30, com_erro=True)
            if estado(pg, host_os) == "identificador":
                erro = _erro_visivel(pg)
                raise ErroRobo("O login Thomson Reuters não aceitou o e-mail informado" + (f": {erro}" if erro else "."))
            return False
        if situacao == "senha":
            if not senha:
                raise ErroRobo("Este e-mail pede senha (não usa o SSO da Thomson Reuters). "
                               "Informe a senha cadastrada para entrar no TAX ONE do cliente.")
            if cont["senha"] >= 1:
                erro = _erro_visivel(pg)
                raise ErroRobo("O login Thomson Reuters voltou para a tela de senha: e-mail ou senha inválidos"
                               + (f" ({erro})" if erro else "") + ". O robô não repete a senha, para não bloquear a conta.")
            campo = pg.locator("input#password, input[name=password], input[type=password]").locator("visible=true").first
            campo.wait_for(timeout=20000)
            campo.fill(senha)
            passo(pg, "Login Thomson Reuters – senha informada (mascarada)")
            cont["senha"] += 1
            url0 = pg.url
            _enviar(pg)
            _esperar_pagina(pg, url0, 40, com_erro=True)
            if estado(pg, host_os) == "senha":
                erro = _erro_visivel(pg)
                raise ErroRobo("O login Thomson Reuters não aceitou o e-mail/senha" + (f": {erro}" if erro else "."))
            return False
        if situacao == "conta":
            if cont["conta"] >= 2:
                raise ErroRobo("A lista de contas da Thomson Reuters voltou depois do Continue.")
            cont["conta"] += 1
            est["via_conta"] = True
            url0 = pg.url
            try:
                est["id_conta"] = escolher_conta(pg, cliente, log)
                if not _esperar_pagina(pg, url0, 60):
                    raise ErroTela("O botão Continue da lista de contas não levou ao ONESOURCE.")
            except (ErroTela, PWError) as ex:
                if pg.is_closed():
                    return False
                motivo = str(ex) if isinstance(ex, ErroTela) else str(ex).splitlines()[0][:160]
                est["manual"], est["id_conta"] = True, ""
                _log(log, f"O robô não conseguiu escolher o cliente sozinho. {motivo}")
                arq = _diagnostico(pg)
                if arq:
                    _log(log, f"Diagnóstico da tela salvo em {arq} (junto com um .png); se precisar de ajuda, envie os dois arquivos.")
            return False
        pg.wait_for_timeout(1000)
        return False

    if getattr(rt._cfg, "acesso_carregado", False):
        _log(log, "Usando o acesso salvo neste computador (evita pedir o PingID de novo)...")
    _log(log, "Abrindo o login do ONESOURCE (Thomson Reuters sign-in)...")
    try:
        for tentativa in range(3):
            try:
                pg.goto(rt.base_url() + "/auth/signin", wait_until="domcontentloaded", timeout=90000)
                break
            except PWError:
                if tentativa == 2:
                    raise ErroRobo("A página de login do ONESOURCE não abriu (verifique a conexão/VPN/ZScaler).")
                _log(log, f"Login do ONESOURCE não carregou (tentativa {tentativa + 1}/3), tentando de novo...")
        falhas = 0
        while time.time() - inicio < LIMITE_S:
            if pg.is_closed():
                nova = substituta()
                if nova is None:
                    raise fechou()
                pg = nova
                continue
            try:
                situacao = estado(pg, host_os)
                if situacao != est["situacao"]:
                    est["situacao"] = situacao
                    est["janelas"] = _janelas()
                    ev.add("estado", f"{situacao} ({_local(pg.url)})")
                if agir(situacao):
                    return pg
                falhas = 0
            except PWError as ex:
                if pg.is_closed():
                    continue
                falhas += 1
                if falhas >= 8:
                    raise ErroRobo(f"Falha no login Thomson Reuters: {str(ex).splitlines()[0][:200]}")
                pg.wait_for_timeout(1000)
        raise ErroRobo("O login Thomson Reuters não foi concluído em 10 minutos (e-mail, SSO/PingID, escolha do cliente). "
                       "Rode de novo e conclua o PingID na janela do robô.")
    except ErroRobo as ex:
        if isinstance(ex, PrecisaJanela):
            raise
        extra = {}
        if isinstance(ex, NavegadorFechou):
            extra = {**_situacao(pg), "janelas": est.get("diag_janelas")}
        else:
            arq = _diagnostico(pg)
            if arq:
                _log(log, f"Diagnóstico do login salvo em {arq}")
        ev.add("erro", str(ex))
        arq_ev = _salvar_eventos(ev, extra)
        if arq_ev:
            _log(log, f"Registro do que aconteceu no navegador salvo em {arq_ev}")
        raise
