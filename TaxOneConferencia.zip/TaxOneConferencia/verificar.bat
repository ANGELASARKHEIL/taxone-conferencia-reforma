@echo off
cd /d "%~dp0"
title Conferir o ambiente - TAX ONE Conferencia da Reforma
call "%~dp0achar_python.bat"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0verificar_ambiente.ps1" -Python "%PY%" -Detalhado
pause
