@echo off
setlocal
cd /d "%~dp0"
title TAX ONE Conferencia da Reforma - Instalacao
set "PYVER=3.13.17"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"

echo.
echo  TAX ONE Conferencia da Reforma - instalacao
echo  Nao feche esta janela. Pode levar alguns minutos.
echo.

call "%~dp0achar_python.bat"
if defined PY (
  echo [1/4] Python encontrado.
  goto com_python
)
echo [1/4] Instalando o Python %PYVER% ^(so para o seu usuario, sem administrador^)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar_python.ps1" -Versao %PYVER%
call "%~dp0achar_python.bat"
if defined PY goto com_python

echo.
echo Nao foi possivel instalar o Python automaticamente.
echo Instale-o manualmente, marcando "Add python.exe to PATH", e abra este instalador de novo.
start "" "%PYURL%"
pause
exit /b 1

:com_python
echo [2/4] Instalando os componentes da ferramenta...
"%PY%" -m pip install --user --disable-pip-version-check --no-warn-script-location -q -r requirements.txt
if errorlevel 1 (
  echo.
  echo Falha ao instalar os componentes. Confira se o ZScaler esta autenticado e abra este instalador de novo.
  pause
  exit /b 1
)
echo [3/4] Criando o atalho e ligando a ferramenta...
set "TAXONE_PYTHON=%PY%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0criar_atalhos.ps1"
powershell -NoProfile -Command "for($i=0;$i -lt 60;$i++){ try{ $c=New-Object Net.Sockets.TcpClient('127.0.0.1',5055); $c.Close(); exit 0 }catch{}; Start-Sleep 1 }; exit 1"
echo [4/4] Conferindo o ambiente...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0verificar_ambiente.ps1" -Python "%PY%"
set "RESULTADO=%errorlevel%"
echo.
echo Pronto! A ferramenta vai abrir no navegador.
start "" http://127.0.0.1:5055
if "%RESULTADO%"=="0" (
  timeout /t 8 >nul
) else (
  echo Ha itens para conferir acima.
  pause
)
