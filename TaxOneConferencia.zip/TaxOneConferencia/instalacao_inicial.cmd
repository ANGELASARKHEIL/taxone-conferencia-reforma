@echo off
setlocal
title Instalador - TAX ONE Conferencia da Reforma
set "DESTINO=%USERPROFILE%\TaxOneConferencia"
if defined TAXONE_DESTINO set "DESTINO=%TAXONE_DESTINO%"
echo.
echo Instalando a ferramenta em: %DESTINO%
echo ^(os resultados das execucoes ficam em %DESTINO%\execucoes^)
if not exist "%DESTINO%" mkdir "%DESTINO%"
robocopy "%~dp0." "%DESTINO%" /E /XF modelos__*.docx instalacao_inicial.cmd /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo.
  echo Nao foi possivel copiar os arquivos para %DESTINO%.
  pause
  exit /b 1
)
if not exist "%DESTINO%\modelos" mkdir "%DESTINO%\modelos"
copy /y "%~dp0modelos__Plano_de_Testes_modelo.docx" "%DESTINO%\modelos\Plano_de_Testes_modelo.docx" >nul
cd /d "%DESTINO%"
call "%DESTINO%\instalar.bat"
