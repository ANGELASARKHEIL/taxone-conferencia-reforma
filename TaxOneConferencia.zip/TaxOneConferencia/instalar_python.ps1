param(
  [string]$Versao = "3.13.17",
  [switch]$SomenteVerificar
)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$url = "https://www.python.org/ftp/python/$Versao/python-$Versao-amd64.exe"
$exe = Join-Path $env:TEMP "python-$Versao-amd64.exe"
$pasta = Join-Path $env:LOCALAPPDATA "Programs\Python\Python313"
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Write-Host "Baixando o Python $Versao de python.org (cerca de 27 MB)..."
  Invoke-WebRequest -Uri $url -OutFile $exe -UseBasicParsing
  $ass = Get-AuthenticodeSignature -FilePath $exe
  if ($ass.Status -ne "Valid" -or $ass.SignerCertificate.Subject -notmatch "Python Software Foundation") {
    throw "A assinatura digital do instalador nao confere com a Python Software Foundation."
  }
  Write-Host "Assinatura digital conferida: Python Software Foundation."
  if ($SomenteVerificar) {
    Write-Host "Modo de verificacao: nada foi instalado."
    exit 0
  }
  Write-Host "Instalando somente para o seu usuario, sem administrador (pode levar 1 a 2 minutos)..."
  $parametros = "/quiet", "InstallAllUsers=0", "PrependPath=1", "Include_launcher=0", "Include_test=0", "Include_doc=0", "Shortcuts=0", "TargetDir=`"$pasta`""
  $p = Start-Process -FilePath $exe -ArgumentList $parametros -Wait -PassThru
  if ($p.ExitCode -ne 0) { throw "O instalador do Python terminou com o codigo $($p.ExitCode)." }
  if (-not (Test-Path (Join-Path $pasta "python.exe"))) { throw "python.exe nao foi encontrado em $pasta." }
  Write-Host "Python $Versao instalado em $pasta."
} catch {
  Write-Host "Falha: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
} finally {
  Remove-Item $exe -Force -ErrorAction SilentlyContinue
}
