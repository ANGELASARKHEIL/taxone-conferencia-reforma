$ErrorActionPreference = "Stop"
$pasta = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = if ($env:TAXONE_PYTHON -and (Test-Path $env:TAXONE_PYTHON)) { $env:TAXONE_PYTHON } else { (Get-Command python -ErrorAction Stop).Source }
$pythonw = Join-Path (Split-Path $python) "pythonw.exe"
if (-not (Test-Path $pythonw)) { $pythonw = $python }

foreach ($c in @(Get-NetTCPConnection -LocalPort 5055 -State Listen -ErrorAction SilentlyContinue)) {
    $proc = Get-Process -Id $c.OwningProcess -ErrorAction SilentlyContinue
    if ($proc -and $proc.ProcessName -match '^pythonw?$') { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
}
Start-Sleep -Seconds 1

$ws = New-Object -ComObject WScript.Shell
$inicializar = [Environment]::GetFolderPath("Startup")
$lnk = $ws.CreateShortcut((Join-Path $inicializar "Conferencia Reforma Tributaria TAX ONE.lnk"))
$lnk.TargetPath = $pythonw
$lnk.Arguments = "app.py --sem-navegador"
$lnk.WorkingDirectory = $pasta
$lnk.WindowStyle = 7
$lnk.Description = "Inicia o site da Conferencia Reforma Tributaria (http://127.0.0.1:5055)"
$lnk.Save()

$area = [Environment]::GetFolderPath("Desktop")
$url = "[InternetShortcut]`r`nURL=http://127.0.0.1:5055/`r`n"
Set-Content -Path (Join-Path $area "Conferencia Reforma Tributaria TAX ONE.url") -Value $url -Encoding ASCII

$rodando = Get-NetTCPConnection -LocalPort 5055 -State Listen -ErrorAction SilentlyContinue
if (-not $rodando) {
    Start-Process -FilePath $pythonw -ArgumentList "app.py", "--sem-navegador" -WorkingDirectory $pasta -WindowStyle Hidden
    Start-Sleep -Seconds 6
}
Write-Host "Atalho criado na Area de Trabalho e inicializacao automatica configurada."
