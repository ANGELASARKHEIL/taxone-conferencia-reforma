param(
    [string]$Inicializar = "",
    [string]$MenuIniciar = "",
    [string]$AreaTrabalho = "",
    [switch]$SemLigar
)
$ErrorActionPreference = "Stop"
$pasta = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = if ($env:TAXONE_PYTHON -and (Test-Path $env:TAXONE_PYTHON)) { $env:TAXONE_PYTHON } else { (Get-Command python -ErrorAction Stop).Source }
$pythonw = Join-Path (Split-Path $python) "pythonw.exe"
if (-not (Test-Path $pythonw)) { $pythonw = $python }
if (-not $Inicializar) { $Inicializar = [Environment]::GetFolderPath("Startup") }
if (-not $MenuIniciar) { $MenuIniciar = [Environment]::GetFolderPath("Programs") }
if (-not $AreaTrabalho) { $AreaTrabalho = [Environment]::GetFolderPath("Desktop") }
$nome = "Conferencia Reforma Tributaria TAX ONE"
$abrirpyw = Join-Path $pasta "abrir.pyw"

if (-not $SemLigar) {
    foreach ($c in @(Get-NetTCPConnection -LocalPort 5055 -State Listen -ErrorAction SilentlyContinue)) {
        $proc = Get-Process -Id $c.OwningProcess -ErrorAction SilentlyContinue
        if ($proc -and $proc.ProcessName -match '^pythonw?$') { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    }
    Start-Sleep -Seconds 1
}

$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut((Join-Path $Inicializar "$nome.lnk"))
$lnk.TargetPath = $pythonw
$lnk.Arguments = '"' + $abrirpyw + '" --sem-navegador'
$lnk.WorkingDirectory = $pasta
$lnk.WindowStyle = 7
$lnk.Description = "Liga a ferramenta com o Windows (http://127.0.0.1:5055)"
$lnk.Save()

foreach ($destino in @($MenuIniciar, $AreaTrabalho)) {
    $abrir = $ws.CreateShortcut((Join-Path $destino "$nome.lnk"))
    $abrir.TargetPath = $pythonw
    $abrir.Arguments = '"' + $abrirpyw + '"'
    $abrir.WorkingDirectory = $pasta
    $abrir.Description = "Abre a Conferencia Reforma Tributaria TAX ONE (liga a ferramenta se precisar)"
    $abrir.Save()
}
$antigo = Join-Path $AreaTrabalho "$nome.url"
if (Test-Path $antigo) { Remove-Item $antigo -Force }

if (-not $SemLigar) {
    $rodando = Get-NetTCPConnection -LocalPort 5055 -State Listen -ErrorAction SilentlyContinue
    if (-not $rodando) {
        Start-Process -FilePath $pythonw -ArgumentList ('"' + $abrirpyw + '"'), "--sem-navegador" -WorkingDirectory $pasta -WindowStyle Hidden
        Start-Sleep -Seconds 6
    }
}
Write-Host "Atalhos criados (Area de Trabalho e Menu Iniciar) e inicializacao automatica configurada."
