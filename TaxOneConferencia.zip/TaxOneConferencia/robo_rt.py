import filecmp
import json
import os
import re
import time

from playwright.sync_api import sync_playwright

import robo_taxone as rt

MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro",
         "Novembro", "Dezembro"]
IMPOSTOS = ["CBS", "IBS", "IS"]
FONTES = re.compile(r".*\.(woff2?|ttf|otf)(\?.*)?$")
CABECALHO_VAZIO_DEBITOS = "Data de emissão;Estabelecimento;Nº do documento fiscal;Valor do imposto - R$"
CABECALHO_VAZIO_CREDITOS = "Tipo;Data fiscal;Data emissão;Estabelecimento;Nº doc;Valor imposto"


def _log(cb, msg):
    rt._log(cb, msg)


def _abrir_modulo_rt(pg, ctx, empresa, modulo, log, evid=None, fig=None):
    pg, fr = rt._abrir_taxone(pg, log)
    for tentativa in range(3):
        try:
            combos = fr.locator("div.bento-combobox input.form-control")
            if not combos.first.is_visible():
                fr.locator("i.bento-icon-close-thick").first.click()
                combos.first.wait_for(timeout=60000)
                pg.wait_for_timeout(2000)
            _log(log, f"Selecionando empresa {empresa}, agrupamento Reforma Tributária do Consumo, módulo {modulo}...")
            rt._escolher(pg, fr, 0, empresa, "Empresa")
            break
        except rt.ErroRobo as e:
            if "lista vazia" not in str(e) or tentativa == 2:
                raise
            pg, fr = rt.reabrir_taxone(pg, log)
    rt.passo(pg, f"Empresa selecionada: {empresa}")
    rt._escolher(pg, fr, 1, "[ Todos ]", "Estabelecimento")
    rt._escolher(pg, fr, 2, "Reforma Tributária do Consumo", "Agrupamento")
    rt.passo(pg, "Estabelecimento [ Todos ] e agrupamento Reforma Tributária do Consumo selecionados")
    if evid and fig:
        combos.nth(3).click()
        pg.wait_for_timeout(2000)
        rt.shot(pg, evid, fig, destaques=[fr.locator(".bento-combobox-container:visible li", has_text=modulo)],
                recorte=rt.area_taxone(pg))
        pg.keyboard.press("Escape")
        pg.wait_for_timeout(800)
    with ctx.expect_page(timeout=90000) as nova:
        rt._escolher(pg, fr, 3, modulo, "Módulo")
    ap = nova.value
    t0 = time.time()
    while "/portal/rt/" not in ap.url and time.time() - t0 < 180:
        ap.wait_for_timeout(2000)
    if "/portal/rt/" not in ap.url:
        raise rt.ErroRobo(f"O módulo {modulo} não abriu (parou em {ap.url[:80]}).")
    ap.wait_for_timeout(6000)
    rt._fechar_avisos(ap)
    rt.passo(ap, f"Módulo {modulo} aberto em nova aba")
    return ap


def _sessao(p, usuario, senha, log):
    b = rt.abrir_navegador(p, True)
    ctx = rt.contexto(b, 1600, 1000)
    ctx.route(FONTES, lambda r: r.abort())
    pg = ctx.new_page()
    pg.on("dialog", lambda d: d.accept())
    rt._login(pg, usuario, senha, log)
    return b, ctx, pg


def _tab(ap, imposto):
    return ap.locator("saf-tab", has_text=re.compile(rf"^\s*{imposto}\s*$")).first


def _rolar(ap, texto):
    try:
        ap.get_by_text(texto, exact=True).first.scroll_into_view_if_needed(timeout=5000)
        ap.wait_for_timeout(800)
    except Exception:
        pass


def _celula(ap, nome):
    rotulo = "Débito" if nome == "debitos" else "Crédito"
    linha = ap.locator("div.detalhes-container div.metade").first.locator(
        "saf-text.body-default", has_text=re.compile(rf"^\s*{rotulo}")).first
    return linha.locator("xpath=following-sibling::*[1]")


def gerar_apuracao(usuario, senha, empresa, periodo, destino_dir, log=None, evid_dir=None, ambiente="QA", tela_real=False):
    rt.definir_ambiente(ambiente)
    rt.definir_evidencias(evid_dir)
    rt.definir_tela_real(tela_real)
    mes, ano = int(periodo[:2]), periodo[3:]
    rotulo = f"{MESES[mes - 1]} - {ano}"
    os.makedirs(destino_dir, exist_ok=True)
    arquivos = {}
    with sync_playwright() as p:
        b, ctx, pg = _sessao(p, usuario, senha, log)
        try:
            ap = _abrir_modulo_rt(pg, ctx, empresa, "Apuração Fiscal", log, evid_dir, "fig08")
            _log(log, f"Apuração aberta. Selecionando período {rotulo}...")
            sel = ap.locator("saf-select").nth(1)
            sel.wait_for(timeout=60000)
            sel.click()
            ap.wait_for_timeout(1500)
            opc = ap.locator("saf-option").filter(has_text=rotulo)
            if opc.count() == 0:
                disp = [o.strip() for o in ap.locator("saf-option").all_inner_texts() if o.strip()]
                raise rt.ErroRobo(f"Período {rotulo} não disponível na Apuração. Disponíveis: {', '.join(disp[:24])}")
            opc.first.click()
            ap.wait_for_timeout(1000)
            rt.passo(ap, f"Período selecionado na Apuração: {rotulo}")
            ap.locator("saf-button", has_text=re.compile(r"^\s*Pesquisar\s*$")).first.click()
            ap.wait_for_timeout(8000)
            rt.shot(ap, evid_dir, "fig09")
            ap.evaluate("() => window.scrollTo(0, 0)")
            detalhes = ap.get_by_text("Detalhes", exact=True).first.locator(
                "xpath=ancestor::*[.//saf-anchor[contains(@class,'valor-texto')]][1]")
            rt.shot(ap, evid_dir, "fig10", full=True, destaques=[detalhes],
                    elipses=[_celula(ap, "debitos"), _celula(ap, "creditos")])
            ap.evaluate("() => window.scrollTo(0, 0)")
            for imp in IMPOSTOS:
                aba = _tab(ap, imp)
                if not aba.count() or aba.get_attribute("disabled") is not None:
                    _log(log, f"{imp}: aba desabilitada na Apuração — ignorado.")
                    continue
                for idx, nome in ((0, "debitos"), (1, "creditos")):
                    aba.click()
                    ap.wait_for_timeout(4000)
                    if idx == 0:
                        if imp == "CBS":
                            rt.passo(ap, f"Aba {imp} da Apuração")
                        else:
                            rt.shot(ap, evid_dir, f"fig09_{imp}")
                            ap.evaluate("() => window.scrollTo(0, 0)")
                            det = ap.get_by_text("Detalhes", exact=True).first.locator(
                                "xpath=ancestor::*[.//saf-anchor[contains(@class,'valor-texto')]][1]")
                            rt.shot(ap, evid_dir, f"fig10_{imp}", full=True, destaques=[det],
                                    elipses=[_celula(ap, "debitos"), _celula(ap, "creditos")])
                    celula = _celula(ap, nome)
                    if celula.count() == 0:
                        _log(log, f"{imp}: valor de {nome} não encontrado.")
                        continue
                    valor = celula.inner_text().strip()
                    caminho = os.path.join(destino_dir, f"{imp}_{nome}.csv")
                    cabecalho = (CABECALHO_VAZIO_DEBITOS if nome == "debitos" else CABECALHO_VAZIO_CREDITOS)
                    if re.fullmatch(r"(R\$\s*)?0([.,]00)?", valor.replace("\xa0", " ")):
                        open(caminho, "w", encoding="utf-8-sig").write(cabecalho + "\n")
                        arquivos[f"{imp}_{nome}"] = caminho
                        _log(log, f"{imp}: sem {nome} no período ({valor}) — nada a exportar.")
                        rt.passo(ap, f"{imp}: sem {nome} na Apuração do período ({valor})")
                        continue
                    _log(log, f"{imp}: exportando {nome} ({valor})...")
                    exp = ap.locator("saf-button", has_text="Exportar").first
                    abriu = False
                    for tentativa in range(4):
                        link = _celula(ap, nome)
                        try:
                            link.scroll_into_view_if_needed(timeout=5000)
                            alvo_clique = link.locator("a").first if link.locator("a").count() else link
                            if tentativa == 0:
                                alvo_clique.click(timeout=10000)
                            elif tentativa == 1:
                                alvo_clique.click(timeout=10000, force=True)
                            elif tentativa == 2:
                                alvo_clique.dispatch_event("click")
                            else:
                                link.evaluate("e => (e.shadowRoot && e.shadowRoot.querySelector('a') || e).click()")
                        except Exception:
                            pass
                        try:
                            exp.wait_for(timeout=20000)
                            abriu = True
                            break
                        except Exception:
                            _log(log, f"{imp}: detalhe de {nome} ainda não abriu (tentativa {tentativa + 1}/4)...")
                    if not abriu:
                        raise rt.ErroRobo(f"O detalhe de {nome} de {imp} ({valor}) não abriu na Apuração. Tente novamente.")
                    ap.wait_for_timeout(3000)
                    sufixo = "" if imp == "CBS" else f"_{imp}"
                    rt.shot(ap, evid_dir, ("fig11" if nome == "debitos" else "fig12") + sufixo, full=True)
                    for tentativa in range(3):
                        try:
                            with ap.expect_download(timeout=120000) as dl:
                                exp.click()
                            dl.value.save_as(caminho)
                            arquivos[f"{imp}_{nome}"] = caminho
                            rt.passo(ap, f"Relatório de {nome} de {imp} exportado da Apuração ({os.path.basename(caminho)})")
                            break
                        except Exception as e:
                            _log(log, f"{imp}: exportação de {nome} não iniciou (tentativa {tentativa + 1}/3): "
                                      f"{str(e).splitlines()[0][:100]}")
                            ap.wait_for_timeout(5000)
                    if f"{imp}_{nome}" not in arquivos:
                        raise rt.ErroRobo(f"Não foi possível exportar os {nome} de {imp} da Apuração (servidor não respondeu).")
                    ap.go_back(wait_until="commit")
                    ap.wait_for_timeout(6000)
                    ap.locator("saf-anchor.valor-texto").first.wait_for(timeout=60000)
                deb, cre = arquivos.get(f"{imp}_debitos"), arquivos.get(f"{imp}_creditos")
                if deb and cre and filecmp.cmp(deb, cre, shallow=False):
                    raise rt.ErroRobo(f"O arquivo de créditos de {imp} saiu idêntico ao de débitos. A tela da Apuração pode ter mudado; "
                                      "nada foi gerado para não produzir números errados.")
            if not arquivos:
                raise rt.ErroRobo("Nenhum relatório de débito/crédito foi exportado da Apuração.")
            _log(log, "Relatórios da Apuração baixados: " + ", ".join(sorted(arquivos)))
            return arquivos
        except rt.ErroRobo:
            raise
        except Exception as e:
            raise rt.ErroRobo(f"Falha na Apuração: {str(e).splitlines()[0][:300]}")
        finally:
            rt.encerrar(b)


def _selecionar(ap, sel, texto):
    sel.click()
    ap.wait_for_timeout(1200)
    opc = sel.locator("saf-option").filter(has_text=texto)
    if opc.count() == 0:
        disp = [o.strip() for o in sel.locator("saf-option").all_text_contents() if o.strip()]
        ap.keyboard.press("Escape")
        raise rt.ErroRobo(f"Opção '{texto.pattern if hasattr(texto, 'pattern') else texto}' não encontrada. Disponíveis: {', '.join(disp[:20])}")
    opc.first.click()
    ap.wait_for_timeout(2000)


def _select_com_opcao(ap, padrao):
    for s in ap.locator("saf-select").all():
        textos = [t.strip() for t in s.locator("saf-option").all_text_contents()]
        if any(re.search(padrao, t) for t in textos):
            return s, textos
    return None, []


def _definir_competencia(ap, mes, ano, registrar):
    alvo = f"{MESES[mes - 1]} / {ano}"
    if re.search(rf"Competência:\s*\|?\s*{re.escape(alvo)}", _texto(ap)):
        return
    ap.get_by_label("Alterar competência").first.click()
    ap.wait_for_timeout(1500)
    sel_comp, _ = _select_com_opcao(ap, r"\w+ / \d{4}")
    if not sel_comp:
        raise rt.ErroRobo("Seletor de competência não encontrado na Conciliação.")
    _selecionar(ap, sel_comp, re.compile(rf"^\s*{MESES[mes - 1]} / {ano}\s*$"))
    if registrar:
        rt.passo(ap, f"Conciliação – competência {alvo} selecionada")
    ap.locator("saf-button", has_text=re.compile(r"^\s*Salvar\s*$")).first.click()
    ap.wait_for_timeout(1500)
    conf = ap.locator("saf-button[a11y-aria-label='Confirmar competência']")
    if conf.count() and conf.first.get_attribute("disabled") is None:
        conf.first.click()
        ap.wait_for_timeout(2500)


def _empresa_ja_selecionada(ap, cod):
    for s in ap.locator("saf-select").all():
        try:
            v = s.evaluate("e => [e.value, e.getAttribute('value'), e.innerText, e.shadowRoot ? e.shadowRoot.textContent : '']"
                           ".filter(Boolean).join(' ')")
        except Exception:
            continue
        if re.search(rf"(^|\s){re.escape(cod)}\s*-", v or ""):
            return s
    return None


def _filtros_conciliacao(ap, empresa, mes, ano, log, registrar=True):
    cod = rt_cod(empresa)
    t0, recarregou = time.time(), False
    while True:
        sel_emp, _ = _select_com_opcao(ap, rf"^{re.escape(cod)}\s*-")
        if sel_emp or _empresa_ja_selecionada(ap, cod):
            break
        if not recarregou and time.time() - t0 > 30:
            _log(log, "Conciliação: lista de empresas não carregou, recarregando a página...")
            ap.reload(wait_until="commit")
            ap.wait_for_timeout(8000)
            recarregou = True
        if time.time() - t0 > 120:
            raise rt.ErroRobo(f"Empresa {cod} não encontrada na Conciliação.")
        ap.wait_for_timeout(3000)
    _definir_competencia(ap, mes, ano, registrar)
    filial = None
    pesquisar = ap.locator("saf-button", has_text=re.compile(r"^\s*Pesquisar\s*$")).first
    for tentativa in range(3):
        sel_emp, _ = _select_com_opcao(ap, rf"^{re.escape(cod)}\s*-")
        if sel_emp is not None:
            _selecionar(ap, sel_emp, re.compile(rf"^\s*{re.escape(cod)}\s*-"))
        if registrar and tentativa == 0:
            rt.passo(ap, f"Conciliação – empresa {cod} selecionada")
        ops, t1 = [], time.time()
        while time.time() - t1 < 30:
            sel_est, textos = _select_com_opcao(ap, r"Selecionar estabelecimento")
            ops = [t for t in textos if t and "Selecionar" not in t] if sel_est else []
            if ops:
                break
            ap.wait_for_timeout(2000)
        if ops:
            filial = ops[0]
            _selecionar(ap, sel_est, filial)
            ap.wait_for_timeout(1500)
            if pesquisar.count() and pesquisar.get_attribute("disabled") is None:
                if registrar:
                    rt.passo(ap, f"Conciliação – filial selecionada: {filial}")
                break
        _log(log, f"Conciliação: estabelecimento não ficou selecionado (tentativa {tentativa + 1}/3), repetindo...")
        ap.wait_for_timeout(3000)
    else:
        raise rt.ErroRobo("Não foi possível selecionar o estabelecimento na Conciliação (Pesquisar continuou desabilitado).")
    _pesquisar_conciliacao(ap)
    return filial


def _pesquisar_conciliacao(ap):
    pb = ap.locator("saf-button", has_text=re.compile(r"^\s*Pesquisar\s*$")).first
    if pb.count() and pb.get_attribute("disabled") is None:
        pb.click()
    ap.wait_for_timeout(8000)


def _texto(ap):
    return re.sub(r"\s*\n\s*", " | ", ap.inner_text("body"))


def _historico(ap):
    t = _texto(ap)
    total = re.search(r"\| (\d+) \| Total de sessões", t)
    execu = re.search(r"\| (\d+) \| Sessões em execução", t)
    m = re.search(r"Pendentes \| ([^|]+) \| (\d\d/\d\d/\d{4} - \d\d/\d\d/\d{4}) \| (\d\d/\d\d/\d{4} - \d\d:\d\d) \| (\d+)", t)
    linha = {"status": m.group(1).strip(), "periodo": m.group(2), "criada": m.group(3), "pct": m.group(4)} if m else {}
    return (int(total.group(1)) if total else 0, int(execu.group(1)) if execu else 0, linha)


def _criar_sessao(ap, mes, ano, log, evid=None):
    _log(log, "Criando nova sessão de conciliação pelo assistente...")
    ap.locator("saf-button", has_text="Criar conciliação").first.click()
    ap.locator("saf-button", has_text="Contribuinte x Fisco").last.wait_for(timeout=60000)
    ap.wait_for_timeout(1500)
    rt.shot(ap, evid, "fig15")
    ap.locator("saf-button", has_text="Contribuinte x Fisco").last.click()
    ap.locator("saf-button", has_text="Mês anterior").last.wait_for(timeout=60000)
    ap.wait_for_timeout(1000)
    rt.shot(ap, evid, "fig16")
    ultimo = 31 if mes in (1, 3, 5, 7, 8, 10, 12) else (30 if mes != 2 else (29 if int(ano) % 4 == 0 else 28))
    ap.get_by_placeholder("Digite sua mensagem...").first.click()
    ap.keyboard.type(f"{MESES[mes - 1]} de {ano} (01/{mes:02d}/{ano} a {ultimo}/{mes:02d}/{ano})", delay=15)
    rt.passo(ap, "Assistente de conciliação – período digitado")
    ap.locator("saf-button", has_text=re.compile(r"^\s*Enviar\s*$")).first.click()
    ap.locator("saf-button", has_text="Confirmar e criar").last.wait_for(timeout=90000)
    resumo = _texto(ap)
    esperado = f"{ano}-{mes:02d}-01 a {ano}-{mes:02d}-{ultimo:02d}"
    if esperado not in resumo:
        raise rt.ErroRobo(f"O assistente da conciliação não entendeu o período (esperado {esperado}).")
    ap.wait_for_timeout(1000)
    rt.shot(ap, evid, "fig17")
    ap.locator("saf-button", has_text="Confirmar e criar").last.click()
    ap.get_by_text(re.compile(r"criada com sucesso")).first.wait_for(timeout=90000)
    ap.wait_for_timeout(1500)
    rt.shot(ap, evid, "fig18")
    _log(log, "Sessão de conciliação criada. Aguardando processamento...")


def _documentos_sem_inconsistencias(ap, evid, log):
    link = ap.locator("saf-anchor, a, saf-button").filter(has_text=re.compile(r"sem inconsist", re.I)).first
    if not link.count():
        link = ap.get_by_text(re.compile(r"documentos? sem inconsist", re.I)).first
    if not link.count():
        _log(log, "Conciliação: link de documentos sem inconsistências não disponível.")
        return
    try:
        link.scroll_into_view_if_needed(timeout=5000)
        ap.wait_for_timeout(800)
        rt.shot(ap, evid, "fig19", destaques=[link])
        url_antes = ap.url
        link.click(timeout=10000)
        ap.wait_for_timeout(6000)
        if ap.url == url_antes:
            _log(log, "Conciliação: documentos sem inconsistências não abriu (provavelmente não há documentos).")
            return
        rt.shot(ap, evid, "fig20")
        ap.go_back(wait_until="commit")
        ap.wait_for_timeout(7000)
        ap.locator("saf-button", has_text="Visualizar inconsistências").first.wait_for(timeout=60000)
    except Exception as e:
        _log(log, f"Conciliação: não foi possível registrar documentos sem inconsistências ({str(e).splitlines()[0][:80]}).")


def gerar_conciliacao(usuario, senha, empresa, periodo, destino_dir, log=None, criar=True, timeout_sessao=1800,
                      evid_dir=None, ambiente="QA", tela_real=False):
    rt.definir_ambiente(ambiente)
    rt.definir_evidencias(evid_dir)
    rt.definir_tela_real(tela_real)
    mes, ano = int(periodo[:2]), periodo[3:]
    os.makedirs(destino_dir, exist_ok=True)
    with sync_playwright() as p:
        b, ctx, pg = _sessao(p, usuario, senha, log)
        try:
            ap = _abrir_modulo_rt(pg, ctx, empresa, "Conciliação Fiscal", log, evid_dir, "fig13")
            url_painel = ap.url
            filial = _filtros_conciliacao(ap, empresa, mes, ano, log)
            rt.shot(ap, evid_dir, "fig14")
            _log(log, f"Conciliação: filial {filial}, competência {MESES[mes - 1]}/{ano}.")
            total_antes, _, _ = _historico(ap)
            if criar:
                _criar_sessao(ap, mes, ano, log, evid_dir)
                voltou = False
                try:
                    ap.locator("saf-anchor, a").filter(has_text=re.compile(r"^\s*Conciliação\s*$")).first.click(timeout=10000)
                    ap.locator("saf-select").first.wait_for(timeout=20000)
                    voltou = True
                except Exception:
                    pass
                if not voltou:
                    ap.goto(url_painel, wait_until="commit")
                ap.wait_for_timeout(8000)
                _filtros_conciliacao(ap, empresa, mes, ano, log, registrar=False)
                t0 = time.time()
                registrou = False
                while True:
                    total, execu, linha = _historico(ap)
                    st = linha.get("status", "")
                    if total > total_antes and execu == 0 and st.startswith("Conclu"):
                        break
                    if total > total_antes and re.search(r"Erro|Falha|Cancelad", st):
                        raise rt.ErroRobo(f"A sessão de conciliação terminou com status {st}.")
                    if time.time() - t0 > timeout_sessao:
                        raise rt.ErroRobo("Tempo esgotado aguardando a sessão de conciliação concluir.")
                    _log(log, f"Sessão de conciliação em processamento... ({st or 'aguardando'} {linha.get('pct', '')}%)")
                    if not registrou:
                        _rolar(ap, "Histórico das sessões")
                        rt.passo(ap, "Histórico – sessão de conciliação em processamento")
                        registrou = True
                    ap.wait_for_timeout(20000)
                    _pesquisar_conciliacao(ap)
                _log(log, "Sessão de conciliação concluída.")
                ap.evaluate("() => window.scrollTo(0, 0)")
                rt.passo(ap, "Painel da conciliação após a sessão concluída")

            t = _texto(ap)
            ultimo = re.search(r"Último período conciliado: \| ([^|]+)", t)
            if "Visualizar inconsistências" not in t:
                rt.passo(ap, "Conciliação sem dados de inconsistências para o período")
                _log(log, "Conciliação: o painel não trouxe dados para o período (sem documentos a conciliar).")
                resultado = {"filial": filial, "periodo": periodo, "ultima_sessao": ultimo.group(1).strip() if ultimo else "",
                             "totais": {"debitos": ("-", "-"), "creditos": ("-", "-")}, "arquivos": {}, "sem_dados": True}
                json.dump(resultado, open(os.path.join(destino_dir, "conciliacao.json"), "w", encoding="utf-8"),
                          ensure_ascii=False, indent=1)
                return resultado
            _documentos_sem_inconsistencias(ap, evid_dir, log)
            _rolar(ap, "Inconsistências")
            rt.shot(ap, evid_dir, "fig21")
            _rolar(ap, "Detalhes")
            rt.shot(ap, evid_dir, "fig24")
            _rolar(ap, "Histórico das sessões")
            rt.shot(ap, evid_dir, "fig25")
            ap.evaluate("() => window.scrollTo(0, 0)")

            def valor(bloco):
                m = re.search(rf"\| {bloco} \| Contribuinte \| Fisco \| Valor dos impostos\W+Total \| Contribuinte \| (R\$\s?[\d\.,]+|-) \| Fisco \| (R\$\s?[\d\.,]+|-)", t)
                return (m.group(1), m.group(2)) if m else ("-", "-")
            resultado = {"filial": filial, "periodo": periodo, "ultima_sessao": ultimo.group(1).strip() if ultimo else "",
                         "totais": {"debitos": valor("Débitos"), "creditos": valor("Créditos")}, "arquivos": {}}
            for idx, nome in ((1, "debitos"), (2, "creditos"), (0, "documentos")):
                botoes = ap.locator("saf-button", has_text="Visualizar inconsistências")
                if botoes.count() <= idx:
                    continue
                botoes.nth(idx).click()
                exp = ap.locator("saf-button", has_text="Exportar").first
                try:
                    exp.wait_for(timeout=45000)
                except Exception:
                    _log(log, f"Conciliação: sem inconsistências de {nome} para exportar.")
                    rt.passo(ap, f"Conciliação – sem inconsistências de {nome}")
                    if "/conciliation" in ap.url and ap.locator("saf-button", has_text="Visualizar inconsistências").count():
                        continue
                    ap.go_back(wait_until="commit")
                    ap.wait_for_timeout(7000)
                    continue
                ap.wait_for_timeout(4000)
                if nome in ("documentos", "debitos"):
                    rt.shot(ap, evid_dir, "fig22" if nome == "documentos" else "fig23")
                else:
                    rt.passo(ap, "Inconsistências nos créditos")
                for tentativa in range(3):
                    try:
                        with ap.expect_download(timeout=120000) as dl:
                            exp.click()
                        caminho = os.path.join(destino_dir, f"conciliacao_{nome}.csv")
                        dl.value.save_as(caminho)
                        resultado["arquivos"][nome] = caminho
                        _log(log, f"Conciliação: exportado {nome}.")
                        rt.passo(ap, f"Inconsistências de {nome} exportadas da Conciliação ({os.path.basename(caminho)})")
                        break
                    except Exception as e:
                        _log(log, f"Conciliação: exportação de {nome} não iniciou (tentativa {tentativa + 1}/3): "
                                  f"{str(e).splitlines()[0][:100]}")
                        ap.wait_for_timeout(5000)
                ap.go_back(wait_until="commit")
                ap.wait_for_timeout(7000)
                ap.locator("saf-button", has_text="Visualizar inconsistências").first.wait_for(timeout=60000)
            json.dump(resultado, open(os.path.join(destino_dir, "conciliacao.json"), "w", encoding="utf-8"),
                      ensure_ascii=False, indent=1)
            return resultado
        except rt.ErroRobo:
            raise
        except Exception as e:
            raise rt.ErroRobo(f"Falha na Conciliação: {str(e).splitlines()[0][:300]}")
        finally:
            rt.encerrar(b)


def rt_cod(empresa):
    return (empresa or "").split(" - ")[0].strip()
