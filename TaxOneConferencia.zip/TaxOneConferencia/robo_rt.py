import csv
import filecmp
import json
import os
import re
import time
from urllib.parse import parse_qs, urlsplit

from playwright.sync_api import Error as PWError
from playwright.sync_api import sync_playwright

import robo_taxone as rt

MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro",
         "Novembro", "Dezembro"]
IMPOSTOS = ["CBS", "IBS", "IS"]
FONTES = re.compile(r".*\.(woff2?|ttf|otf)(\?.*)?$")
CLIQUE_MS = 30000
_LOG = [None]
JS_LIBERAR = """el => {
  const r = el.getBoundingClientRect();
  const x = r.left + r.width / 2, y = r.top + r.height / 2;
  const liberados = [];
  for (let i = 0; i < 3; i++) {
    const t = document.elementFromPoint(x, y);
    if (!t || t === document.body || t === document.documentElement || t === el || el.contains(t) || t.contains(el)) break;
    t.style.setProperty('pointer-events', 'none', 'important');
    liberados.push(t.tagName.toLowerCase() + (t.id ? '#' + t.id : ''));
  }
  return liberados;
}"""
CABECALHO_VAZIO_DEBITOS = "Data de emissão;Estabelecimento;Nº do documento fiscal;Valor do imposto - R$"
CABECALHO_VAZIO_CREDITOS = "Tipo;Data fiscal;Data emissão;Estabelecimento;Nº doc;Valor imposto"


def _log(cb, msg):
    rt._log(cb, msg)


def _abrir_modulo_rt(pg, ctx, empresa, modulo, log, evid=None, fig=None):
    _LOG[0] = log
    pg, fr = rt._abrir_taxone(pg, log)
    for tentativa in range(3):
        try:
            combos = fr.locator("div.bento-combobox input.form-control")
            if not combos.first.is_visible():
                fr.locator("i.bento-icon-close-thick").first.click()
                combos.first.wait_for(timeout=60000)
                pg.wait_for_timeout(2000)
            _log(log, f"Selecionando empresa {empresa}, agrupamento Reforma Tributária do Consumo, módulo {modulo}...")
            rt._escolher(pg, fr, 0, empresa, "Empresa")
            break
        except rt.ErroRobo as e:
            if "lista vazia" not in str(e) or tentativa == 2:
                raise
            pg, fr = rt.reabrir_taxone(pg, log)
    rt.passo(pg, f"Empresa selecionada: {empresa}")
    rt._escolher(pg, fr, 1, "[ Todos ]", "Estabelecimento")
    rt._escolher(pg, fr, 2, "Reforma Tributária do Consumo", "Agrupamento")
    rt.passo(pg, "Estabelecimento [ Todos ] e agrupamento Reforma Tributária do Consumo selecionados")
    if evid and fig:
        combos.nth(3).click()
        pg.wait_for_timeout(2000)
        rt.shot(pg, evid, fig, destaques=[fr.locator(".bento-combobox-container:visible li", has_text=modulo)],
                recorte=rt.area_taxone(pg))
        pg.keyboard.press("Escape")
        pg.wait_for_timeout(800)
    with ctx.expect_page(timeout=90000) as nova:
        rt._escolher(pg, fr, 3, modulo, "Módulo")
    ap = nova.value
    try:
        ap.bring_to_front()
    except PWError:
        pass
    t0 = time.time()
    while "/portal/rt/" not in ap.url and time.time() - t0 < 180:
        ap.wait_for_timeout(2000)
    if "/portal/rt/" not in ap.url:
        raise rt.ErroRobo(f"O módulo {modulo} não abriu (parou em {ap.url[:80]}).")
    ap.wait_for_timeout(6000)
    rt._fechar_avisos(ap)
    rt.passo(ap, f"Módulo {modulo} aberto em nova aba")
    return ap


def _sessao(p, usuario, senha, log):
    b = rt.abrir_navegador(p, True)
    ctx = rt.contexto(b, 1600, 1000)
    ctx.route(FONTES, lambda r: r.abort())
    pg = ctx.new_page()
    pg.on("dialog", lambda d: d.accept())
    pg = rt._login(pg, usuario, senha, log)
    novo = rt.sem_janela(p, b, ctx, log, 1600, 1000, lambda c: c.route(FONTES, lambda r: r.abort()))
    if novo:
        b, ctx, pg = novo
    return b, ctx, pg


def _pasta_clique():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "TaxOneConferencia", "diagnostico", "clique_" + time.strftime("%Y%m%d_%H%M%S"))


def _clicar_robusto(ap, loc, log, descricao, efeito=None):
    log = log or _LOG[0]
    try:
        loc.click(timeout=CLIQUE_MS)
        return
    except PWError as e:
        motivo = rt.resumo_erro(e, 200)
    _log(log, f"{descricao}: o clique normal não funcionou ({motivo}). Tentando de outro jeito...")
    rt.registrar_falha(ap, _pasta_clique(), log)
    try:
        ap.bring_to_front()
    except PWError:
        pass
    rt._fechar_avisos(ap)
    curto = max(1500, CLIQUE_MS // 4)
    try:
        loc.click(timeout=curto)
        return
    except PWError:
        pass
    try:
        liberados = loc.evaluate(JS_LIBERAR, timeout=3000)
    except PWError:
        liberados = []
    if liberados:
        _log(log, f"{descricao}: havia {', '.join(liberados)} na frente do botão; o clique passa por cima.")
        try:
            loc.click(timeout=curto)
            return
        except PWError:
            pass
    if efeito:
        try:
            loc.click(force=True, timeout=3000)
            ap.wait_for_timeout(800)
            if efeito():
                return
        except PWError:
            pass
    loc.dispatch_event("click")


def _tab(ap, imposto):
    return ap.locator("saf-tab", has_text=re.compile(rf"^\s*{imposto}\s*$")).first


def _rolar(ap, texto):
    try:
        ap.get_by_text(texto, exact=True).first.scroll_into_view_if_needed(timeout=5000)
        ap.wait_for_timeout(800)
    except Exception:
        pass


def _celula(ap, nome):
    rotulo = "Débito" if nome == "debitos" else "Crédito"
    padrao = re.compile(rf"^\s*{rotulo}")
    metades = ap.locator("div.detalhes-container div.metade").filter(visible=True).filter(
        has=ap.locator("saf-text.body-default", has_text=padrao))
    if metades.count():
        linha = metades.first.locator("saf-text.body-default", has_text=padrao).first
    else:
        linha = ap.locator("saf-text.body-default", has_text=padrao).filter(visible=True).first
    return linha.locator("xpath=following-sibling::*[1]")


JS_TABELA = r"""
() => {
  const norm = t => (t || '').replace(/\s+/g, ' ').trim();
  const visivel = e => {
    const r = e.getBoundingClientRect();
    const s = getComputedStyle(e);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
  };
  const dinheiro = /^R\$\s*-?[\d.]+,\d{2}$/;
  const inteiro = /^\d+$/;
  document.querySelectorAll('[data-taxone]').forEach(e => e.removeAttribute('data-taxone'));
  const todos = Array.from(document.querySelectorAll('body *')).filter(visivel);
  const folha = e => !Array.from(e.children).some(c => norm(c.textContent));
  const clicavel = e => {
    let x = e;
    for (let i = 0; i < 4 && x && x !== document.body; i++, x = x.parentElement) {
      if (x.matches('a, button, saf-anchor, [role=link], [role=button], [onclick]')) return x;
      if (getComputedStyle(x).cursor === 'pointer') return x;
    }
    return null;
  };
  const rotulos = {debitos: /^d[eé]bitos?:?$/i, creditos: /^cr[eé]ditos?:?$/i};
  const saida = {};
  for (const chave of Object.keys(rotulos)) {
    const rots = todos.filter(e => rotulos[chave].test(norm(e.textContent)) && folha(e));
    for (const rot of rots) {
      let lin = rot.parentElement;
      let dins = [];
      for (let i = 0; i < 6 && lin && lin !== document.body; i++, lin = lin.parentElement) {
        dins = todos.filter(e => lin.contains(e) && folha(e) && dinheiro.test(norm(e.textContent)));
        if (dins.length >= 3) break;
        dins = [];
      }
      if (!dins.length) continue;
      const qtds = todos.filter(e => lin.contains(e) && folha(e) && inteiro.test(norm(e.textContent)));
      const itens = {total: dins[dins.length - 1], qtd: qtds.length ? qtds[qtds.length - 1] : null,
                     estadual: dins[0], municipal: dins[1]};
      const info = {textos: {}, clicavel: {}};
      for (const col of Object.keys(itens)) {
        const el = itens[col];
        if (!el) continue;
        const alvo = clicavel(el);
        (alvo || el).setAttribute('data-taxone', chave + '-' + col);
        info.textos[col] = norm(el.textContent);
        info.clicavel[col] = !!alvo;
      }
      const tabela = lin.closest('table') || lin.parentElement;
      if (tabela && !document.querySelector('[data-taxone="tabela"]')) tabela.setAttribute('data-taxone', 'tabela');
      saida[chave] = info;
      break;
    }
  }
  return saida;
}
"""


def _tabela(ap):
    try:
        return ap.evaluate(JS_TABELA) or {}
    except Exception:
        return {}


def _alvo_tabela(ap, nome, col):
    return ap.locator(f'[data-taxone="{nome}-{col}"]').first


def _detalhes(ap):
    return ap.get_by_text("Detalhes", exact=True).locator(
        "xpath=ancestor::*[.//saf-anchor[contains(@class,'valor-texto')]][1]").filter(visible=True).first


def _num_br(txt):
    s = re.sub(r"[^\d,.\-]", "", str(txt or ""))
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _soma_csv(caminho):
    padrao = re.compile(r"^Valor (do )?imposto|^Valor (IBS|CBS|IS)\s*-\s*R\$", re.I)
    with open(caminho, encoding="utf-8-sig", newline="") as f:
        leitor = csv.reader(f, delimiter=";")
        cab = next(leitor, [])
        col = next((i for i, c in enumerate(cab) if padrao.search(c.strip())), None)
        if col is None:
            return None
        total = 0.0
        for linha in leitor:
            v = _num_br(linha[col]) if col < len(linha) else None
            if v is not None:
                total += v
    return round(total, 2)


def _duplicado(arquivos, chave):
    atual = arquivos[chave]
    with open(atual, encoding="utf-8-sig") as f:
        if sum(1 for _ in f) <= 1:
            return None
    for outra, caminho in arquivos.items():
        if outra != chave and os.path.exists(caminho) and filecmp.cmp(atual, caminho, shallow=False):
            return outra
    return None


def _valor_tela(ap, nome, modo="card"):
    anterior = None
    for _ in range(8):
        if modo == "tabela":
            v = _tabela(ap).get(nome, {}).get("textos", {}).get("total", "")
        else:
            c = _celula(ap, nome)
            try:
                v = c.inner_text(timeout=3000).strip() if c.count() else ""
            except Exception:
                v = ""
        if v and v == anterior:
            return v
        anterior = v
        ap.wait_for_timeout(1200)
    return anterior or ""


def _painel_pronto(ap, segundos=45):
    t0 = time.time()
    while time.time() - t0 < segundos:
        if _celula(ap, "debitos").count():
            return "card"
        if _tabela(ap).get("debitos", {}).get("textos", {}).get("total"):
            return "tabela"
        ap.wait_for_timeout(1000)
    return None


def _esperar(ap, loc, segundos):
    t0 = time.time()
    while time.time() - t0 < segundos:
        try:
            if loc.is_visible():
                return True
        except Exception:
            pass
        ap.wait_for_timeout(500)
    return False


def _caminho(ap):
    return urlsplit(ap.url).path.rstrip("/")


def _voltar_painel(ap, painel):
    try:
        if _caminho(ap) != painel:
            ap.go_back(wait_until="commit")
            ap.wait_for_timeout(6000)
        ap.locator("saf-tab").first.wait_for(state="visible", timeout=60000)
        return True
    except Exception:
        return False


def _alvo_clique(ap, nome, modo, tentativa):
    if modo == "tabela":
        _tabela(ap)
        return _alvo_tabela(ap, nome, ("total", "total", "qtd", "estadual")[tentativa])
    return _celula(ap, nome)


def _pesquisar_detalhe(ap, exp, segundos=90):
    botao = ap.locator("saf-button", has_text=re.compile(r"^\s*Pesquisar\s*$")).filter(visible=True).first
    if not _esperar(ap, botao, 20):
        return False
    try:
        botao.scroll_into_view_if_needed(timeout=8000)
        botao.click(timeout=10000)
    except Exception:
        return False
    return _esperar(ap, exp, segundos)


def _abrir_detalhe(ap, imp, nome, exp, log, painel, modo="card"):
    for tentativa in range(4):
        clicou = False
        try:
            link = _alvo_clique(ap, nome, modo, tentativa)
            link.scroll_into_view_if_needed(timeout=8000)
            alvo_clique = link.locator("a").first if link.locator("a").count() else link
            if tentativa == 0:
                alvo_clique.click(timeout=10000)
            elif tentativa == 1:
                alvo_clique.click(timeout=10000, force=True)
            elif tentativa == 2:
                alvo_clique.dispatch_event("click")
            else:
                link.evaluate("e => (e.shadowRoot && e.shadowRoot.querySelector('a') || e).click()")
            clicou = True
        except Exception:
            pass
        if clicou and _esperar(ap, exp, 15):
            return True
        if _caminho(ap) != painel:
            if _pesquisar_detalhe(ap, exp) or _esperar(ap, exp, 60):
                return True
            _voltar_painel(ap, painel)
        _log(log, f"{imp}: detalhe de {nome} ainda não abriu (tentativa {tentativa + 1}/4)...")
    return False


def _baixar_detalhe(ap, exp, caminho, imp, nome, log):
    for tentativa in range(3):
        try:
            with ap.expect_download(timeout=120000) as dl:
                exp.click()
            dl.value.save_as(caminho)
            return True
        except Exception as e:
            _log(log, f"{imp}: exportação de {nome} não iniciou (tentativa {tentativa + 1}/3): "
                      f"{str(e).splitlines()[0][:100]}")
            ap.wait_for_timeout(5000)
    return False


def _diagnostico(ap, evid_dir, imp, nome, motivo, modulo="Apuração"):
    try:
        rt.passo(ap, f"ERRO na {modulo} ({imp} {nome}): {motivo}"[:150])
        if evid_dir:
            os.makedirs(evid_dir, exist_ok=True)
            base = os.path.join(evid_dir, f"erro_{imp}_{nome}")
            texto = ap.inner_text("body", timeout=5000)
            total = ap.locator("div.detalhes-container").count()
            visiveis = ap.locator("div.detalhes-container").filter(visible=True).count()
            tabela = json.dumps(_tabela(ap), ensure_ascii=False)
            with open(base + ".txt", "w", encoding="utf-8") as f:
                f.write(f"{time.strftime('%d/%m/%Y %H:%M:%S')}\nEndereço: {ap.url}\nMotivo: {motivo}\n"
                        f"Blocos de detalhes: {total} na página, {visiveis} visíveis\n"
                        f"Tabela de lançamentos reconhecida: {tabela}\n\n{texto[:6000]}\n")
            try:
                with open(base + ".html", "w", encoding="utf-8") as f:
                    f.write(ap.content())
            except Exception:
                pass
            try:
                ap.screenshot(path=base + ".png", full_page=True, timeout=15000)
            except Exception:
                pass
    except Exception:
        pass


def _exportar_item(ap, aba, imp, idx, nome, destino_dir, evid_dir, log, arquivos, painel):
    aba.click()
    ap.wait_for_timeout(4000)
    modo = _painel_pronto(ap)
    if not modo:
        raise rt.ErroRobo(f"O painel de {imp} não foi reconhecido na Apuração (nem o quadro Detalhes, nem a tabela Lançamento).")
    if idx == 0:
        if imp == "CBS":
            rt.passo(ap, f"Aba {imp} da Apuração")
        else:
            rt.shot(ap, evid_dir, f"fig09_{imp}")
            ap.evaluate("() => window.scrollTo(0, 0)")
            if modo == "tabela":
                _tabela(ap)
                rt.shot(ap, evid_dir, f"fig10_{imp}", full=True, destaques=[ap.locator('[data-taxone="tabela"]').first],
                        elipses=[_alvo_tabela(ap, "debitos", "total"), _alvo_tabela(ap, "creditos", "total")])
            else:
                rt.shot(ap, evid_dir, f"fig10_{imp}", full=True, destaques=[_detalhes(ap)],
                        elipses=[_celula(ap, "debitos"), _celula(ap, "creditos")])
    valor = _valor_tela(ap, nome, modo)
    if not valor:
        raise rt.ErroRobo(f"O valor de {nome} de {imp} não foi encontrado na tela da Apuração.")
    qtd = _tabela(ap).get(nome, {}).get("textos", {}).get("qtd", "") if modo == "tabela" else ""
    resumo_tela = f"{valor}" + (f", {qtd} documentos" if qtd else "")
    caminho = os.path.join(destino_dir, f"{imp}_{nome}.csv")
    chave = f"{imp}_{nome}"
    cabecalho = CABECALHO_VAZIO_DEBITOS if nome == "debitos" else CABECALHO_VAZIO_CREDITOS
    if re.fullmatch(r"(R\$\s*)?0([.,]00)?", valor.replace("\xa0", " ")):
        open(caminho, "w", encoding="utf-8-sig").write(cabecalho + "\n")
        arquivos[chave] = caminho
        _log(log, f"{imp}: sem {nome} no período ({valor}) — nada a exportar.")
        rt.passo(ap, f"{imp}: sem {nome} na Apuração do período ({valor})")
        return
    _log(log, f"{imp}: exportando {nome} ({resumo_tela})...")
    exp = ap.locator("saf-button", has_text="Exportar").filter(visible=True).first
    if not _abrir_detalhe(ap, imp, nome, exp, log, painel, modo):
        raise rt.ErroRobo(f"O detalhe de {nome} de {imp} ({resumo_tela}) não abriu na Apuração.")
    ap.wait_for_timeout(3000)
    sufixo = "" if imp == "CBS" else f"_{imp}"
    rt.shot(ap, evid_dir, ("fig11" if nome == "debitos" else "fig12") + sufixo, full=True)
    if not _baixar_detalhe(ap, exp, caminho, imp, nome, log):
        raise rt.ErroRobo(f"Não foi possível exportar os {nome} de {imp} da Apuração (servidor não respondeu).")
    arquivos[chave] = caminho
    rt.passo(ap, f"Relatório de {nome} de {imp} exportado da Apuração ({os.path.basename(caminho)})")
    soma, na_tela = _soma_csv(caminho), _num_br(valor)
    if soma is not None and na_tela is not None and abs(soma - na_tela) > 0.05:
        _log(log, f"{imp}: atenção — a soma do arquivo de {nome} (R$ {soma:,.2f}) difere do valor da tela ({valor}).")
    igual = _duplicado(arquivos, chave)
    if igual:
        arquivos.pop(chave)
        os.remove(caminho)
        raise rt.ErroRobo(f"O arquivo de {nome} de {imp} saiu idêntico ao de {igual.replace('_', ' ')}. "
                          "A tela da Apuração pode ter mudado; nada foi gerado para não produzir números errados.")
    if not _voltar_painel(ap, painel):
        raise rt.ErroRobo(f"A tela da Apuração não voltou ao painel depois de exportar {nome} de {imp}.")


def _coletar(ap, destino_dir, evid_dir, log):
    arquivos, falhas = {}, []
    painel = _caminho(ap)
    for imp in IMPOSTOS:
        aba = _tab(ap, imp)
        if not aba.count() or aba.get_attribute("disabled") is not None:
            _log(log, f"{imp}: aba desabilitada na Apuração — ignorado.")
            continue
        for idx, nome in ((0, "debitos"), (1, "creditos")):
            try:
                _exportar_item(ap, aba, imp, idx, nome, destino_dir, evid_dir, log, arquivos, painel)
                continue
            except rt.ErroRobo as e:
                motivo = str(e)
            except Exception as e:
                if ap.is_closed():
                    raise
                motivo = "falha inesperada: " + str(e).splitlines()[0][:150]
            falhas.append(f"{imp} {nome}: {motivo}")
            _log(log, f"ATENÇÃO — {imp}: {motivo}")
            _diagnostico(ap, evid_dir, imp, nome, motivo)
            if not _voltar_painel(ap, painel):
                _log(log, "A Apuração não voltou ao painel; a coleta segue só com o que já foi exportado.")
                falhas.append("Coleta interrompida: a tela da Apuração não voltou ao painel.")
                return arquivos, falhas
    return arquivos, falhas


def gerar_apuracao(usuario, senha, empresa, periodo, destino_dir, log=None, evid_dir=None, ambiente="QA", tela_real=False,
                   acesso=None):
    rt.definir_ambiente(ambiente)
    rt.definir_evidencias(evid_dir)
    rt.definir_tela_real(tela_real)
    rt.definir_acesso(acesso, usuario)
    mes, ano = int(periodo[:2]), periodo[3:]
    rotulo = f"{MESES[mes - 1]} - {ano}"
    os.makedirs(destino_dir, exist_ok=True)
    with sync_playwright() as p:
        b, ctx, pg = _sessao(p, usuario, senha, log)
        ap = None
        try:
            ap = _abrir_modulo_rt(pg, ctx, empresa, "Apuração Fiscal", log, evid_dir, "fig08")
            _log(log, f"Apuração aberta. Selecionando período {rotulo}...")
            sel = ap.locator("saf-select").nth(1)
            sel.wait_for(timeout=60000)
            aberta = lambda: ap.locator("saf-option").filter(visible=True).count() > 0
            _clicar_robusto(ap, sel, log, "Lista de períodos", aberta)
            ap.wait_for_timeout(1500)
            opc = ap.locator("saf-option").filter(has_text=rotulo)
            if opc.count() == 0:
                disp = [o.strip() for o in ap.locator("saf-option").all_inner_texts() if o.strip()]
                rt.registrar_falha(ap, destino_dir, log)
                if not disp:
                    raise rt.ErroRobo("A lista de períodos da Apuração não abriu (nenhuma opção apareceu na tela).")
                raise rt.ErroRobo(f"Período {rotulo} não disponível na Apuração. Disponíveis: {', '.join(disp[:24])}")
            _clicar_robusto(ap, opc.first, log, f"Período {rotulo}")
            ap.wait_for_timeout(1000)
            rt.passo(ap, f"Período selecionado na Apuração: {rotulo}")
            _clicar_robusto(ap, ap.locator("saf-button", has_text=re.compile(r"^\s*Pesquisar\s*$")).first, log, "Botão Pesquisar")
            ap.wait_for_timeout(8000)
            rt.shot(ap, evid_dir, "fig09")
            ap.evaluate("() => window.scrollTo(0, 0)")
            rt.shot(ap, evid_dir, "fig10", full=True, destaques=[_detalhes(ap)],
                    elipses=[_celula(ap, "debitos"), _celula(ap, "creditos")])
            ap.evaluate("() => window.scrollTo(0, 0)")
            arquivos, falhas = _coletar(ap, destino_dir, evid_dir, log)
            if not arquivos:
                raise rt.ErroRobo("Nenhum relatório de débito/crédito foi exportado da Apuração. " + "; ".join(falhas))
            _log(log, "Relatórios da Apuração baixados: " + ", ".join(sorted(arquivos)))
            return arquivos, falhas
        except rt.ErroRobo:
            raise
        except Exception as e:
            rt.registrar_falha(ap or ctx, destino_dir, log)
            raise rt.ErroRobo(f"Falha na Apuração: {rt.resumo_erro(e)}")
        finally:
            rt.encerrar(b)


def _selecionar(ap, sel, texto):
    _clicar_robusto(ap, sel, None, "Lista de opções", lambda: sel.locator("saf-option").filter(visible=True).count() > 0)
    ap.wait_for_timeout(1200)
    opc = sel.locator("saf-option").filter(has_text=texto)
    if opc.count() == 0:
        disp = [o.strip() for o in sel.locator("saf-option").all_text_contents() if o.strip()]
        ap.keyboard.press("Escape")
        raise rt.ErroRobo(f"Opção '{texto.pattern if hasattr(texto, 'pattern') else texto}' não encontrada. Disponíveis: {', '.join(disp[:20])}")
    _clicar_robusto(ap, opc.first, None, "Opção da lista")
    ap.wait_for_timeout(2000)


def _select_com_opcao(ap, padrao):
    for s in ap.locator("saf-select").all():
        textos = [t.strip() for t in s.locator("saf-option").all_text_contents()]
        if any(re.search(padrao, t) for t in textos):
            return s, textos
    return None, []


def _definir_competencia(ap, mes, ano, registrar):
    alvo = f"{MESES[mes - 1]} / {ano}"
    if re.search(rf"Competência:\s*\|?\s*{re.escape(alvo)}", _texto(ap)):
        return
    _clicar_robusto(ap, ap.get_by_label("Alterar competência").first, None, "Alterar competência")
    ap.wait_for_timeout(1500)
    sel_comp, _ = _select_com_opcao(ap, r"\w+ / \d{4}")
    if not sel_comp:
        raise rt.ErroRobo("Seletor de competência não encontrado na Conciliação.")
    _selecionar(ap, sel_comp, re.compile(rf"^\s*{MESES[mes - 1]} / {ano}\s*$"))
    if registrar:
        rt.passo(ap, f"Conciliação – competência {alvo} selecionada")
    ap.locator("saf-button", has_text=re.compile(r"^\s*Salvar\s*$")).first.click()
    ap.wait_for_timeout(1500)
    conf = ap.locator("saf-button[a11y-aria-label='Confirmar competência']")
    if conf.count() and conf.first.get_attribute("disabled") is None:
        conf.first.click()
        ap.wait_for_timeout(2500)


def _empresa_ja_selecionada(ap, cod):
    for s in ap.locator("saf-select").all():
        try:
            v = s.evaluate("e => [e.value, e.getAttribute('value'), e.innerText, e.shadowRoot ? e.shadowRoot.textContent : '']"
                           ".filter(Boolean).join(' ')")
        except Exception:
            continue
        if re.search(rf"(^|\s){re.escape(cod)}\s*-", v or ""):
            return s
    return None


def _filtros_conciliacao(ap, empresa, mes, ano, log, registrar=True):
    cod = rt_cod(empresa)
    t0, recarregou = time.time(), False
    while True:
        sel_emp, _ = _select_com_opcao(ap, rf"^{re.escape(cod)}\s*-")
        if sel_emp or _empresa_ja_selecionada(ap, cod):
            break
        if not recarregou and time.time() - t0 > 30:
            _log(log, "Conciliação: lista de empresas não carregou, recarregando a página...")
            ap.reload(wait_until="commit")
            ap.wait_for_timeout(8000)
            recarregou = True
        if time.time() - t0 > 120:
            raise rt.ErroRobo(f"Empresa {cod} não encontrada na Conciliação.")
        ap.wait_for_timeout(3000)
    _definir_competencia(ap, mes, ano, registrar)
    filial = None
    pesquisar = ap.locator("saf-button", has_text=re.compile(r"^\s*Pesquisar\s*$")).first
    for tentativa in range(3):
        sel_emp, _ = _select_com_opcao(ap, rf"^{re.escape(cod)}\s*-")
        if sel_emp is not None:
            _selecionar(ap, sel_emp, re.compile(rf"^\s*{re.escape(cod)}\s*-"))
        if registrar and tentativa == 0:
            rt.passo(ap, f"Conciliação – empresa {cod} selecionada")
        ops, t1 = [], time.time()
        while time.time() - t1 < 30:
            sel_est, textos = _select_com_opcao(ap, r"Selecionar estabelecimento")
            ops = [t for t in textos if t and "Selecionar" not in t] if sel_est else []
            if ops:
                break
            ap.wait_for_timeout(2000)
        if ops:
            filial = ops[0]
            _selecionar(ap, sel_est, filial)
            ap.wait_for_timeout(1500)
            if pesquisar.count() and pesquisar.get_attribute("disabled") is None:
                if registrar:
                    rt.passo(ap, f"Conciliação – filial selecionada: {filial}")
                break
        _log(log, f"Conciliação: estabelecimento não ficou selecionado (tentativa {tentativa + 1}/3), repetindo...")
        ap.wait_for_timeout(3000)
    else:
        raise rt.ErroRobo("Não foi possível selecionar o estabelecimento na Conciliação (Pesquisar continuou desabilitado).")
    _pesquisar_conciliacao(ap)
    return filial


def _pesquisar_conciliacao(ap):
    pb = ap.locator("saf-button", has_text=re.compile(r"^\s*Pesquisar\s*$")).first
    if pb.count() and pb.get_attribute("disabled") is None:
        pb.click()
    ap.wait_for_timeout(8000)


def _texto(ap):
    return re.sub(r"\s*\n\s*", " | ", ap.inner_text("body"))


def _historico(ap):
    t = _texto(ap)
    total = re.search(r"\| (\d+) \| Total de sessões", t)
    execu = re.search(r"\| (\d+) \| Sessões em execução", t)
    m = re.search(r"Pendentes \| ([^|]+) \| (\d\d/\d\d/\d{4} - \d\d/\d\d/\d{4}) \| (\d\d/\d\d/\d{4} - \d\d:\d\d) \| (\d+)", t)
    linha = {"status": m.group(1).strip(), "periodo": m.group(2), "criada": m.group(3), "pct": m.group(4)} if m else {}
    return (int(total.group(1)) if total else 0, int(execu.group(1)) if execu else 0, linha)


def _criar_sessao(ap, mes, ano, log, evid=None):
    _log(log, "Criando nova sessão de conciliação pelo assistente...")
    ap.locator("saf-button", has_text="Criar conciliação").first.click()
    ap.locator("saf-button", has_text="Contribuinte x Fisco").last.wait_for(timeout=60000)
    ap.wait_for_timeout(1500)
    rt.shot(ap, evid, "fig15")
    ap.locator("saf-button", has_text="Contribuinte x Fisco").last.click()
    ap.locator("saf-button", has_text="Mês anterior").last.wait_for(timeout=60000)
    ap.wait_for_timeout(1000)
    rt.shot(ap, evid, "fig16")
    ultimo = 31 if mes in (1, 3, 5, 7, 8, 10, 12) else (30 if mes != 2 else (29 if int(ano) % 4 == 0 else 28))
    ap.get_by_placeholder("Digite sua mensagem...").first.click()
    ap.keyboard.type(f"{MESES[mes - 1]} de {ano} (01/{mes:02d}/{ano} a {ultimo}/{mes:02d}/{ano})", delay=15)
    rt.passo(ap, "Assistente de conciliação – período digitado")
    ap.locator("saf-button", has_text=re.compile(r"^\s*Enviar\s*$")).first.click()
    ap.locator("saf-button", has_text="Confirmar e criar").last.wait_for(timeout=90000)
    resumo = _texto(ap)
    esperado = f"{ano}-{mes:02d}-01 a {ano}-{mes:02d}-{ultimo:02d}"
    if esperado not in resumo:
        raise rt.ErroRobo(f"O assistente da conciliação não entendeu o período (esperado {esperado}).")
    ap.wait_for_timeout(1000)
    rt.shot(ap, evid, "fig17")
    ap.locator("saf-button", has_text="Confirmar e criar").last.click()
    ap.get_by_text(re.compile(r"criada com sucesso")).first.wait_for(timeout=90000)
    ap.wait_for_timeout(1500)
    rt.shot(ap, evid, "fig18")
    _log(log, "Sessão de conciliação criada. Aguardando processamento...")


def _documentos_sem_inconsistencias(ap, evid, log):
    link = ap.locator("saf-anchor, a, saf-button").filter(has_text=re.compile(r"sem inconsist", re.I)).first
    if not link.count():
        link = ap.get_by_text(re.compile(r"documentos? sem inconsist", re.I)).first
    if not link.count():
        _log(log, "Conciliação: link de documentos sem inconsistências não disponível.")
        return
    try:
        link.scroll_into_view_if_needed(timeout=5000)
        ap.wait_for_timeout(800)
        rt.shot(ap, evid, "fig19", destaques=[link])
        url_antes = ap.url
        link.click(timeout=10000)
        ap.wait_for_timeout(6000)
        if ap.url == url_antes:
            _log(log, "Conciliação: documentos sem inconsistências não abriu (provavelmente não há documentos).")
            return
        rt.shot(ap, evid, "fig20")
        ap.go_back(wait_until="commit")
        ap.wait_for_timeout(7000)
        ap.locator("saf-button", has_text="Visualizar inconsistências").first.wait_for(timeout=60000)
    except Exception as e:
        _log(log, f"Conciliação: não foi possível registrar documentos sem inconsistências ({str(e).splitlines()[0][:80]}).")


def _abrir_acordeao(ap, titulo, log):
    alvos = ap.get_by_text(titulo, exact=True).filter(visible=True)
    if not alvos.count():
        return False
    alvo, motivo = alvos.first, ""
    for estrategia in range(3):
        try:
            alvo.scroll_into_view_if_needed(timeout=3000)
            if estrategia == 0:
                alvo.click(timeout=4000)
            elif estrategia == 1:
                alvo.click(timeout=4000, force=True)
            else:
                alvo.dispatch_event("click")
            ap.wait_for_timeout(1500)
            return True
        except Exception as e:
            motivo = " ".join(str(e).split())[:160]
    _log(log, f"Conciliação: não consegui abrir \"{titulo}\" ({motivo}).")
    return False


def _detalhes_por_tributo(ap, evid, log):
    try:
        _rolar(ap, "Detalhes")
        for titulo in ("Inconsistências nos débitos", "Inconsistências nos créditos"):
            _abrir_acordeao(ap, titulo, log)
        cartao = ap.get_by_text("Detalhes", exact=True).first.locator(
            "xpath=ancestor::*[.//*[normalize-space(text())='Inconsistências nos débitos']][1]")
        existe = cartao.count() > 0
        rt.shot(ap, evid, "fig24", destaques=[cartao.first] if existe else None)
        return cartao.first.inner_text(timeout=3000).strip()[:4000] if existe else ""
    except Exception as e:
        _log(log, f"Conciliação: não foi possível detalhar as inconsistências por tributo ({str(e).splitlines()[0][:80]}).")
        return ""


def gerar_conciliacao(usuario, senha, empresa, periodo, destino_dir, log=None, criar=True, timeout_sessao=1800,
                      evid_dir=None, ambiente="QA", tela_real=False, acesso=None):
    rt.definir_ambiente(ambiente)
    rt.definir_evidencias(evid_dir)
    rt.definir_tela_real(tela_real)
    rt.definir_acesso(acesso, usuario)
    mes, ano = int(periodo[:2]), periodo[3:]
    os.makedirs(destino_dir, exist_ok=True)
    with sync_playwright() as p:
        b, ctx, pg = _sessao(p, usuario, senha, log)
        try:
            ap = _abrir_modulo_rt(pg, ctx, empresa, "Conciliação Fiscal", log, evid_dir, "fig13")
            url_painel = ap.url
            filial = _filtros_conciliacao(ap, empresa, mes, ano, log)
            rt.shot(ap, evid_dir, "fig14")
            _log(log, f"Conciliação: filial {filial}, competência {MESES[mes - 1]}/{ano}.")
            total_antes, _, _ = _historico(ap)
            if criar:
                _criar_sessao(ap, mes, ano, log, evid_dir)
                voltou = False
                try:
                    ap.locator("saf-anchor, a").filter(has_text=re.compile(r"^\s*Conciliação\s*$")).first.click(timeout=10000)
                    ap.locator("saf-select").first.wait_for(timeout=20000)
                    voltou = True
                except Exception:
                    pass
                if not voltou:
                    ap.goto(url_painel, wait_until="commit")
                ap.wait_for_timeout(8000)
                _filtros_conciliacao(ap, empresa, mes, ano, log, registrar=False)
                t0 = time.time()
                registrou = False
                while True:
                    total, execu, linha = _historico(ap)
                    st = linha.get("status", "")
                    if total > total_antes and execu == 0 and st.startswith("Conclu"):
                        break
                    if total > total_antes and re.search(r"Erro|Falha|Cancelad", st):
                        raise rt.ErroRobo(f"A sessão de conciliação terminou com status {st}.")
                    if time.time() - t0 > timeout_sessao:
                        raise rt.ErroRobo("Tempo esgotado aguardando a sessão de conciliação concluir.")
                    _log(log, f"Sessão de conciliação em processamento... ({st or 'aguardando'} {linha.get('pct', '')}%)")
                    if not registrou:
                        _rolar(ap, "Histórico das sessões")
                        rt.passo(ap, "Histórico – sessão de conciliação em processamento")
                        registrou = True
                    ap.wait_for_timeout(20000)
                    _pesquisar_conciliacao(ap)
                _log(log, "Sessão de conciliação concluída.")
                ap.evaluate("() => window.scrollTo(0, 0)")
                rt.passo(ap, "Painel da conciliação após a sessão concluída")

            t = _texto(ap)
            ultimo = re.search(r"Último período conciliado: \| ([^|]+)", t)
            if "Visualizar inconsistências" not in t:
                rt.passo(ap, "Conciliação sem dados de inconsistências para o período")
                _log(log, "Conciliação: o painel não trouxe dados para o período (sem documentos a conciliar).")
                resultado = {"filial": filial, "periodo": periodo, "ultima_sessao": ultimo.group(1).strip() if ultimo else "",
                             "totais": {"debitos": ("-", "-"), "creditos": ("-", "-")}, "arquivos": {}, "sem_dados": True}
                json.dump(resultado, open(os.path.join(destino_dir, "conciliacao.json"), "w", encoding="utf-8"),
                          ensure_ascii=False, indent=1)
                return resultado
            _documentos_sem_inconsistencias(ap, evid_dir, log)
            _rolar(ap, "Inconsistências")
            rt.shot(ap, evid_dir, "fig21")
            _rolar(ap, "Detalhes")
            rt.shot(ap, evid_dir, "fig24")
            _rolar(ap, "Histórico das sessões")
            rt.shot(ap, evid_dir, "fig25")
            ap.evaluate("() => window.scrollTo(0, 0)")

            def valor(bloco):
                m = re.search(rf"\| {bloco} \| Contribuinte \| Fisco \| Valor dos impostos\W+Total \| Contribuinte \| (R\$\s?[\d\.,]+|-) \| Fisco \| (R\$\s?[\d\.,]+|-)", t)
                return (m.group(1), m.group(2)) if m else ("-", "-")
            resultado = {"filial": filial, "periodo": periodo, "ultima_sessao": ultimo.group(1).strip() if ultimo else "",
                         "totais": {"debitos": valor("Débitos"), "creditos": valor("Créditos")}, "arquivos": {}}
            for idx, nome in ((1, "debitos"), (2, "creditos"), (0, "documentos")):
                botoes = ap.locator("saf-button", has_text="Visualizar inconsistências")
                if botoes.count() <= idx:
                    continue
                botoes.nth(idx).click()
                exp = ap.locator("saf-button", has_text="Exportar").first
                try:
                    exp.wait_for(timeout=45000)
                except Exception:
                    _log(log, f"Conciliação: sem inconsistências de {nome} para exportar.")
                    rt.passo(ap, f"Conciliação – sem inconsistências de {nome}")
                    if "/conciliation" in ap.url and ap.locator("saf-button", has_text="Visualizar inconsistências").count():
                        continue
                    ap.go_back(wait_until="commit")
                    ap.wait_for_timeout(7000)
                    continue
                ap.wait_for_timeout(4000)
                if nome in ("documentos", "debitos"):
                    rt.shot(ap, evid_dir, "fig22" if nome == "documentos" else "fig23")
                else:
                    rt.passo(ap, "Inconsistências nos créditos")
                for tentativa in range(3):
                    try:
                        with ap.expect_download(timeout=120000) as dl:
                            exp.click()
                        caminho = os.path.join(destino_dir, f"conciliacao_{nome}.csv")
                        dl.value.save_as(caminho)
                        resultado["arquivos"][nome] = caminho
                        _log(log, f"Conciliação: exportado {nome}.")
                        rt.passo(ap, f"Inconsistências de {nome} exportadas da Conciliação ({os.path.basename(caminho)})")
                        break
                    except Exception as e:
                        _log(log, f"Conciliação: exportação de {nome} não iniciou (tentativa {tentativa + 1}/3): "
                                  f"{str(e).splitlines()[0][:100]}")
                        ap.wait_for_timeout(5000)
                ap.go_back(wait_until="commit")
                ap.wait_for_timeout(7000)
                ap.locator("saf-button", has_text="Visualizar inconsistências").first.wait_for(timeout=60000)
            resultado["detalhes"] = _detalhes_por_tributo(ap, evid_dir, log)
            json.dump(resultado, open(os.path.join(destino_dir, "conciliacao.json"), "w", encoding="utf-8"),
                      ensure_ascii=False, indent=1)
            return resultado
        except rt.ErroRobo:
            raise
        except Exception as e:
            rt.registrar_falha(ctx, destino_dir, log)
            raise rt.ErroRobo(f"Falha na Conciliação: {rt.resumo_erro(e)}")
        finally:
            rt.encerrar(b)


CTB_MODULO = "Contabilização"
CTB_API = "/rtcontabilizacaoapi/v1/"


class _ApiCtb:
    def __init__(self, ap):
        self.itens = []
        ap.on("response", self._resposta)

    def _resposta(self, r):
        try:
            if CTB_API not in r.url or r.request.method != "GET" or r.request.resource_type not in ("xhr", "fetch"):
                return
            try:
                corpo = r.json()
            except Exception:
                corpo = None
            partes = urlsplit(r.url)
            self.itens.append({"caminho": partes.path, "status": r.status, "corpo": corpo,
                               "consulta": {k: v[0] for k, v in parse_qs(partes.query).items()}})
        except Exception:
            pass

    def marca(self):
        return len(self.itens)

    def achar(self, final, desde=0, **filtros):
        for it in reversed(self.itens[desde:]):
            if it["caminho"].endswith(final) and all(it["consulta"].get(k) == v for k, v in filtros.items()):
                return it
        return None


def _aguardar_api(ap, api, final, desde, segundos=30, **filtros):
    t0 = time.time()
    while time.time() - t0 < segundos:
        if api.achar(final, desde, **filtros):
            ap.wait_for_timeout(1200)
            return api.achar(final, desde, **filtros)
        ap.wait_for_timeout(400)
    return None


def _kpis_tela(ap):
    m = re.search(r"Não contabilizados \| (\d+) \| Contabilizados \| (\d+) \| Estornados \| (\d+) \| Total de lançamentos \| (\d+)",
                  _texto(ap))
    if not m:
        return None
    return {"nao_contabilizados": int(m.group(1)), "contabilizados": int(m.group(2)),
            "estornados": int(m.group(3)), "total": int(m.group(4))}


def _flt(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _item_saldo(x):
    return {"configuracao": x.get("nomeConfiguracao"), "natureza": x.get("natureza"),
            "apurado": _flt(x.get("apurado")), "contabilizado": _flt(x.get("contabilizado")),
            "saldo_disponivel": _flt(x.get("saldoDisponivel")), "pode_contabilizar": x.get("podeContabilizar"),
            "data_operacao": x.get("dataOperacao"), "conta": x.get("codContaContabil"),
            "contrapartida": x.get("codContaContrapart"), "periodo": x.get("periodo")}


def _itens_grade(ap):
    itens = []
    linhas = ap.locator('wj-flex-grid[aria-labelledby="lancamentos-table-header"] [role="row"]')
    for i in range(linhas.count()):
        cel = [re.sub(r"\s+", " ", t).strip() for t in linhas.nth(i).locator('[role="gridcell"]').all_text_contents()]
        if len(cel) >= 6 and "R$" in cel[5]:
            saldo = _num_br(cel[5]) or 0.0
            itens.append({"configuracao": cel[3], "natureza": "D" if cel[4].upper().startswith("D") else "C",
                          "apurado": saldo, "contabilizado": 0.0, "saldo_disponivel": saldo, "pode_contabilizar": None,
                          "data_operacao": cel[2], "conta": None, "contrapartida": None, "periodo": None})
    return itens


def _estabelecimentos_ctb(ap, segundos=60):
    t0 = time.time()
    while time.time() - t0 < segundos:
        est = ap.locator('saf-select[label="Estabelecimento"]').first
        try:
            ops = [t.strip() for t in est.locator("saf-option").all_text_contents() if t.strip() and "Selecionar" not in t]
        except Exception:
            ops = []
        if ops:
            return est, ops
        ap.wait_for_timeout(1500)
    raise rt.ErroRobo("A lista de estabelecimentos da Contabilização não carregou.")


def _competencia_ctb(ap, mes, ano):
    alvo = f"{MESES[mes - 1]} / {ano}"
    valor = ap.locator(".competencia-value").first
    try:
        if valor.inner_text(timeout=3000).strip() == alvo:
            return
    except Exception:
        pass
    ap.evaluate("window.scrollTo(0, 0)")
    _clicar_robusto(ap, ap.locator("#competencia-calendar-button").first, None, "Calendário da competência")
    ap.wait_for_timeout(900)
    ano_tela = ap.locator(".competencia-popover-year").first
    for _ in range(6):
        try:
            lido = ano_tela.inner_text(timeout=2000).strip()
        except Exception:
            break
        if lido == str(ano) or not lido.isdigit():
            break
        sentido = "Ano anterior" if int(lido) > int(ano) else "Próximo ano"
        botao = ap.locator(f'.competencia-popover-year-nav saf-button[a11y-aria-label="{sentido}"]').first
        if botao.get_attribute("disabled") is not None:
            raise rt.ErroRobo(f"A Contabilização não permite consultar o ano {ano} (a tela está no ano {lido}).")
        botao.click(timeout=5000)
        ap.wait_for_timeout(500)
    ap.locator(".competencia-popover-months saf-button", has_text=re.compile(rf"^\s*{MESES[mes - 1]}\s*$")).first.click(timeout=10000)
    ap.wait_for_timeout(1500)
    lido = valor.inner_text(timeout=5000).strip()
    if lido != alvo:
        raise rt.ErroRobo(f"A competência não ficou em {alvo} na Contabilização (a tela mostra {lido}).")
    rt.passo(ap, f"Contabilização – competência {alvo} selecionada")


def _grade_ctb(ap):
    return ap.locator('wj-flex-grid[aria-labelledby="lancamentos-table-header"]').first


def _sintetica_estab(ap, api, texto_estab, cod, ano_mes, evid_dir, primeiro, log):
    ap.evaluate("window.scrollTo(0, 0)")
    est = ap.locator('saf-select[label="Estabelecimento"]').first
    _selecionar(ap, est, texto_estab)
    if primeiro:
        rt.shot(ap, evid_dir, "fig28", destaques=[ap.locator('saf-select[label="Empresa"]').first, est,
                                                    ap.locator(".competencia-info").first])
    botao = ap.locator("saf-button", has_text=re.compile(r"^\s*Pesquisar\s*$")).filter(visible=True).first
    marca = api.marca()
    botao.click(timeout=10000)
    it = _aguardar_api(ap, api, "/saldos", marca, 40, codEstab=cod, tipoImposto="CBS", periodo=ano_mes)
    ap.wait_for_timeout(1500)
    dados = {"fonte": "api", "itens": [], "total": 0, "resumo": None, "kpis_tela": _kpis_tela(ap)}
    if it and it["status"] == 200 and isinstance(it["corpo"], dict):
        corpo = it["corpo"]
        dados["resumo"], dados["total"] = corpo.get("resumo"), int(corpo.get("total") or 0)
        brutos, pagina = list(corpo.get("items") or []), 1
        while len(brutos) < dados["total"] and pagina < 20:
            proximo = ap.locator("saf-button", has_text=re.compile(r"^\s*Próximo\s*$")).filter(visible=True).first
            if not proximo.count() or proximo.get_attribute("disabled") is not None:
                break
            pagina += 1
            marca = api.marca()
            proximo.click(timeout=8000)
            outra = _aguardar_api(ap, api, "/saldos", marca, 20, codEstab=cod, page=str(pagina))
            if not outra or not isinstance(outra["corpo"], dict):
                break
            brutos += outra["corpo"].get("items") or []
        dados["itens"] = [_item_saldo(x) for x in brutos]
    else:
        _log(log, f"Contabilização: o servidor não respondeu a consulta do estabelecimento {cod}; lendo a grade da tela.")
        dados["fonte"] = "tela"
        dados["itens"] = _itens_grade(ap)
        dados["total"] = len(dados["itens"])
    rt.passo(ap, f"Contabilização – visão sintética do estabelecimento {cod} ({len(dados['itens'])} configuração(ões) com saldo)")
    if primeiro:
        ap.evaluate("window.scrollTo(0, 0)")
        rt.shot(ap, evid_dir, "fig32", full=True, destaques=[ap.locator(".kpi-strip").first, _grade_ctb(ap)])
    return dados


def _exportar_grade(ap, caminho, rotulo, log, evid_dir=None, fig=None):
    formato = ap.get_by_text("Selecione o formato", exact=True).first
    for tentativa in range(3):
        try:
            ap.locator('saf-radio[value="CSV"]').first.evaluate("e => e.click()")
            ap.wait_for_timeout(800)
            exp = ap.locator("saf-button", has_text=re.compile(r"^\s*Exportar\s*$")).filter(visible=True).first
            exp.evaluate("e => e.scrollIntoView({block: 'center'})")
            ap.wait_for_timeout(500)
            if fig and tentativa == 0:
                rt.shot(ap, evid_dir, fig, full=True, destaques=[formato, exp])
            with ap.expect_download(timeout=90000) as dl:
                exp.click(timeout=15000)
            dl.value.save_as(caminho)
            rt.passo(ap, f"Contabilização – {rotulo} exportados ({os.path.basename(caminho)})")
            return True
        except Exception as e:
            _log(log, f"Contabilização: exportação de {rotulo} não iniciou (tentativa {tentativa + 1}/3): "
                      f"{str(e).splitlines()[0][:100]}")
            ap.wait_for_timeout(4000)
    return False


def _analitica(ap, api, ano_mes, destino_dir, evid_dir, log):
    out = {"kpis_tela": None, "linhas_tela": 0, "total": 0, "arquivo": None}
    ap.evaluate("window.scrollTo(0, 0)")
    marca = api.marca()
    ap.locator("saf-button", has_text=re.compile(r"Vis.o anal.tica")).first.click(timeout=10000)
    _aguardar_api(ap, api, "/lancamentos", marca, 25, periodo=ano_mes, tipoImposto="CBS")
    ap.wait_for_timeout(2500)
    out["kpis_tela"] = _kpis_tela(ap)
    m = re.search(r"Exibindo (\d+) a (\d+) de (\d+)", _texto(ap))
    out["linhas_tela"] = int(m.group(3)) if m else 0
    out["total"] = out["kpis_tela"]["total"] if out["kpis_tela"] else out["linhas_tela"]
    rt.shot(ap, evid_dir, "fig33", full=True, destaques=[ap.locator(".kpi-strip").first, _grade_ctb(ap)])
    if out["total"] or out["linhas_tela"]:
        caminho = os.path.join(destino_dir, "lancamentos.csv")
        if _exportar_grade(ap, caminho, "lançamentos", log, evid_dir, "fig34"):
            out["arquivo"] = caminho
        else:
            raise rt.ErroRobo("Não foi possível exportar os lançamentos da visão analítica.")
    else:
        _log(log, "Contabilização: nenhum lançamento contábil gerado na competência — nada a exportar da visão analítica.")
        rt.passo(ap, "Contabilização – visão analítica sem lançamentos na competência")
    return out


def _configuracoes(ap, api, destino_dir, evid_dir, log):
    out = {"arquivo": None, "linhas_tela": 0, "visualizada": False}
    ap.evaluate("window.scrollTo(0, 0)")
    marca = api.marca()
    ap.locator("saf-button", has_text=re.compile(r"^\s*Configurar\s*$")).first.click(timeout=10000)
    t0 = time.time()
    while "/configuracoes" not in ap.url and time.time() - t0 < 30:
        ap.wait_for_timeout(500)
    if "/configuracoes" not in ap.url:
        raise rt.ErroRobo("A tela Configurações da Contabilização não abriu.")
    _aguardar_api(ap, api, "/configuracoes-contabeis", marca, 30)
    ap.wait_for_timeout(2500)
    m = re.search(r"Exibindo (\d+) a (\d+) de (\d+)", _texto(ap))
    out["linhas_tela"] = int(m.group(3)) if m else 0
    rt.shot(ap, evid_dir, "fig29", full=True, destaques=[ap.locator("wj-flex-grid").filter(visible=True).first])
    olho = ap.locator('saf-button[a11y-aria-label="Visualizar configuração"]').filter(visible=True)
    if olho.count():
        try:
            olho.first.evaluate("e => e.scrollIntoView({block: 'center'})")
            olho.first.click(timeout=10000)
            dialogo = ap.locator("saf-dialog").filter(visible=True).first
            _esperar(ap, dialogo, 15)
            ap.wait_for_timeout(2000)
            rt.shot(ap, evid_dir, "fig30", destaques=[dialogo])
            out["visualizada"] = True
        finally:
            cancelar = ap.locator("saf-dialog").filter(visible=True).locator(
                "saf-button", has_text=re.compile(r"^\s*Cancelar\s*$")).first
            if cancelar.count():
                cancelar.click(timeout=10000)
                ap.wait_for_timeout(1500)
    if out["linhas_tela"]:
        caminho = os.path.join(destino_dir, "configuracoes.csv")
        if _exportar_grade(ap, caminho, "configurações", log, evid_dir, "fig31"):
            out["arquivo"] = caminho
    return out


def _ctb_principal(ap, base):
    for _ in range(2):
        try:
            cancelar = ap.locator("saf-dialog").filter(visible=True).locator(
                "saf-button", has_text=re.compile(r"^\s*Cancelar\s*$")).first
            if cancelar.count():
                cancelar.click(timeout=5000)
                ap.wait_for_timeout(1000)
            if _caminho(ap) != base:
                ap.go_back(wait_until="commit")
                ap.wait_for_timeout(5000)
        except Exception:
            pass
        if _caminho(ap) == base:
            break
    if _caminho(ap) != base:
        ap.goto(urlsplit(ap.url)._replace(path=base, query="", fragment="").geturl(), wait_until="commit")
        ap.wait_for_timeout(6000)
    return _estabelecimentos_ctb(ap)


def _bloco_ctb(ap, res, evid_dir, log, nome, fn, *args):
    try:
        return fn(*args)
    except rt.ErroRobo as e:
        motivo = str(e)
    except Exception as e:
        if ap.is_closed():
            raise
        motivo = "falha inesperada: " + str(e).splitlines()[0][:150]
    res["falhas"].append(f"{nome}: {motivo}")
    _log(log, f"ATENÇÃO — Contabilização, {nome}: {motivo}")
    _diagnostico(ap, evid_dir, "CTB", nome.replace(" ", "_"), motivo, "Contabilização")
    return None


def _gravar_ctb(res, destino_dir):
    with open(os.path.join(destino_dir, "contabilizacao.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1, default=str)


def gerar_contabilizacao(usuario, senha, empresa, periodo, destino_dir, log=None, evid_dir=None, ambiente="QA", tela_real=False,
                         acesso=None):
    rt.definir_ambiente(ambiente)
    rt.definir_evidencias(evid_dir)
    rt.definir_tela_real(tela_real)
    rt.definir_acesso(acesso, usuario)
    mes, ano = int(periodo[:2]), int(periodo[3:])
    ano_mes = f"{ano}-{mes:02d}"
    cod = rt_cod(empresa)
    os.makedirs(destino_dir, exist_ok=True)
    res = {"empresa": cod, "periodo": periodo, "competencia": ano_mes, "disponivel": False, "aviso": "", "abas": {},
           "estabelecimentos": [], "sintetica": {}, "analitica": {}, "configuracoes": {}, "falhas": []}
    with sync_playwright() as p:
        b, ctx, pg = _sessao(p, usuario, senha, log)
        try:
            try:
                ap = _abrir_modulo_rt(pg, ctx, empresa, CTB_MODULO, log, evid_dir, "fig27")
            except rt.ErroRobo as e:
                if "Módulo" in str(e) and "não encontrado" in str(e):
                    res["aviso"] = ("O módulo Contabilização não está disponível para esta empresa ou usuário "
                                    "(depende de licenciamento prévio e de permissão de acesso).")
                    _log(log, "ATENÇÃO — " + res["aviso"])
                    _gravar_ctb(res, destino_dir)
                    return res
                raise
            if "/portal/rt/contabilizacao" not in ap.url:
                raise rt.ErroRobo(f"O módulo Contabilização não abriu (parou em {ap.url[:80]}).")
            res["disponivel"] = True
            api, base = _ApiCtb(ap), _caminho(ap)
            emp = ap.locator('saf-select[label="Empresa"]').first
            if (emp.get_attribute("current-value") or "").strip() != cod:
                _selecionar(ap, emp, re.compile(rf"^\s*{re.escape(cod)}\s*-"))
            est, estabs = _estabelecimentos_ctb(ap)
            codigos = [e.split(" - ")[0].strip() for e in estabs]
            res["estabelecimentos"] = codigos
            _log(log, f"Contabilização aberta. Estabelecimentos: {', '.join(codigos)}. Abrindo as configurações contábeis...")
            _selecionar(ap, est, estabs[0])
            res["configuracoes"] = _bloco_ctb(ap, res, evid_dir, log, "configurações", _configuracoes, ap, api,
                                              destino_dir, evid_dir, log) or {}
            est, estabs = _ctb_principal(ap, base)
            codigos = [e.split(" - ")[0].strip() for e in estabs]
            res["estabelecimentos"] = codigos
            _competencia_ctb(ap, mes, ano)
            for i, texto in enumerate(estabs):
                _log(log, f"Contabilização: consultando o saldo de CBS do estabelecimento {codigos[i]} em {periodo}...")
                dados = _bloco_ctb(ap, res, evid_dir, log, f"visão sintética {codigos[i]}", _sintetica_estab, ap, api,
                                   texto, codigos[i], ano_mes, evid_dir, i == 0, log)
                if dados is not None:
                    res["sintetica"][codigos[i]] = dados
                if i == 0 and dados is not None:
                    for imp in IMPOSTOS:
                        aba = _tab(ap, imp)
                        res["abas"][imp] = bool(aba.count()) and aba.get_attribute("disabled") is None
                    off = [k for k, v in res["abas"].items() if not v]
                    if off:
                        _log(log, f"Contabilização: aba(s) {', '.join(off)} desabilitada(s) no produto — ignorada(s).")
            if len(estabs) > 1:
                _bloco_ctb(ap, res, evid_dir, log, "estabelecimento", _selecionar, ap, est, estabs[0])
            _log(log, "Contabilização: abrindo a visão analítica...")
            res["analitica"] = _bloco_ctb(ap, res, evid_dir, log, "visão analítica", _analitica, ap, api, ano_mes,
                                          destino_dir, evid_dir, log) or {}
            if not res["sintetica"] and not res["analitica"]:
                raise rt.ErroRobo("Nenhum dado foi coletado da Contabilização. " + "; ".join(res["falhas"]))
            _gravar_ctb(res, destino_dir)
            _log(log, "Contabilização coletada: " + ", ".join(
                f"{c}: {len(d['itens'])} saldo(s)" for c, d in res["sintetica"].items()))
            return res
        except rt.ErroRobo:
            raise
        except Exception as e:
            rt.registrar_falha(ctx, destino_dir, log)
            raise rt.ErroRobo(f"Falha na Contabilização: {rt.resumo_erro(e)}")
        finally:
            rt.encerrar(b)


def rt_cod(empresa):
    return (empresa or "").split(" - ")[0].strip()
