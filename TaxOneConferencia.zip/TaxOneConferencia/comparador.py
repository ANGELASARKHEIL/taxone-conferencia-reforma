import difflib
import json
import os
import re
from decimal import Decimal, InvalidOperation

import pandas as pd

AQUI = os.path.dirname(os.path.abspath(__file__))
LAYOUTS = json.load(open(os.path.join(AQUI, "layouts.json"), encoding="utf-8"))

CHAVE_DOC = ["COD_EMPRESA", "COD_ESTAB", "DATA_FISCAL", "DAT_FISCAL", "MOVTO_E_S", "NORM_DEV", "COD_DOCTO",
             "COD_FIS_JUR", "NUM_DOCFIS", "SERIE_DOCFIS", "SUB_SERIE_DOCFIS"]
CHAVE_ITEM = ["NUM_ITEM"]
CABECALHOS = {"SAFX3007", "SAFX3042"}
RELATORIO_DA_SAFX = {"SAFX3007": "fiscais", "SAFX3008": "fiscais", "SAFX3009": "fiscais",
                     "SAFX3042": "utilities", "SAFX3043": "utilities"}
ALIAS_FIXOS = {"DATA_FISCAL": ["DAT_FISCAL"], "DAT_FISCAL": ["DATA_FISCAL"]}


def _ler_texto(caminho):
    raw = open(caminho, "rb").read()
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace")


def ler_relatorio(caminho):
    txt = _ler_texto(caminho)
    linhas = [l for l in txt.splitlines() if l.strip()]
    if not linhas:
        return pd.DataFrame()
    cab = _unicos([c.strip() for c in linhas[0].split("\t")])
    dados = [l.split("\t") for l in linhas[1:]]
    dados = [(d + [""] * len(cab))[:len(cab)] for d in dados]
    df = pd.DataFrame(dados, columns=cab).apply(lambda s: s.str.strip())
    if "SEQ_DOC" in df.columns and "ORIGEM SAFX" in df.columns and len(df):
        chaves = [c for c in dict.fromkeys(CHAVE_DOC + ["GRUPO_FIS_JUR"]) if c in df.columns]
        cab_mask = df["ORIGEM SAFX"].isin(CABECALHOS)
        base = df[cab_mask].drop_duplicates("SEQ_DOC").set_index("SEQ_DOC")[chaves]
        for c in chaves:
            vazio = df[c] == ""
            if vazio.any() and len(base):
                df.loc[vazio, c] = df.loc[vazio, "SEQ_DOC"].map(base[c].to_dict()).fillna("")
    return df


def identificar_safx(nome_arquivo, primeira_linha=""):
    m = re.search(r"30(07|08|09|42|43)", os.path.basename(nome_arquivo))
    if m:
        return "SAFX30" + m.group(1)
    return None


def _unicos(cols):
    vistos, out = {}, []
    for c in cols:
        vistos[c] = vistos.get(c, 0) + 1
        out.append(c if vistos[c] == 1 else f"{c}_{vistos[c]}")
    return out


def ler_safx(caminho, tipo):
    campos = [c["campo"] for c in LAYOUTS[tipo]["campos"]]
    ext = os.path.splitext(caminho)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        df = pd.read_excel(caminho, dtype=str, header=None).fillna("")
        linhas = df.values.tolist()
    else:
        txt = _ler_texto(caminho)
        brutas = [l for l in txt.splitlines() if l.strip()]
        amostra = brutas[0] if brutas else ""
        sep = "\t" if "\t" in amostra else (";" if amostra.count(";") >= 5 else ("|" if "|" in amostra else "\t"))
        linhas = [l.split(sep) for l in brutas]
        if sep == "|":
            linhas = [l[1:-1] if l and l[0] == "" and l[-1] == "" else l for l in linhas]
    if not linhas:
        return pd.DataFrame(columns=campos), False
    primeira = [str(x).strip().upper() for x in linhas[0]]
    tem_cabecalho = "COD_EMPRESA" in primeira
    if tem_cabecalho:
        cols = primeira
        linhas = linhas[1:]
    else:
        cols = list(campos)
        amostra = [str(l[2]).strip() for l in linhas[:200] if len(l) > 2]
        if "DATA_FISCAL" not in cols and "DAT_FISCAL" not in cols and amostra and \
                sum(bool(re.fullmatch(r"(19|20)\d{6}", v)) for v in amostra) >= 0.9 * len(amostra):
            cols.insert(2, "DATA_FISCAL")
        maior = max(len(l) for l in linhas)
        cols += [f"CAMPO_EXTRA_{i + 1}" for i in range(maior - len(cols))]
    cols = _unicos(cols)
    n = len(cols)
    linhas = [([str(x) for x in l] + [""] * n)[:n] for l in linhas]
    df = pd.DataFrame(linhas, columns=cols).apply(lambda s: s.str.strip())
    df = df.mask(df == "@", "")
    df.insert(0, "_LINHA", range(2 if tem_cabecalho else 1, len(df) + (2 if tem_cabecalho else 1)))
    return df, tem_cabecalho


COLUNAS_META = {"ORIGEM SAFX", "SEQ_DOC"}
DECIMAIS_TESTE = (0, 2, 4, 6, 3, 5, 7, 8)
AMOSTRA_ALINHAMENTO = 3000


def _canon(v):
    if v is None or (isinstance(v, float) and v != v):
        return ""
    v = str(v).strip()
    if v in ("", "@"):
        return ""
    if re.fullmatch(r"(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])", v):
        return f"{v[:4]}-{v[4:6]}-{v[6:]}"
    m = re.fullmatch(r"(\d{2})/(\d{2})/(\d{4})(?:\s.*)?", v)
    if m:
        return f"{m.group(3)}-{m.group(2)}-{m.group(1)}"
    s = v.replace(" ", "")
    neg = s.startswith("-") or s.endswith("-")
    s = s.strip("-+")
    if re.fullmatch(r"\d{1,3}(\.\d{3})*,\d+|\d+,\d+", s):
        s = s.replace(".", "").replace(",", ".")
    if re.fullmatch(r"\d+(\.\d+)?", s):
        d = Decimal(s).normalize()
        txt = format(d, "f")
        if "." in txt:
            txt = txt.rstrip("0").rstrip(".")
        if txt in ("0", "-0"):
            return "0"
        return ("-" if neg else "") + txt
    return v.upper()


def _escalar(c, dec):
    if not dec or not c or c.startswith(("19", "20")) and "-" in c:
        return c
    if not re.fullmatch(r"-?\d+", c):
        return c
    d = (Decimal(c) / (Decimal(10) ** dec)).normalize()
    txt = format(d, "f")
    if "." in txt:
        txt = txt.rstrip("0").rstrip(".")
    return "0" if txt in ("0", "-0") else txt


def _trivial(c):
    return c in ("", "0")


def _iguais(a, b):
    return a == b or (_trivial(a) and _trivial(b))


def _alinhar(pares_safx, pares_rel, colunas_safx, colunas_rel, chave, nomes_cabecalho):
    """Descobre, pelos próprios dados, qual coluna do relatório corresponde a cada posição da SAFX."""
    rel_vals = {c: [r[c] for r in pares_rel] for c in colunas_rel}
    rel_sets = {c: set(v) - {"", "0"} for c, v in rel_vals.items()}
    rel_nt = {c: [i for i, v in enumerate(vs) if not _trivial(v)] for c, vs in rel_vals.items()}
    candidatos, info = [], {}
    for col in colunas_safx:
        if col in chave:
            continue
        sv = [s[col] for s in pares_safx]
        idx = [i for i, v in enumerate(sv) if not _trivial(v)]
        if len(idx) < 3:
            continue
        distintos = len({sv[i] for i in idx})
        numerico = all(re.fullmatch(r"-?\d+", sv[i]) for i in idx[:200])
        decs = DECIMAIS_TESTE if numerico else (0,)
        achou = False
        for dec in decs:
            esc_todos = [_escalar(v, dec) for v in sv]
            amostra = {esc_todos[i] for i in idx[:50]}
            for rc in colunas_rel:
                if not (amostra & rel_sets[rc]):
                    continue
                rv = rel_vals[rc]
                taxa = sum(1 for i in idx if esc_todos[i] == rv[i]) / len(idx)
                if taxa < 0.9:
                    continue
                nt = rel_nt[rc]
                cobertura = sum(1 for i in nt if esc_todos[i] == rv[i]) / len(nt) if nt else 0
                if distintos == 1 and col != rc and difflib.SequenceMatcher(None, col, rc).ratio() < 0.6 and not nomes_cabecalho:
                    info.setdefault(col, {"status": "valor constante, correspondência incerta", "exemplo": sv[idx[0]], "coluna": rc})
                    continue
                nota = (round(min(taxa, cobertura), 3), round(taxa, 3), 1 if col == rc else 0,
                        difflib.SequenceMatcher(None, col, rc).ratio(), -dec)
                candidatos.append((nota, col, rc, dec, taxa, sv[idx[0]]))
                achou = True
        if not achou and col not in info:
            info[col] = {"status": "sem correspondência", "exemplo": sv[idx[0]]}
    mapa, usadas = {}, set()
    for nota, col, rc, dec, taxa, ex in sorted(candidatos, key=lambda x: x[0], reverse=True):
        if col in mapa or rc in usadas:
            continue
        mapa[col] = (rc, dec)
        usadas.add(rc)
        info[col] = {"status": "alinhado", "coluna": rc, "decimais": dec, "taxa": taxa, "exemplo": ex}
    for nota, col, rc, dec, taxa, ex in candidatos:
        if col not in mapa:
            info[col] = {"status": "coluna já usada por outra posição com melhor correspondência", "coluna": rc, "exemplo": ex}
    return mapa, info


def confrontar(arquivos_safx, relatorio_fiscais, relatorio_utilities, saida_xlsx, periodo=None,
               saida_nao_encontrados=None):
    relatorios = {}
    if relatorio_fiscais and os.path.exists(relatorio_fiscais):
        relatorios["fiscais"] = ler_relatorio(relatorio_fiscais)
    if relatorio_utilities and os.path.exists(relatorio_utilities):
        relatorios["utilities"] = ler_relatorio(relatorio_utilities)

    resumo, divergencias, nao_integrados, so_taxone, mapeamento = [], [], [], [], []
    nao_enc_registros = {}
    mm_aaaa = f"{periodo[3:]}-{periodo[:2]}" if periodo and re.fullmatch(r"\d{2}/\d{4}", periodo) else None

    for caminho in arquivos_safx:
        nome = os.path.basename(caminho)
        tipo = identificar_safx(nome)
        if not tipo:
            resumo.append({"Arquivo": nome, "SAFX": "?", "Status": "Não identificado (o nome deve conter 3007, 3008, 3009, 3042 ou 3043)"})
            continue
        safx, tem_cab = ler_safx(caminho, tipo)
        rel = relatorios.get(RELATORIO_DA_SAFX[tipo], pd.DataFrame())
        rel_tipo = rel[rel["ORIGEM SAFX"] == tipo] if len(rel) and "ORIGEM SAFX" in rel.columns else pd.DataFrame()
        colunas_safx = [c for c in safx.columns if c != "_LINHA"]
        colunas_rel = [c for c in rel.columns if c not in COLUNAS_META] if len(rel) else []

        chave_safx_cols = [c for c in CHAVE_DOC if c in colunas_safx]
        if tipo not in CABECALHOS:
            chave_safx_cols += [c for c in CHAVE_ITEM if c in colunas_safx]
        par_chave = {}
        for c in chave_safx_cols:
            alvo = c if c in colunas_rel else next((a for a in ALIAS_FIXOS.get(c, []) if a in colunas_rel), None)
            if alvo:
                par_chave[c] = alvo
        chave = list(par_chave)
        if not chave or rel_tipo.empty:
            resumo.append({"Arquivo": nome, "SAFX": tipo, "Registros na SAFX": len(safx),
                           "Status": "Sem relatório para esta SAFX" if rel_tipo.empty else "Sem campos-chave para cruzar"})
            continue

        canon_safx = [{c: _canon(v) for c, v in zip(colunas_safx, linha)} for linha in safx[colunas_safx].itertuples(index=False)]
        canon_rel = [{c: _canon(v) for c, v in zip(colunas_rel, linha)} for linha in rel_tipo[colunas_rel].itertuples(index=False)]
        idx_rel = {}
        for i, r in enumerate(canon_rel):
            idx_rel.setdefault(tuple(r[par_chave[c]] for c in chave), []).append(i)

        pares_s, pares_r = [], []
        for s in canon_safx:
            rr = idx_rel.get(tuple(s[c] for c in chave))
            if rr:
                pares_s.append(s)
                pares_r.append(canon_rel[rr[0]])
                if len(pares_s) >= AMOSTRA_ALINHAMENTO:
                    break
        mapa, info = _alinhar(pares_s, pares_r, colunas_safx, colunas_rel, chave, tem_cab)
        posicao = {c: i + 1 for i, c in enumerate(colunas_safx)}
        for c in colunas_safx:
            if c in chave:
                mapeamento.append({"SAFX": tipo, "Posição": posicao[c], "Campo (layout)": c, "Coluna no relatório": par_chave[c],
                                   "Situação": "chave do cruzamento"})
            elif c in info:
                i = info[c]
                mapeamento.append({"SAFX": tipo, "Posição": posicao[c], "Campo (layout)": c,
                                   "Coluna no relatório": i.get("coluna", ""), "Casas decimais": i.get("decimais", ""),
                                   "Concordância": f"{i['taxa']:.0%}" if "taxa" in i else "",
                                   "Situação": {"alinhado": "comparado"}.get(i["status"], "não comparado – " + i["status"]),
                                   "Exemplo SAFX": i.get("exemplo", "")})

        tot = encontrados = com_div = fora = 0
        pos_chave = [colunas_safx.index(c) for c in chave]
        usados = set()
        brutos = safx[colunas_safx].values.tolist()
        for linha_n, s, bruto in zip(safx["_LINHA"], canon_safx, brutos):
            tot += 1
            k = tuple(s[c] for c in chave)
            rr = idx_rel.get(k)
            k_txt = " | ".join(f"{c}={str(bruto[i]).strip()}" for c, i in zip(chave, pos_chave))
            if not rr:
                status = "Não encontrado no TAX ONE"
                data = next((s[c] for c in ("DATA_FISCAL", "DAT_FISCAL") if c in s and s[c]), "")
                if mm_aaaa and data and not data.startswith(mm_aaaa):
                    status = "Fora do período do relatório"
                    fora += 1
                nao_integrados.append({"SAFX": tipo, "Arquivo": nome, "Linha": linha_n, "Chave": k_txt, "Status": status})
                reg = {"Arquivo": nome, "Linha": linha_n, "Status": status}
                reg.update(dict(zip(colunas_safx, bruto)))
                nao_enc_registros.setdefault(tipo, []).append(reg)
                continue
            encontrados += 1
            usados.add(k)
            r = canon_rel[rr[0]]
            teve = False
            for c, (rc, dec) in mapa.items():
                vs, vr = _escalar(s[c], dec), r[rc]
                if not _iguais(vs, vr):
                    teve = True
                    divergencias.append({"SAFX": tipo, "Linha": linha_n, "Chave": k_txt, "Posição": posicao[c],
                                         "Campo": rc, "Valor SAFX": vs.replace(".", ","), "Valor TAX ONE": vr.replace(".", ",")})
            if len(rr) > 1:
                teve = True
                divergencias.append({"SAFX": tipo, "Linha": linha_n, "Chave": k_txt, "Posição": "", "Campo": "(chave)",
                                     "Valor SAFX": "1 registro", "Valor TAX ONE": f"{len(rr)} registros com a mesma chave"})
            com_div += teve

        for k, rr in idx_rel.items():
            if k not in usados:
                linha_rel = rel_tipo.iloc[rr[0]]
                so_taxone.append({"SAFX": tipo, "Chave": " | ".join(f"{c}={linha_rel[par_chave[c]]}" for c in chave),
                                  "SEQ_DOC": linha_rel.get("SEQ_DOC", "")})

        resumo.append({
            "Arquivo": nome, "SAFX": tipo, "Status": "Confrontado",
            "Registros na SAFX": tot, "Encontrados no TAX ONE": encontrados,
            "Não encontrados": tot - encontrados - fora, "Fora do período": fora,
            "Com divergência": com_div, "OK": encontrados - com_div,
            "Registros no relatório (origem)": len(rel_tipo), "Só no TAX ONE": sum(1 for k in idx_rel if k not in usados),
            "Campos comparados": len(mapa), "Chave usada": ", ".join(chave),
            "Cabeçalho no arquivo": "Sim" if tem_cab else "Não (posições do arquivo)",
        })

    os.makedirs(os.path.dirname(saida_xlsx), exist_ok=True)
    with pd.ExcelWriter(saida_xlsx, engine="openpyxl") as xw:
        pd.DataFrame(resumo).to_excel(xw, sheet_name="Resumo", index=False)
        pd.DataFrame(divergencias or [{"Resultado": "Nenhuma divergência encontrada"}]).to_excel(xw, sheet_name="Divergências", index=False)
        pd.DataFrame(nao_integrados or [{"Resultado": "Todos os registros foram encontrados"}]).to_excel(xw, sheet_name="Não integrados", index=False)
        pd.DataFrame(so_taxone or [{"Resultado": "Nenhum"}]).to_excel(xw, sheet_name="Só no TAX ONE", index=False)
        pd.DataFrame(mapeamento or [{"Resultado": "Sem mapeamento"}]).to_excel(xw, sheet_name="Mapeamento de campos", index=False)
        _ajustar_planilhas(xw)
    if saida_nao_encontrados:
        with pd.ExcelWriter(saida_nao_encontrados, engine="openpyxl") as xw:
            if nao_enc_registros:
                for tipo in sorted(nao_enc_registros):
                    pd.DataFrame(nao_enc_registros[tipo]).to_excel(xw, sheet_name=tipo, index=False)
            else:
                pd.DataFrame([{"Resultado": "Todos os registros das SAFX foram encontrados no TAX ONE"}]).to_excel(
                    xw, sheet_name="Resultado", index=False)
            _ajustar_planilhas(xw)
    return {"resumo": resumo, "divergencias": len(divergencias), "nao_integrados": len(nao_integrados),
            "so_taxone": len(so_taxone), "saida": saida_xlsx, "saida_nao_encontrados": saida_nao_encontrados}


def _ajustar_planilhas(xw):
    for ws in xw.book.worksheets:
        ws.freeze_panes = "A2"
        for col in ws.columns:
            larg = max(len(str(c.value or "")) for c in list(col)[:200])
            ws.column_dimensions[col[0].column_letter].width = min(max(10, larg + 2), 70)
