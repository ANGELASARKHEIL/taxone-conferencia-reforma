param(
  [string]$Python = "",
  [string[]]$Modulos = @("flask", "pandas", "openpyxl", "playwright", "docx", "PIL"),
  [switch]$Detalhado
)
$aqui = Split-Path -Parent $MyInvocation.MyCommand.Path
$erros = 0
$avisos = 0

function Linha($estado, $texto, $dica) {
  if ($estado -eq "AVISO") { $script:avisos++ }
  if (-not $Detalhado -and $estado -eq "OK") { return }
  $cor = @{ OK = "Green"; AVISO = "Yellow"; ERRO = "Red" }[$estado]
  Write-Host ("  [{0}] {1}" -f $estado.PadRight(5), $texto) -ForegroundColor $cor
  if ($dica) { Write-Host ("          {0}" -f $dica) }
}

if ($Detalhado) {
  Write-Host ""
  Write-Host "Conferindo o ambiente..."
}

if (-not $Python) { $Python = $env:TAXONE_PYTHON }
$versao = $null
if ($Python -and (Test-Path $Python)) {
  $versao = (& $Python -c "import sys; print('%d.%d.%d' % sys.version_info[:3])" 2>$null)
}
if ($versao) {
  Linha "OK" "Python $versao"
} else {
  $erros++
  Linha "ERRO" "Python nao encontrado" "Abra o instalador de novo."
}

if ($versao) {
  $lista = $Modulos -join ", "
  & $Python -c "import $lista" 2>$null
  if ($LASTEXITCODE -eq 0) {
    Linha "OK" "Componentes da ferramenta instalados"
  } else {
    $erros++
    Linha "ERRO" "Faltam componentes da ferramenta" "Autentique o ZScaler e abra o instalador de novo."
  }
  & $Python -c "import win32com.client" 2>$null
  if ($LASTEXITCODE -eq 0) {
    Linha "OK" "Automacao do Word disponivel"
  } else {
    Linha "AVISO" "Automacao do Word indisponivel" "O plano sai igual; o sumario so atualiza quando o Word abrir o arquivo."
  }
}

$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") |
  Where-Object { Test-Path $_ } | Select-Object -First 1
if ($edge) {
  Linha "OK" "Microsoft Edge encontrado"
} else {
  $erros++
  Linha "ERRO" "Microsoft Edge nao encontrado" "O robo usa o Edge instalado no Windows."
}

$word = (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\winword.exe") -or (Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\winword.exe")
if ($word) {
  Linha "OK" "Microsoft Word encontrado"
} else {
  Linha "AVISO" "Microsoft Word nao encontrado" "Voce vai precisar dele para abrir o plano de teste."
}

try {
  $r = Invoke-WebRequest -Uri "https://uat.onesourcetax.com" -Method Head -TimeoutSec 20 -UseBasicParsing
  Linha "OK" ("TAX ONE UAT acessivel (HTTP {0})" -f $r.StatusCode)
} catch {
  if ($_.Exception.Response) {
    Linha "OK" "TAX ONE UAT respondeu"
  } else {
    $erros++
    Linha "ERRO" "TAX ONE UAT nao respondeu" "Autentique o ZScaler e tente de novo; se persistir, o UAT pode estar indisponivel."
  }
}

if ($aqui -match "OneDrive") {
  Linha "AVISO" "A ferramenta esta numa pasta do OneDrive" "Mova para uma pasta local, por exemplo C:\Users\seu-usuario\TaxOneConferencia."
} else {
  Linha "OK" "Pasta da ferramenta fora do OneDrive"
}

$unidade = Get-PSDrive -Name $aqui.Substring(0, 1) -ErrorAction SilentlyContinue
if ($unidade -and $unidade.Free -lt 2GB) {
  Linha "AVISO" ("Pouco espaco livre ({0:n1} GB)" -f ($unidade.Free / 1GB)) "Cada execucao gera dezenas ou centenas de MB."
} else {
  Linha "OK" "Espaco em disco suficiente"
}

if (Get-NetTCPConnection -LocalPort 5055 -State Listen -ErrorAction SilentlyContinue) {
  Linha "OK" "Ferramenta ligada (porta 5055 em uso)"
} else {
  Linha "AVISO" "Ferramenta ainda nao esta ligada" "Use o atalho da Area de Trabalho ou o iniciar.bat."
}

Write-Host ""
if ($erros -eq 0 -and $avisos -eq 0) {
  Write-Host "Ambiente conferido: tudo certo." -ForegroundColor Green
  exit 0
}
if ($erros -eq 0) {
  Write-Host "Ambiente pronto, com avisos acima." -ForegroundColor Yellow
  exit 2
}
Write-Host ("{0} item(ns) precisam de atencao antes de executar." -f $erros) -ForegroundColor Red
exit 1
