import ctypes
import os
import socket
import subprocess
import sys
import time
import webbrowser

AQUI = os.path.dirname(os.path.abspath(__file__))
PORTA = int(os.environ.get("TAXONE_CONF_PORTA", "5055"))
URL = "http://127.0.0.1:%d" % PORTA


def escutando():
    try:
        socket.create_connection(("127.0.0.1", PORTA), timeout=1).close()
        return True
    except OSError:
        return False


def main():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateMutexW(None, False, "Local\\TaxOneConferenciaAbrir")
    outro_abrindo = ctypes.get_last_error() == 183
    if not escutando() and not outro_abrindo:
        subprocess.Popen(
            [sys.executable, os.path.join(AQUI, "app.py"), "--sem-navegador"],
            cwd=AQUI,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW,
        )
    for _ in range(120):
        if escutando():
            break
        time.sleep(0.5)
    if "--sem-navegador" not in sys.argv and escutando():
        webbrowser.open(URL)


main()
