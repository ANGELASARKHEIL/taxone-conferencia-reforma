import copy
import os
import re
import time

import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.opc.packuri import PackURI
from docx.opc.part import Part
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls, qn
from docx.shared import Cm, Pt, RGBColor
from PIL import Image, ImageDraw, ImageFont

AQUI = os.path.dirname(os.path.abspath(__file__))
MODELO = os.path.join(AQUI, "modelos", "Plano_de_Testes_modelo.docx")
MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro",
         "Novembro", "Dezembro"]
CT_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
LARGURA = Cm(16)

SHAPETYPE = ('<v:shapetype id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t" '
             'path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f"><v:stroke joinstyle="miter"/><v:formulas>'
             '<v:f eqn="if lineDrawn pixelLineWidth 0"/><v:f eqn="sum @0 1 0"/><v:f eqn="sum 0 0 @1"/>'
             '<v:f eqn="prod @2 1 2"/><v:f eqn="prod @3 21600 pixelWidth"/><v:f eqn="prod @3 21600 pixelHeight"/>'
             '<v:f eqn="sum @0 0 1"/><v:f eqn="prod @6 1 2"/><v:f eqn="prod @7 21600 pixelWidth"/>'
             '<v:f eqn="sum @8 21600 0"/><v:f eqn="prod @7 21600 pixelHeight"/><v:f eqn="sum @10 21600 0"/>'
             '</v:formulas><v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>'
             '<o:lock v:ext="edit" aspectratio="t"/></v:shapetype>')


def _substituir_paragrafo(p, mapa):
    texto = p.text
    if not any(k in texto for k in mapa):
        return
    for r in p.runs:
        for k, v in mapa.items():
            if k in r.text:
                r.text = r.text.replace(k, v)
    novo = p.text
    if any(k in novo for k in mapa):
        for k, v in mapa.items():
            novo = novo.replace(k, v)
        p.runs[0].text = novo
        for r in p.runs[1:]:
            r.text = ""


def _todos_paragrafos(doc):
    for p in doc.paragraphs:
        yield p
    for t in doc.tables:
        for row in t.rows:
            for c in row.cells:
                for p in c.paragraphs:
                    yield p
    for s in doc.sections:
        for parte in (s.header, s.footer):
            for p in parte.paragraphs:
                yield p


def _icone(nome_arquivo, destino):
    img = Image.new("RGB", (260, 190), "white")
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((90, 10, 170, 100), radius=10, fill=(16, 124, 65))
    f_grande = f_peq = None
    for negrito, normal in (("segoeuib.ttf", "segoeui.ttf"), ("DejaVuSans-Bold.ttf", "DejaVuSans.ttf")):
        try:
            f_grande, f_peq = ImageFont.truetype(negrito, 46), ImageFont.truetype(normal, 15)
            break
        except OSError:
            continue
    if f_grande is None:
        f_grande = f_peq = ImageFont.load_default()
    d.text((130, 55), "X", font=f_grande, fill="white", anchor="mm")
    nome = os.path.basename(nome_arquivo)
    linhas, atual = [], ""
    for ch in nome:
        if d.textlength(atual + ch, font=f_peq) > 250:
            linhas.append(atual)
            atual = ""
        atual += ch
    linhas.append(atual)
    for i, l in enumerate(linhas[:4]):
        d.text((130, 118 + i * 18), l, font=f_peq, fill="black", anchor="mm")
    img.save(destino)
    return destino


class Gerador:
    def __init__(self, modelo, pasta_tmp):
        self.doc = Document(modelo)
        self.tmp = pasta_tmp
        os.makedirs(pasta_tmp, exist_ok=True)
        self.n_ole = 0

    def anexar_excel(self, paragrafo, caminho):
        self.n_ole += 1
        n = self.n_ole
        part = Part(PackURI(f"/word/embeddings/Microsoft_Excel_Worksheet{n}.xlsx"), CT_XLSX,
                    open(caminho, "rb").read(), self.doc.part.package)
        rid_pkg = self.doc.part.relate_to(part, RT.PACKAGE)
        rid_img, _ = self.doc.part.get_or_add_image(_icone(caminho, os.path.join(self.tmp, f"icone_{n}.png")))
        forma = f"_x0000_i{1024 + n}"
        xml = (f'<w:r {nsdecls("w", "r")} xmlns:v="urn:schemas-microsoft-com:vml" '
               f'xmlns:o="urn:schemas-microsoft-com:office:office"><w:object w:dxaOrig="2600" w:dyaOrig="1900">'
               f'{SHAPETYPE if n == 1 else ""}'
               f'<v:shape id="{forma}" type="#_x0000_t75" style="width:130pt;height:95pt" o:ole="">'
               f'<v:imagedata r:id="{rid_img}" o:title=""/></v:shape>'
               f'<o:OLEObject Type="Embed" ProgID="Excel.Sheet.12" ShapeID="{forma}" DrawAspect="Icon" '
               f'ObjectID="_17{int(time.time()) % 100000000:08d}{n}" r:id="{rid_pkg}"/></w:object></w:r>')
        paragrafo._p.append(parse_xml(xml))


def _antes(ref, novo):
    ref._element.addprevious(novo._element)
    return novo


def monetario(coluna):
    c = str(coluna)
    return bool(re.search(r"valor|total|diferen", c, re.I)) and not re.search(r"qtd|docs|registros|valor (igual|diferente)", c, re.I)


def formatar_valor(v, coluna=""):
    if v is None or (isinstance(v, float) and v != v):
        return "—"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if monetario(coluna) or not float(v).is_integer():
            return f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        return f"{int(v):,}".replace(",", ".")
    return str(v)


def _tabela(doc, linhas, colunas, larguras=None):
    t = doc.add_table(rows=1, cols=len(colunas))
    bordas = "".join(f'<w:{b} w:val="inset" w:sz="6" w:space="0" w:color="auto"/>'
                     for b in ("top", "left", "bottom", "right", "insideH", "insideV"))
    t._tbl.tblPr.append(parse_xml(f'<w:tblBorders {nsdecls("w")}>{bordas}</w:tblBorders>'))
    for i, c in enumerate(colunas):
        cel = t.rows[0].cells[i]
        cel.text = ""
        run = cel.paragraphs[0].add_run(str(c))
        run.bold = True
        run.font.size = Pt(8)
        cel._tc.get_or_add_tcPr().append(parse_xml(f'<w:shd {nsdecls("w")} w:val="clear" w:color="auto" w:fill="F2F2F2"/>'))
    for l in linhas:
        cels = t.add_row().cells
        for i, c in enumerate(colunas):
            v = l.get(c, "") if isinstance(l, dict) else l[i]
            cels[i].text = ""
            r = cels[i].paragraphs[0].add_run(formatar_valor(v, c))
            r.font.size = Pt(8)
    if larguras:
        for row in t.rows:
            for i, w in enumerate(larguras):
                row.cells[i].width = w
    return t


def _converter_para_xlsx(fontes, destino):
    with pd.ExcelWriter(destino, engine="openpyxl") as xw:
        for aba, caminho in fontes:
            if not caminho or not os.path.exists(caminho):
                continue
            if caminho.lower().endswith(".xls"):
                df = pd.read_csv(caminho, sep="\t", dtype=str, encoding="latin-1", keep_default_na=False)
            else:
                df = pd.read_csv(caminho, sep=None, engine="python", dtype=str, encoding="utf-8-sig", keep_default_na=False)
            df.to_excel(xw, sheet_name=aba[:31], index=False)
    return destino


AZUL_MODELO = RGBColor(0x1F, 0x38, 0x64)
PRETO = RGBColor(0, 0, 0)


def _definir_texto(p, texto):
    if p.runs:
        p.runs[0].text = texto
        for r in p.runs[1:]:
            r.text = ""
    else:
        p.add_run(texto)
    return p


def _clonar_depois(p_ref, texto, depois_de=None):
    from docx.text.paragraph import Paragraph
    novo = copy.deepcopy(p_ref._p)
    for d in novo.findall(".//" + qn("w:drawing")):
        d.getparent().remove(d)
    (depois_de or p_ref)._p.addnext(novo)
    return _definir_texto(Paragraph(novo, p_ref._parent), texto)


def _achar(doc, inicio, a_partir=None):
    ativo = a_partir is None
    for p in doc.paragraphs:
        if not ativo:
            ativo = p._p is a_partir._p
            continue
        if p.text.strip().startswith(inicio):
            return p
    return None


def _bloco_entre(doc, titulo_ini, titulo_fim):
    dentro, itens = False, []
    for p in doc.paragraphs:
        t = p.text.strip()
        if p.style.name.startswith("Heading 1"):
            if dentro:
                break
            dentro = t.upper().startswith(titulo_ini)
            continue
        if dentro and t:
            itens.append(p)
    return itens


def _substituir_lista(doc, titulo, linhas):
    itens = [p for p in _bloco_entre(doc, titulo, None) if p.text.strip().startswith("•")]
    if not itens:
        return
    modelo = itens[0]
    ultimo = modelo
    _definir_texto(modelo, "• " + linhas[0])
    for l in linhas[1:]:
        ultimo = _clonar_depois(modelo, "• " + l, ultimo)
    for p in itens[1:]:
        p._p.getparent().remove(p._p)


def _revisar_textos(doc, info, cliente, empresa_nome, mes, ano):
    per = info["periodo"]
    mes_txt = f"{MESES[mes - 1].lower()} de {ano}"
    amb = info.get("ambiente_completo") or f"TAX ONE {cliente} UAT"
    amb_os = "UAT (uat.onesourcetax.com)"
    modulos = ("Data Warehouse (Relatório de Conferência dos Documentos Fiscais e Utilities – Reforma Tributária), "
               "Apuração Fiscal CBS-IBS-IS e Conciliação Fiscal-Contábil")

    intro = _bloco_entre(doc, "INTRODUÇÃO", None)
    if intro:
        _definir_texto(intro[0], (
            f"Este documento apresenta o Plano de Testes para validação das funcionalidades da Reforma Tributária do Consumo "
            f"implementadas no sistema Tax One para o cliente {cliente}. A Reforma Tributária brasileira introduz novos tributos "
            "como CBS (Contribuição sobre Bens e Serviços) e IBS (Imposto sobre Bens e Serviços), exigindo adaptações "
            f"significativas nos processos fiscais. Os testes contemplam os módulos {modulos}, além da validação da integração "
            "das SAFX da Reforma Tributária (SAFX3007, SAFX3008, SAFX3009, SAFX3042 e SAFX3043) e dos confrontos entre os "
            f"resultados de cada módulo, para a empresa {empresa_nome}. A execução deste plano é fundamental para assegurar "
            "que o sistema esteja preparado para o período de transição da Reforma Tributária."))
    obj = _bloco_entre(doc, "OBJETIVO DO DOCUMENTO", None)
    if obj:
        _definir_texto(obj[0], (
            f"O objetivo deste Plano de Testes é documentar os procedimentos de validação dos módulos {modulos} no ambiente "
            f"{amb}{(' – ONESOURCE ' + amb_os) if amb_os else ''} para o cliente {cliente}, período de referência {mes_txt}. "
            "Este documento serve como guia para a equipe de testes e para o cliente durante a homologação das funcionalidades "
            "de Reforma Tributária, detalhando os caminhos de navegação, os relatórios utilizados, os confrontos realizados "
            "entre SAFX, Relatório de Conferência, Apuração e Conciliação, e as evidências obtidas."))
    _substituir_lista(doc, "ESCOPO", [
        "Módulo Data Warehouse (agrupamento Básicos): geração do Relatório de Conferência dos Documentos Fiscais e Utilities – Reforma Tributária",
        "Validação da integração das SAFX3007, SAFX3008, SAFX3009, SAFX3042 e SAFX3043 contra o Relatório de Conferência (registros não integrados e campos divergentes)",
        f"Módulo Apuração Fiscal CBS-IBS-IS (agrupamento Reforma Tributária do Consumo): débitos e créditos de cada tributo disponível na tela (CBS, IBS e IS) do período {per}",
        "Exportação dos relatórios detalhados de Débito/Crédito da Apuração",
        f"Módulo Conciliação Fiscal-Contábil: criação da sessão de conciliação Contribuinte x Fisco para o período {per}",
        "Análise e exportação das inconsistências de documentos, débitos e créditos entre Contribuinte e Fisco",
        f"Testes no ambiente {amb} para a empresa {empresa_nome}",
    ])
    itens_escopo = [p for p in _bloco_entre(doc, "ESCOPO", None) if p.text.strip().startswith("•")]
    modelo_nota = _achar(doc, "Atenção: Para que o resultado seja refletido")
    if itens_escopo and modelo_nota is not None:
        nota = copy.deepcopy(modelo_nota._p)
        itens_escopo[-1]._p.addnext(nota)
        from docx.text.paragraph import Paragraph
        np_ = Paragraph(nota, modelo_nota._parent)
        texto = (" o campo 123 – VLR_TOT_CBS da SAFX3007 precisa estar preenchido com valor maior que zero para que o "
                 "documento seja considerado nos módulos da Reforma Tributária (Apuração e Conciliação). Sem essa "
                 "informação, nenhum valor é gerado nos módulos.")
        if len(np_.runs) >= 2:
            np_.runs[0].text = "Premissa:"
            np_.runs[1].text = texto
            for r in np_.runs[2:]:
                r.text = ""
        else:
            _definir_texto(np_, "Premissa:" + texto)
    _substituir_lista(doc, "FORA DO ESCOPO", [
        "Configuração de novos estabelecimentos ou empresas",
    ])
    safx = info.get("safx") or []
    _substituir_lista(doc, "MASSA DE DADOS", [
        f"Empresa: {empresa_nome}",
        f"Ambiente: {amb} (ONESOURCE {amb_os})",
        f"Período de apuração: {MESES[mes - 1]}/{ano} ({per})",
        "Estabelecimentos: " + (info.get("estabelecimentos") or "Todos"),
        "SAFX analisadas: " + (", ".join(safx) if safx else "não anexadas nesta execução"),
    ])

    h1 = [p for p in doc.paragraphs if p.style.name.startswith("Heading 1")]
    idx_passo = next((i for i, p in enumerate(h1) if p.text.strip().upper().startswith("PASSO A PASSO")), None)
    n = (idx_passo + 1) if idx_passo is not None else 8
    subs = {"Geração Relatório de Conferência": f"{n}.1 Módulo Data Warehouse – Geração do Relatório de Conferência",
            "Módulo Apuração Fiscal CBS/IBS/IS": f"{n}.2 Módulo Apuração Fiscal CBS-IBS-IS",
            "Módulo Conciliação Fiscal-Contábil": f"{n}.3 Módulo Conciliação Fiscal-Contábil"}
    for p in doc.paragraphs:
        t = p.text.strip()
        if t in subs:
            _definir_texto(p, subs[t])
            continue
        m = re.match(r"^Passo (\d+)\s*[–-]\s*(.+)$", t)
        if m:
            _definir_texto(p, f"{n}.1.{m.group(1)} {m.group(2)}")
            for r in p.runs:
                r.font.color.rgb = PRETO
                r.bold = True
            continue
        m = re.match(r"^(12|13)\.(\d+)\s+(.+)$", t)
        if m:
            _definir_texto(p, f"{n}.{2 if m.group(1) == '12' else 3}.{m.group(2)} {m.group(3)}")
            continue
        if "(ver item 12.9)" in t:
            _substituir_paragrafo(p, {"(ver item 12.9)": f"(ver item {n}.2.9)"})

    textos = {
        "Visualização da aba Parâmetros": (
            "Visualização da aba Parâmetros onde o usuário configura os critérios de geração do relatório: Tipo de Execução, "
            f"Período, Origem e Empresas. Nesta execução: Tipo de Execução Imediata, Período {per}, Origem Todas e empresa "
            f"{empresa_nome}. Em seguida o usuário aciona o botão Executar."),
        "Visualização da aba Log": "Visualização da aba Log do processo, indicando que o relatório foi gerado com sucesso.",
        "Visualização da aba Arquivos": (
            "Visualização da aba Arquivos com os arquivos gerados pelo processo (Documentos Fiscais e Utilities, extensão .xls). "
            "Após selecionar os arquivos, o usuário clica em Salvar Arquivos Selecionados, que os envia para a Transferência de arquivos."),
        "Seção Output de Dados": (
            "Download dos arquivos pela Transferência de arquivos (ícone na barra superior do Tax One). Os arquivos ficam "
            "disponíveis por 3 dias e são baixados em formato .zip, contendo os relatórios em Excel."),
        "Figura 7 –": "Figura 7 – Transferência de Arquivos – Download do Relatório em Excel",
        "3. Selecione o período a conciliar": (
            "3. Selecione o período a conciliar (Mês atual ou Mês anterior) ou informe o período desejado na mensagem "
            f"(nesta execução: {MESES[mes - 1].lower()} de {ano})."),
    }
    for inicio, novo in textos.items():
        p = _achar(doc, inicio)
        if p is not None:
            _definir_texto(p, novo)


def _soma(linhas, coluna):
    total = 0.0
    for l in linhas or []:
        v = l.get(coluna)
        if isinstance(v, (int, float)) and v == v:
            total += v
    return total


def _qtd(v):
    return formatar_valor(int(v), "qtd")


def _brl(v):
    return "R$ " + formatar_valor(float(v), "valor")


def _linha_funcional(et):
    titulo, st, r = et["titulo"], (et.get("status") or "Não executada"), et.get("resumo") or []
    if re.search(r"pulad|não executad", st, re.I):
        return {"Etapa": titulo, "Situação": "Não executada", "Principais números": "—", "Próximo passo": "—"}
    if re.search(r"erro|falha", st, re.I):
        return {"Etapa": titulo, "Situação": "Erro", "Principais números": st, "Próximo passo": "Reexecutar a etapa"}
    if "SAFX" in titulo:
        tot, ok = _soma(r, "Registros na SAFX"), _soma(r, "OK")
        div, nao = _soma(r, "Com divergência"), _soma(r, "Não encontrados")
        atencao = div or nao
        return {"Etapa": titulo, "Situação": "Atenção" if atencao else "OK",
                "Principais números": f"{_qtd(tot)} registros; {_qtd(ok)} OK; {_qtd(div)} com divergência; {_qtd(nao)} não integrados",
                "Próximo passo": ("Analisar a planilha de documentos não encontrados e a aba Divergências do resultado SAFX"
                                  if atencao else "Nenhuma ação necessária")}
    if "Apuração" in titulo and "Conciliação" not in titulo:
        ok, dif = _soma(r, "OK"), _soma(r, "Valor diferente")
        sc, scv = _soma(r, "Só conferência (qtd)"), _soma(r, "Só conferência (valor)")
        sa, sav = _soma(r, "Só apuração (qtd)"), _soma(r, "Só apuração (valor)")
        atencao = dif or sc or sa
        passos = []
        if sc:
            passos.append("verificar os documentos que estão só na conferência (ex.: campo 123 da SAFX3007 não preenchido)")
        if dif or sa:
            passos.append("analisar as diferenças de valor e os documentos só na apuração na aba Divergências")
        return {"Etapa": titulo, "Situação": "Atenção" if atencao else "OK",
                "Principais números": (f"{_qtd(ok)} documentos iguais; {_qtd(dif)} com valor diferente; "
                                       f"{_qtd(sc)} só na conferência ({_brl(scv)}); {_qtd(sa)} só na apuração ({_brl(sav)})"),
                "Próximo passo": ((lambda s: s[:1].upper() + s[1:])("; ".join(passos)) if passos else "Nenhuma ação necessária")}
    if "Conciliação" in titulo:
        partes = [f"{l.get('Imposto', '')} {l.get('Tipo', '')}: diferença {_brl(l.get('Diferença total') or 0)}" for l in r]
        dif = any(abs(l.get("Diferença total") or 0) > 0.01 for l in r)
        sa, sc = _soma(r, "Só apuração (qtd)"), _soma(r, "Só conciliação (qtd)")
        atencao = dif or sa or sc
        return {"Etapa": titulo, "Situação": "Atenção" if atencao else "OK",
                "Principais números": "; ".join(partes + [f"{_qtd(sa)} documentos só na apuração", f"{_qtd(sc)} só na conciliação"]) if r else st,
                "Próximo passo": ("Avaliar as inconsistências Contribuinte x Fisco e as diferenças em relação à apuração na planilha da conciliação"
                                  if atencao else "Nenhuma ação necessária")}
    return {"Etapa": titulo, "Situação": "OK", "Principais números": st, "Próximo passo": "—"}


def _finalizar_textos(g, doc, info, cliente, etapas):
    final = _bloco_entre(doc, "CONSIDERAÇÕES FINAIS", None)
    if final:
        base = final[0]
        linhas = [_linha_funcional(et) for et in etapas if et.get("titulo") != "Relatório final consolidado"]
        pendentes = [l for l in linhas if l["Situação"] in ("Atenção", "Erro")]
        conclusao = (f"Resultado: {len(pendentes)} etapa(s) com pontos de atenção – ver a coluna “Próximo passo”."
                     if pendentes else "Resultado: todas as etapas executadas sem pontos de atenção.")
        _definir_texto(base, f"Testes executados no Tax One para {cliente}, empresa {info.get('empresa_nome') or ''}, "
                             f"período {info['periodo']}, em {time.strftime('%d/%m/%Y')}. {conclusao}")
        for p in final[1:]:
            p._p.getparent().remove(p._p)
        ultimo = [base._p]

        def depois(el):
            ultimo[0].addnext(el)
            ultimo[0] = el

        def paragrafo(texto, negrito=False, tamanho=None):
            from docx.text.paragraph import Paragraph
            novo = copy.deepcopy(base._p)
            depois(novo)
            par = _definir_texto(Paragraph(novo, base._parent), texto)
            for r in par.runs:
                r.bold = negrito
                if tamanho:
                    r.font.size = Pt(tamanho)
            return par

        paragrafo("")
        depois(_tabela(doc, linhas, ["Etapa", "Situação", "Principais números", "Próximo passo"],
                       [Cm(4), Cm(2), Cm(6), Cm(5)])._tbl)
        for et in etapas:
            if et.get("resumo"):
                paragrafo("")
                paragrafo("Detalhe – " + et["titulo"], negrito=True)
                depois(_tabela(doc, et["resumo"], et.get("colunas") or list(et["resumo"][0].keys()))._tbl)
        excels = [x for et in etapas for x in et.get("excels", []) if x and os.path.exists(x)]
        if excels:
            paragrafo("")
            paragrafo("Planilhas anexas (clique duas vezes para abrir):", negrito=True, tamanho=9)
            p = paragrafo("")
            for x in excels:
                g.anexar_excel(p, x)
    aprov = next((t for t in doc.tables if t.rows and t.rows[0].cells[0].text.strip() == "Função"), None)
    if aprov is not None:
        for row in aprov.rows:
            if row.cells[0].text.strip().startswith("Consultor"):
                for c, v in ((row.cells[1], info.get("usuario_nome") or info.get("usuario", "")), (row.cells[2], time.strftime("%d/%m/%Y"))):
                    p = c.paragraphs[0]
                    if p.runs:
                        _definir_texto(p, v)
                    else:
                        r = p.add_run(v)
                        r.font.size = Pt(9)


def _paragrafo_simples_vazio(el):
    if el is None or el.tag != qn("w:p"):
        return False
    if "".join(t.text or "" for t in el.iter(qn("w:t"))).strip():
        return False
    for marca in ("w:drawing", "w:pict", "w:object", "w:br", "w:sectPr"):
        if el.findall(".//" + qn(marca)):
            return False
    return True


def _numerar_legenda(p, numero):
    m = re.match(r"^(\s*Figura\s+)(\d+)", p.text)
    if not m or int(m.group(2)) == numero:
        return
    ini, fim = len(m.group(1)), len(m.group(1)) + len(m.group(2))
    pos, feito = 0, False
    for r in p.runs:
        a, b = pos, pos + len(r.text)
        pos = b
        if b <= ini or a >= fim:
            continue
        i0, i1 = max(ini, a) - a, min(fim, b) - a
        r.text = r.text[:i0] + ("" if feito else str(numero)) + r.text[i1:]
        feito = True


def _limpar_figuras_vazias(doc):
    seq = 0
    for p in list(doc.paragraphs):
        m = re.match(r"^Figura (\d+)(\.\d+)?\s*[–-]", p.text.strip())
        if not m:
            continue
        ant = p._p.getprevious()
        tem_img = ant is not None and ant.tag == qn("w:p") and (
            ant.findall(".//" + qn("w:drawing")) or ant.findall(".//" + qn("w:pict")))
        if not tem_img:
            prox = p._p.getnext()
            p._p.getparent().remove(p._p)
            if _paragrafo_simples_vazio(prox):
                prox.getparent().remove(prox)
            continue
        if m.group(2) is None:
            seq += 1
        _numerar_legenda(p, seq)


def _ajustar_cabecalho(doc):
    grupos = {}
    for s in doc.sections:
        el = s.header._element
        esq, dire, pagina = int(s.left_margin) // 635, int(s.right_margin) // 635, int(s.page_width) // 635
        grupos.setdefault(id(el), (el, []))[1].append((pagina, esq, pagina - esq - dire))
    for el, secoes in grupos.values():
        for t in el.findall(qn("w:tbl")):
            pr = t.find(qn("w:tblPr"))
            larg = pr.find(qn("w:tblW")) if pr is not None else None
            if larg is None or larg.get(qn("w:type")) != "dxa":
                continue
            total = int(larg.get(qn("w:w")))
            ind_el = pr.find(qn("w:tblInd"))
            ind = int(ind_el.get(qn("w:w"))) if ind_el is not None else 0
            cel_el = pr.find(f"{qn('w:tblCellMar')}/{qn('w:left')}")
            margem_cel = int(cel_el.get(qn("w:w"))) if cel_el is not None else 0
            if not any(esq + ind - margem_cel < 0 or esq + ind + total > pagina for pagina, esq, _ in secoes):
                continue
            novo = min(texto for _, _, texto in secoes)
            fator = novo / total
            if ind_el is None:
                ind_el = parse_xml(f'<w:tblInd {nsdecls("w")} w:w="0" w:type="dxa"/>')
                larg.addnext(ind_el)
            ind_el.set(qn("w:w"), "0")
            ind_el.set(qn("w:type"), "dxa")
            larg.set(qn("w:w"), str(novo))
            for g in t.findall(f"{qn('w:tblGrid')}/{qn('w:gridCol')}"):
                g.set(qn("w:w"), str(int(int(g.get(qn("w:w"))) * fator)))
            for w_ in t.iter(qn("w:tcW")):
                if w_.get(qn("w:type")) == "dxa":
                    w_.set(qn("w:w"), str(int(int(w_.get(qn("w:w"))) * fator)))


def _ajustar_aprovacao(doc):
    from docx.text.paragraph import Paragraph
    tabela = next((t for t in doc.tables if t.rows and t.rows[0].cells[0].text.strip() == "Função"), None)
    if tabela is None:
        return
    for h in list(tabela._tbl.iter(qn("w:highlight"))):
        h.getparent().remove(h)
    total = len(tabela.rows)
    for i, linha in enumerate(tabela.rows):
        pr = linha._tr.get_or_add_trPr()
        if pr.find(qn("w:cantSplit")) is None:
            pr.insert(0, parse_xml(f'<w:cantSplit {nsdecls("w")}/>'))
        if i < total - 1:
            for cel in linha.cells:
                for par in cel.paragraphs:
                    par.paragraph_format.keep_with_next = True
    ant = tabela._tbl.getprevious()
    for _ in range(4):
        if ant is None or ant.tag != qn("w:p"):
            break
        par = Paragraph(ant, doc._body)
        par.paragraph_format.keep_with_next = True
        if par.style is not None and par.style.name.startswith("Heading"):
            break
        ant = ant.getprevious()


def _atualizar_sumario(caminho):
    try:
        import pythoncom
        import win32com.client as win32
    except ImportError:
        return False
    pythoncom.CoInitialize()
    wd = None
    try:
        wd = win32.DispatchEx("Word.Application")
        wd.Visible = False
        wd.DisplayAlerts = 0
        d = wd.Documents.Open(os.path.abspath(caminho), AddToRecentFiles=False)
        for i in range(1, d.TablesOfContents.Count + 1):
            d.TablesOfContents(i).Update()
        d.Save()
        d.Close(False)
        return True
    except Exception:
        return False
    finally:
        if wd is not None:
            try:
                wd.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()


def gerar_plano(info, etapas, evid_dir, saida, modelo=MODELO):
    """info: cliente, ambiente, ambiente_completo, empresa, empresa_nome, periodo, estabelecimento, usuario,
    usuario_nome, processo, sessao_conciliacao. etapas: lista de dicts {titulo, status, resumo, colunas, excels}."""
    mes, ano = int(info["periodo"][:2]), info["periodo"][3:]
    tmp = os.path.join(os.path.dirname(saida), "_word_tmp")
    g = Gerador(modelo, tmp)
    doc = g.doc
    cliente = (info.get("cliente") or "CLIENTE").upper()
    empresa_nome = info.get("empresa_nome") or info.get("empresa")
    autor = info.get("usuario_nome") or info.get("usuario", "")
    mapa = {
        "{{EMPRESA}}": empresa_nome,
        "{{AMBIENTE_COMPLETO}}": info.get("ambiente_completo") or f"TAX ONE {cliente} {info.get('ambiente') or ''}".strip(),
        "{{AMBIENTE}}": info.get("ambiente") or "",
        "{{MES_ANO}}": f"{MESES[mes - 1]}/{ano}",
        "{{MES_EXT}}": f"{MESES[mes - 1].lower()} de {ano}",
        "{{PERIODO}}": info["periodo"],
        "{{CLIENTE}}": cliente,
        "{{VERSAO}}": "01",
        "{{DATA}}": time.strftime("%d/%m/%Y"),
        "{{DESCRICAO}}": f"Plano de testes e evidências – período {info['periodo']}",
        "{{AUTOR}}": autor,
    }
    for p in _todos_paragrafos(doc):
        _substituir_paragrafo(p, mapa)
    razao = empresa_nome.split(" - ", 1)[-1].strip()
    for part in doc.part.package.iter_parts():
        if re.match(r"/word/(header|footer)\d+\.xml", str(part.partname)):
            for t in part._element.iter(qn("w:t")):
                if t.text and "{{" in t.text:
                    t.text = t.text.replace("{{EMPRESA_RAZAO}}", razao).replace("{{ANO}}", time.strftime("%Y"))
    cp = doc.core_properties
    cp.author = autor
    cp.last_modified_by = autor
    cp.title = f"Plano de Testes – Reforma Tributária – {cliente} – {info['periodo']}"
    cp.subject = empresa_nome
    cp.created = cp.modified = __import__("datetime").datetime.now()
    cp.revision = 1

    _revisar_textos(doc, info, cliente, empresa_nome, mes, ano)

    horas = {}
    reg = os.path.join(evid_dir or "", "passos.jsonl")
    if os.path.exists(reg):
        import json
        with open(reg, encoding="utf-8") as f:
            for linha in f:
                if linha.strip():
                    ps = json.loads(linha)
                    if ps.get("figura"):
                        horas[ps["figura"]] = ps["hora"]
    figuras = {}
    for p in list(doc.paragraphs):
        m = re.match(r"^Figura (\d+)\s*[–-]", p.text.strip())
        if m:
            figuras[int(m.group(1))] = p
    for n, legenda in figuras.items():
        img = os.path.join(evid_dir or "", f"fig{n:02d}.png")
        anterior = legenda._p.getprevious()
        tem_img = anterior is not None and anterior.tag == qn("w:p") and anterior.findall(".//" + qn("w:drawing"))
        if os.path.exists(img):
            if tem_img:
                for r in anterior.findall(qn("w:r")):
                    if r.findall(".//" + qn("w:drawing")):
                        anterior.remove(r)
                from docx.text.paragraph import Paragraph
                alvo = Paragraph(anterior, legenda._parent)
            else:
                alvo = _antes(legenda, doc.add_paragraph())
                alvo.alignment = WD_ALIGN_PARAGRAPH.CENTER
            alvo.add_run().add_picture(img, width=LARGURA)
            if f"fig{n:02d}" in horas:
                legenda.add_run(f" (capturada em {horas[f'fig{n:02d}'][:16]})")
            ultimo = legenda
            for k, imp in enumerate(("IBS", "IS"), 1):
                extra = os.path.join(evid_dir or "", f"fig{n:02d}_{imp}.png")
                if not os.path.exists(extra):
                    continue
                from docx.text.paragraph import Paragraph
                pi = copy.deepcopy(alvo._p)
                for d_ in pi.findall(".//" + qn("w:drawing")):
                    d_.getparent().remove(d_)
                ultimo._p.addnext(pi)
                Paragraph(pi, legenda._parent).add_run().add_picture(extra, width=LARGURA)
                pc = copy.deepcopy(legenda._p)
                pi.addnext(pc)
                texto = re.sub(r"\s*\(capturada em [^)]*\)", "", legenda.text)
                texto = re.sub(r"^Figura (\d+)", rf"Figura \1.{k}", texto)
                texto = texto.replace("(CBS)", f"({imp})") if "(CBS)" in texto else f"{texto} – aba {imp}"
                if f"fig{n:02d}_{imp}" in horas:
                    texto += f" (capturada em {horas[f'fig{n:02d}_{imp}'][:16]})"
                ultimo = _definir_texto(Paragraph(pc, legenda._parent), texto)

    _finalizar_textos(g, doc, info, cliente, etapas)
    _limpar_figuras_vazias(doc)
    _ajustar_cabecalho(doc)
    _ajustar_aprovacao(doc)
    for p in _todos_paragrafos(doc):
        for r in p.runs:
            if r.font.color is not None and r.font.color.type is not None and r.font.color.rgb == AZUL_MODELO:
                r.font.color.rgb = PRETO
    doc.save(saida)
    atualizado = _atualizar_sumario(saida)
    d2 = Document(saida)
    if not atualizado:
        d2.settings.element.append(parse_xml(f'<w:updateFields {nsdecls("w")} w:val="true"/>'))
    cp = d2.core_properties
    cp.author = cp.last_modified_by = autor
    for el in list(cp._element):
        if el.tag.endswith("}lastPrinted"):
            cp._element.remove(el)
    d2.save(saida)
    return saida
