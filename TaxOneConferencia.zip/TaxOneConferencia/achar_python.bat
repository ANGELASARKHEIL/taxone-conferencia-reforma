@echo off
rem Define PY com o caminho completo de um Python 3.10 ou superior de verdade (ignora o atalho da Microsoft Store).
set "PY="
for /f "usebackq delims=" %%P in (`py -3 -c "import sys; print(sys.executable) if sys.version_info >= (3, 10) else sys.exit(1)" 2^>nul`) do if not defined PY set "PY=%%P"
if not defined PY for /f "usebackq delims=" %%P in (`python -c "import sys; print(sys.executable) if sys.version_info >= (3, 10) else sys.exit(1)" 2^>nul`) do if not defined PY set "PY=%%P"
if not defined PY if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set "PY=%LocalAppData%\Programs\Python\Python313\python.exe"
if defined PY if not exist "%PY%" set "PY="
exit /b 0
