import json
import os
import re
import unicodedata

import pandas as pd

import comparador

TOL = 0.01
IMPOSTOS = ["CBS", "IBS", "IS"]


def _num(v):
    s = str(v or "").replace("R$", "").replace("\xa0", "").strip()
    if s in ("", "-", "—"):
        return 0.0
    neg = s.startswith("-") or (s.startswith("(") and s.endswith(")"))
    s = s.strip("-()").strip()
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return -float(s) if neg else float(s)
    except ValueError:
        return 0.0


def _doc(v):
    s = str(v or "").strip()
    return s.lstrip("0") or s


def _estab(v):
    return re.split(r"\s+[-–]\s+", str(v or "").strip())[0].strip()


def _data(v):
    s = str(v or "").strip()
    return f"{s[6:8]}/{s[4:6]}/{s[:4]}" if re.fullmatch(r"\d{8}", s) else s


def _col(df, *padroes):
    for p in padroes:
        for c in df.columns:
            if re.search(p, c, re.I):
                return c
    return None


def _ajustar(xw):
    comparador._ajustar_planilhas(xw)


def ler_apuracao(arquivos):
    out = {}
    for chave, caminho in arquivos.items():
        m = re.match(r"(CBS|IBS|IS)_(debitos|creditos)", chave)
        if not m or not os.path.exists(caminho):
            continue
        df = pd.read_csv(caminho, sep=";", dtype=str, encoding="utf-8-sig", keep_default_na=False)
        c_est = _col(df, r"^Estabelecimento", r"^C[óo]digo (do )?estabelecimento")
        c_doc = _col(df, r"^N[º°o]\.? ?(do )?doc")
        c_val = _col(df, r"^Valor (do )?imposto", r"^Valor (IBS|CBS|IS)\s*-\s*R\$")
        c_dat = _col(df, r"^Data fiscal", r"^Data de emiss")
        if not (c_est and c_doc and c_val):
            raise ValueError(f"Colunas inesperadas em {os.path.basename(caminho)}: {list(df.columns)}")
        n = pd.DataFrame({
            "COD_ESTAB": df[c_est].map(_estab), "NUM_DOC": df[c_doc].map(_doc), "DOC_ORIGINAL": df[c_doc],
            "DATA": df[c_dat].map(_data) if c_dat else "", "VALOR_APURACAO": df[c_val].map(_num).astype(float),
        })
        if "Tipo" in df.columns:
            n["TIPO_APURACAO"] = df["Tipo"]
        out.setdefault(m.group(1), {})[m.group(2)] = n
    return out


def docs_conferencia(rel_fis, rel_uti, imposto):
    partes = []
    for nome, caminho, cab in (("Fiscais", rel_fis, "SAFX3007"), ("Utilities", rel_uti, "SAFX3042")):
        if not caminho or not os.path.exists(caminho):
            continue
        rel = comparador.ler_relatorio(caminho)
        if rel.empty or "ORIGEM SAFX" not in rel.columns:
            continue
        cap = rel[rel["ORIGEM SAFX"] == cab]
        col_v = f"VLR_TOT_{imposto}"
        if col_v not in cap.columns or cap.empty:
            continue
        data = cap["DATA_FISCAL"] if "DATA_FISCAL" in cap.columns else cap.get("DAT_FISCAL", "")
        mov = cap["MOVTO_E_S"] if "MOVTO_E_S" in cap.columns else pd.Series(["9"] * len(cap), index=cap.index)
        partes.append(pd.DataFrame({
            "RELATORIO": nome, "COD_ESTAB": cap["COD_ESTAB"].map(_estab), "NUM_DOC": cap["NUM_DOCFIS"].map(_doc),
            "DOC_ORIGINAL": cap["NUM_DOCFIS"], "DATA": data, "MOVTO_E_S": mov,
            "COD_DOCTO": cap.get("COD_DOCTO", ""), "SERIE": cap.get("SERIE_DOCFIS", ""),
            "COD_FIS_JUR": cap.get("COD_FIS_JUR", ""), "VALOR_CONFERENCIA": cap[col_v].map(_num),
        }))
    if not partes:
        return pd.DataFrame(columns=["RELATORIO", "COD_ESTAB", "NUM_DOC", "MOVTO_E_S", "VALOR_CONFERENCIA"])
    df = pd.concat(partes, ignore_index=True)
    df["TIPO"] = df["MOVTO_E_S"].map(lambda m: "debitos" if str(m).strip() == "9" else "creditos")
    return df


def confrontar_conf_apuracao(rel_fis, rel_uti, apur_arquivos, saida):
    apur = ler_apuracao(apur_arquivos)
    resumo, detalhes = [], []
    for imp in IMPOSTOS:
        if imp not in apur:
            continue
        conf = docs_conferencia(rel_fis, rel_uti, imp)
        for tipo in ("debitos", "creditos"):
            a = apur[imp].get(tipo)
            if a is None:
                continue
            c = conf[(conf["TIPO"] == tipo) & (conf["VALOR_CONFERENCIA"].abs() > TOL)] if len(conf) else conf
            ca = c.groupby(["COD_ESTAB", "NUM_DOC"]).agg(
                VALOR_CONFERENCIA=("VALOR_CONFERENCIA", "sum"), QTD_CONF=("VALOR_CONFERENCIA", "size"),
                DATA_CONF=("DATA", "first"), RELATORIO=("RELATORIO", "first"), MOVTO_E_S=("MOVTO_E_S", "first"),
                COD_DOCTO=("COD_DOCTO", "first"), SERIE=("SERIE", "first"), COD_FIS_JUR=("COD_FIS_JUR", "first"),
                DOC_CONF=("DOC_ORIGINAL", "first")).reset_index() if len(c) else pd.DataFrame(
                columns=["COD_ESTAB", "NUM_DOC", "VALOR_CONFERENCIA"])
            aa = a.groupby(["COD_ESTAB", "NUM_DOC"]).agg(
                VALOR_APURACAO=("VALOR_APURACAO", "sum"), QTD_APUR=("VALOR_APURACAO", "size"),
                DATA_APUR=("DATA", "first"), DOC_APUR=("DOC_ORIGINAL", "first")).reset_index()
            m = ca.merge(aa, on=["COD_ESTAB", "NUM_DOC"], how="outer", indicator=True)
            m["VALOR_CONFERENCIA"] = pd.to_numeric(m["VALOR_CONFERENCIA"], errors="coerce").fillna(0.0)
            m["VALOR_APURACAO"] = pd.to_numeric(m["VALOR_APURACAO"], errors="coerce").fillna(0.0)
            m["DIFERENCA"] = (m["VALOR_CONFERENCIA"] - m["VALOR_APURACAO"]).round(2)

            def status(r):
                if r["_merge"] == "left_only":
                    return "Só no relatório de conferência"
                if r["_merge"] == "right_only":
                    return "Só na apuração"
                return "OK" if abs(r["DIFERENCA"]) <= TOL else "Valor diferente"
            m["STATUS"] = m.apply(status, axis=1) if len(m) else []
            m.insert(0, "TIPO", "Débito" if tipo == "debitos" else "Crédito")
            m.insert(0, "IMPOSTO", imp)
            cnt = m["STATUS"].value_counts().to_dict() if len(m) else {}
            soma = lambda st, col: round(float(m.loc[m["STATUS"] == st, col].sum()), 2) if len(m) else 0.0
            resumo.append({
                "Imposto": imp, "Tipo": "Débito" if tipo == "debitos" else "Crédito",
                "Docs conferência": len(ca), "Valor conferência": round(float(ca["VALOR_CONFERENCIA"].sum()), 2) if len(ca) else 0.0,
                "Docs apuração": len(aa), "Valor apuração": round(float(aa["VALOR_APURACAO"].sum()), 2),
                "Diferença total": round((float(ca["VALOR_CONFERENCIA"].sum()) if len(ca) else 0.0) - float(aa["VALOR_APURACAO"].sum()), 2),
                "OK": cnt.get("OK", 0), "Valor diferente": cnt.get("Valor diferente", 0),
                "Só conferência (qtd)": cnt.get("Só no relatório de conferência", 0),
                "Só conferência (valor)": soma("Só no relatório de conferência", "VALOR_CONFERENCIA"),
                "Só apuração (qtd)": cnt.get("Só na apuração", 0),
                "Só apuração (valor)": soma("Só na apuração", "VALOR_APURACAO"),
            })
            detalhes.append(m[m["STATUS"] != "OK"].drop(columns=["_merge"]))
    det = pd.concat(detalhes, ignore_index=True) if detalhes else pd.DataFrame()
    with pd.ExcelWriter(saida, engine="openpyxl") as xw:
        pd.DataFrame(resumo or [{"Resultado": "Sem relatórios da apuração para comparar"}]).to_excel(xw, sheet_name="Resumo", index=False)
        (det if len(det) else pd.DataFrame([{"Resultado": "Todos os documentos batem"}])).to_excel(
            xw, sheet_name="Divergências", index=False)
        _ajustar(xw)
    return {"resumo": resumo, "divergencias": len(det), "saida": saida}


def _totais_apuracao(apur_arquivos):
    apur = ler_apuracao(apur_arquivos)
    out = {}
    for imp, d in apur.items():
        deb = float(d["debitos"]["VALOR_APURACAO"].sum()) if "debitos" in d else 0.0
        cre = float(d["creditos"]["VALOR_APURACAO"].sum()) if "creditos" in d else 0.0
        out[imp] = {"debitos": round(deb, 2), "creditos": round(cre, 2), "saldo": round(deb - cre, 2)}
    return out


STATUS_CONC = {"UNMATCHED": "Sem correspondência no Fisco", "MATCHED": "Conciliado", "DIVERGENT": "Divergente",
               "DIVERGENCE": "Divergente", "PENDING": "Pendente"}


def ler_conciliacao(arquivos):
    partes = []
    for nome in ("debitos", "creditos"):
        caminho = arquivos.get(nome)
        if not caminho or not os.path.exists(caminho):
            continue
        df = pd.read_csv(caminho, sep=None, engine="python", dtype=str, encoding="utf-8-sig", keep_default_na=False)
        if df.empty:
            continue
        c_doc, c_est = _col(df, r"^N[º°o]\.? ?Documento"), _col(df, r"^Estabelecimento")
        c_trib, c_st = _col(df, r"^Tipo Tributo"), _col(df, r"^Status")
        partes.append(pd.DataFrame({
            "IMPOSTO": df[c_trib].str.upper() if c_trib else "CBS",
            "TIPO": "debitos" if nome == "debitos" else "creditos",
            "COD_ESTAB": df[c_est].map(_estab), "NUM_DOC": df[c_doc].map(_doc), "DOC_ORIGINAL": df[c_doc],
            "STATUS_CONCILIACAO": df[c_st].map(lambda s: STATUS_CONC.get(s.strip().upper(), s)) if c_st else "",
            "VALOR_CONTRIBUINTE": df[_col(df, r"^Valor Contribuinte")].map(_num),
            "VALOR_FISCO": df[_col(df, r"^Valor Fisco")].map(_num) if _col(df, r"^Valor Fisco") else 0.0,
        }))
    return pd.concat(partes, ignore_index=True) if partes else pd.DataFrame(
        columns=["IMPOSTO", "TIPO", "COD_ESTAB", "NUM_DOC", "STATUS_CONCILIACAO", "VALOR_CONTRIBUINTE", "VALOR_FISCO"])


def confrontar_apur_conciliacao(apur_arquivos, conc, saida, incompleto=False):
    apur = ler_apuracao(apur_arquivos)
    cdf = ler_conciliacao(conc.get("arquivos", {}))
    tot_dash = {k: (_num(v[0]) if v and v[0] != "-" else None) for k, v in conc.get("totais", {}).items()}
    um_imposto = len(apur) == 1 and not incompleto
    resumo, detalhes = [], []
    for imp in IMPOSTOS:
        if imp not in apur:
            continue
        for tipo in ("debitos", "creditos"):
            a = apur[imp].get(tipo)
            if a is None:
                continue
            aa = a.groupby(["COD_ESTAB", "NUM_DOC"]).agg(VALOR_APURACAO=("VALOR_APURACAO", "sum"),
                                                         DATA_APUR=("DATA", "first"), DOC_APUR=("DOC_ORIGINAL", "first")).reset_index()
            c = cdf[(cdf["IMPOSTO"] == imp) & (cdf["TIPO"] == tipo)]
            ca = c.groupby(["COD_ESTAB", "NUM_DOC"]).agg(
                VALOR_CONTRIBUINTE=("VALOR_CONTRIBUINTE", "sum"), VALOR_FISCO=("VALOR_FISCO", "sum"),
                STATUS_CONCILIACAO=("STATUS_CONCILIACAO", "first"), DOC_CONC=("DOC_ORIGINAL", "first")).reset_index() if len(c) else \
                pd.DataFrame(columns=["COD_ESTAB", "NUM_DOC", "VALOR_CONTRIBUINTE", "VALOR_FISCO", "STATUS_CONCILIACAO"])
            m = aa.merge(ca, on=["COD_ESTAB", "NUM_DOC"], how="outer", indicator=True)
            for col in ("VALOR_APURACAO", "VALOR_CONTRIBUINTE", "VALOR_FISCO"):
                m[col] = pd.to_numeric(m[col], errors="coerce").fillna(0.0)
            m["DIFERENCA_APUR_X_CONC"] = (m["VALOR_APURACAO"] - m["VALOR_CONTRIBUINTE"]).round(2)

            def status(r):
                if r["_merge"] == "left_only":
                    return "Só na apuração (sem inconsistência na conciliação)"
                if r["_merge"] == "right_only":
                    return "Só na conciliação (não está na apuração)"
                return "Valor igual" if abs(r["DIFERENCA_APUR_X_CONC"]) <= TOL else "Valor diferente"
            m["STATUS"] = m.apply(status, axis=1) if len(m) else []
            if len(m):
                so_a, so_c = m[m["_merge"] == "left_only"], m[m["_merge"] == "right_only"]

                def mapa(df, col):
                    d = {}
                    for n, e, v in zip(df["NUM_DOC"], df["COD_ESTAB"], df[col]):
                        d.setdefault(n, []).append(f"{e}: {v:,.2f}")
                    return {k: "; ".join(v) for k, v in d.items()}
                mapa_c, mapa_a = mapa(so_c, "VALOR_CONTRIBUINTE"), mapa(so_a, "VALOR_APURACAO")
                m["MESMO_NUM_EM_OUTRO_ESTAB"] = ""
                m.loc[m["_merge"] == "left_only", "MESMO_NUM_EM_OUTRO_ESTAB"] = so_a["NUM_DOC"].map(mapa_c).fillna("")
                m.loc[m["_merge"] == "right_only", "MESMO_NUM_EM_OUTRO_ESTAB"] = so_c["NUM_DOC"].map(mapa_a).fillna("")
            m.insert(0, "TIPO", "Débito" if tipo == "debitos" else "Crédito")
            m.insert(0, "IMPOSTO", imp)
            cnt = m["STATUS"].value_counts().to_dict() if len(m) else {}
            soma = lambda st, col: round(float(m.loc[m["STATUS"] == st, col].sum()), 2) if len(m) else 0.0
            total_apur = round(float(aa["VALOR_APURACAO"].sum()), 2)
            total_conc = tot_dash.get(tipo) if um_imposto else None
            if total_conc is None:
                total_conc = round(float(ca["VALOR_CONTRIBUINTE"].sum()), 2) if len(ca) else 0.0
            linha = {
                "Imposto": imp, "Tipo": "Débito" if tipo == "debitos" else "Crédito",
                "Total apuração": total_apur, "Total contribuinte (conciliação)": total_conc,
                "Diferença total": round(total_apur - total_conc, 2),
                "Docs apuração": len(aa), "Docs nas inconsistências da conciliação": len(ca),
                "Valor igual": cnt.get("Valor igual", 0), "Valor diferente": cnt.get("Valor diferente", 0),
                "Só apuração (qtd)": cnt.get("Só na apuração (sem inconsistência na conciliação)", 0),
                "Só apuração (valor)": soma("Só na apuração (sem inconsistência na conciliação)", "VALOR_APURACAO"),
                "Só conciliação (qtd)": cnt.get("Só na conciliação (não está na apuração)", 0),
                "Só conciliação (valor)": soma("Só na conciliação (não está na apuração)", "VALOR_CONTRIBUINTE"),
            }
            if len(c):
                for st, q in c["STATUS_CONCILIACAO"].value_counts().items():
                    linha[f"Conciliação: {st}"] = int(q)
            resumo.append(linha)
            detalhes.append(m.drop(columns=["_merge"]))
    det = pd.concat(detalhes, ignore_index=True) if detalhes else pd.DataFrame()
    diverg = det[det["STATUS"] != "Valor igual"] if len(det) else det
    with pd.ExcelWriter(saida, engine="openpyxl") as xw:
        pd.DataFrame(resumo or [{"Resultado": "Sem dados da apuração para comparar"}]).to_excel(xw, sheet_name="Resumo", index=False)
        (diverg if len(diverg) else pd.DataFrame([{"Resultado": "Apuração e conciliação batem documento a documento"}])).to_excel(
            xw, sheet_name="Divergências", index=False)
        (cdf if len(cdf) else pd.DataFrame([{"Resultado": "Sem inconsistências exportadas"}])).to_excel(
            xw, sheet_name="Inconsistências conciliação", index=False)
        pd.DataFrame([{"Filial": conc.get("filial"), "Período": conc.get("periodo"), "Última sessão": conc.get("ultima_sessao"),
                       "Débitos contribuinte (painel)": conc.get("totais", {}).get("debitos", ("-",))[0],
                       "Débitos fisco (painel)": conc.get("totais", {}).get("debitos", ("-", "-"))[1],
                       "Créditos contribuinte (painel)": conc.get("totais", {}).get("creditos", ("-",))[0],
                       "Créditos fisco (painel)": conc.get("totais", {}).get("creditos", ("-", "-"))[1]}]).to_excel(
            xw, sheet_name="Painel conciliação", index=False)
        _ajustar(xw)
    return {"resumo": resumo, "divergencias": len(diverg), "saida": saida}

STATUS_OK = "OK"
STATUS_PEND = "Pendente de contabilização"
STATUS_DIV = "Divergente"
STATUS_VER = "Verificar"
STATUS_DIST = "Distribuição diferente"
COLS_CTB = ["Estabelecimento", "Valor apuração CBS (D - C)", "Valor apurado na Contabilização",
            "Diferença apuração x contabilização", "Valor contabilizado", "Valor a contabilizar (saldo)",
            "Qtd lançamentos", "Valor dos lançamentos", "Status"]
COLS_LANC = ["NUMERO", "STATUS", "DATA", "PERIODO", "ESTAB", "IMPOSTO", "CONFIGURACAO", "NATUREZA", "VALOR_DEBITO",
             "VALOR_CREDITO", "VALOR_LIQUIDO"]
COLS_CFG = ["NOME", "ATIVA", "IMPOSTO", "NATUREZA", "ESTAB", "CONTA", "CONTRAPARTIDA", "CENTRO_CUSTO", "CENTRO_DESPESA",
            "CENTRO_LUCRO", "CODIGO_OPERACAO"]


def _brl(v):
    return "R$ " + f"{float(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _sem_acento(s):
    return unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().strip()


def _nat(v):
    s = _sem_acento(v).upper()
    return "D" if s.startswith("D") else ("C" if s.startswith("C") else "")


def _num_us(v):
    try:
        return float(str(v or "").strip())
    except ValueError:
        return _num(v)


def _sinal(natureza):
    return 1.0 if _nat(natureza) == "D" else -1.0


def _soma_itens(itens, campo):
    return round(float(sum(_sinal(i.get("natureza")) * float(i.get(campo) or 0.0) for i in itens)), 2)


def _situacao_item(i):
    if abs(i.get("contabilizado") or 0.0) <= TOL:
        return "Não contabilizada"
    return "Contabilizada" if abs(i.get("saldo_disponivel") or 0.0) <= TOL else "Parcialmente contabilizada"


def _ler_csv_ctb(caminho):
    if not caminho or not os.path.exists(caminho):
        return pd.DataFrame()
    return pd.read_csv(caminho, sep=None, engine="python", dtype=str, encoding="utf-8-sig", keep_default_na=False)


def ler_lancamentos(caminho):
    df = _ler_csv_ctb(caminho)
    if df.empty:
        return pd.DataFrame(columns=COLS_LANC)
    c = {"NUMERO": _col(df, r"^N[uú]mero Lan"), "STATUS": _col(df, r"^Status"), "DATA": _col(df, r"^Data Lan"),
         "PERIODO": _col(df, r"^Per[ií]odo"), "ESTAB": _col(df, r"^Estabelecimento"), "IMPOSTO": _col(df, r"^Tipo Imposto"),
         "CONFIGURACAO": _col(df, r"^Nome Configura"), "NATUREZA": _col(df, r"^Natureza"),
         "VALOR_DEBITO": _col(df, r"^Valor D[eé]bito"), "VALOR_CREDITO": _col(df, r"^Valor Cr[eé]dito")}
    if not all(c[k] for k in ("PERIODO", "ESTAB", "CONFIGURACAO", "NATUREZA", "VALOR_DEBITO", "VALOR_CREDITO")):
        raise ValueError(f"Colunas inesperadas em {os.path.basename(caminho)}: {list(df.columns)}")
    out = pd.DataFrame({k: (df[v] if v else "") for k, v in c.items()})
    out["ESTAB"] = out["ESTAB"].map(_estab)
    out["NATUREZA"] = out["NATUREZA"].map(_nat)
    out["VALOR_DEBITO"] = out["VALOR_DEBITO"].map(_num_us)
    out["VALOR_CREDITO"] = out["VALOR_CREDITO"].map(_num_us)
    out["VALOR_LIQUIDO"] = (out["VALOR_DEBITO"] - out["VALOR_CREDITO"]).round(2)
    return out


def ler_configuracoes(caminho):
    df = _ler_csv_ctb(caminho)
    if df.empty:
        return pd.DataFrame(columns=COLS_CFG)
    c = {"NOME": _col(df, r"^Nome"), "ATIVA": _col(df, r"^Ativa", r"^Status"), "IMPOSTO": _col(df, r"^Tipo Imposto"),
         "NATUREZA": _col(df, r"^Natureza"), "ESTAB": _col(df, r"^Estabelecimento"), "CONTA": _col(df, r"^Conta Cont"),
         "CONTRAPARTIDA": _col(df, r"^Conta Contrapart"), "CENTRO_CUSTO": _col(df, r"^Centro de Custo"),
         "CENTRO_DESPESA": _col(df, r"^Centro de Despesa"), "CENTRO_LUCRO": _col(df, r"^Centro de Lucro"),
         "CODIGO_OPERACAO": _col(df, r"^C[oó]digo de Opera")}
    if not all(c[k] for k in ("NOME", "ATIVA", "IMPOSTO", "NATUREZA", "CONTA", "CONTRAPARTIDA")):
        raise ValueError(f"Colunas inesperadas em {os.path.basename(caminho)}: {list(df.columns)}")
    out = pd.DataFrame({k: (df[v] if v else "") for k, v in c.items()})
    out["ATIVA"] = out["ATIVA"].map(lambda s: _sem_acento(s).lower() in ("sim", "s", "true", "1", "ativa"))
    out["IMPOSTO"] = out["IMPOSTO"].str.upper().str.strip()
    out["NATUREZA"] = out["NATUREZA"].map(_nat)
    out["ESTAB"] = out["ESTAB"].map(_estab)
    return out


def _apuracao_cbs(apur_arquivos):
    try:
        apur = ler_apuracao(apur_arquivos)
    except Exception as ex:
        return None, {}, f"arquivos da Apuração ilegíveis ({str(ex)[:100]})"
    cbs = apur.get("CBS") or {}
    if "debitos" not in cbs or "creditos" not in cbs:
        return None, {}, "a Apuração de CBS (débitos e créditos) não foi exportada"
    deb = cbs["debitos"].groupby("COD_ESTAB")["VALOR_APURACAO"].sum()
    cre = cbs["creditos"].groupby("COD_ESTAB")["VALOR_APURACAO"].sum()
    por = {e: round(float(deb.get(e, 0.0)) - float(cre.get(e, 0.0)), 2) for e in set(deb.index) | set(cre.index)}
    total = round(float(cbs["debitos"]["VALOR_APURACAO"].sum()) - float(cbs["creditos"]["VALOR_APURACAO"].sum()), 2)
    return total, por, ""


def _lista(itens, limite=6):
    itens = [str(i) for i in itens]
    return ", ".join(itens[:limite]) + (f" e mais {len(itens) - limite}" if len(itens) > limite else "")


def confrontar_contabilizacao(apur_arquivos, ctb, saida):
    ano_mes = ctb.get("competencia") or ""
    estabs = list(ctb.get("estabelecimentos") or [])
    sint, analit, confi = ctb.get("sintetica") or {}, ctb.get("analitica") or {}, ctb.get("configuracoes") or {}
    avisos = list(ctb.get("falhas") or [])
    ap_total, ap_estab, ap_msg = _apuracao_cbs(apur_arquivos or {})
    ap_ok = ap_total is not None
    lanc, cfg = pd.DataFrame(columns=COLS_LANC), pd.DataFrame(columns=COLS_CFG)
    try:
        lanc = ler_lancamentos(analit.get("arquivo"))
    except ValueError as ex:
        avisos.append(str(ex))
    try:
        cfg = ler_configuracoes(confi.get("arquivo"))
    except ValueError as ex:
        avisos.append(str(ex))
    lanc_disponivel = bool(analit) and (analit.get("arquivo") is not None or not analit.get("total"))
    cfg_disponivel = bool(confi) and confi.get("arquivo") is not None

    todos = estabs + [e for e in ap_estab if e not in estabs and abs(ap_estab[e]) > TOL]
    por = {}
    for e in todos:
        d = sint.get(e)
        itens = d["itens"] if d else []
        sel = lanc[(lanc["PERIODO"] == ano_mes) & (lanc["ESTAB"] == e) & ~lanc["STATUS"].str.contains("estorn", case=False, na=False)] \
            if len(lanc) else lanc
        por[e] = {"d": d, "itens": itens, "apurado": _soma_itens(itens, "apurado"), "contabilizado": _soma_itens(itens, "contabilizado"),
                  "saldo": _soma_itens(itens, "saldo_disponivel"), "n_lanc": len(sel),
                  "v_lanc": round(float(sel["VALOR_LIQUIDO"].sum()), 2) if len(sel) else 0.0}
    todos_coletados = bool(estabs) and all(por[e]["d"] is not None for e in estabs)
    tot = {k: round(float(sum(por[e][k] for e in todos)), 2) for k in ("apurado", "contabilizado", "saldo", "v_lanc")}
    tot["n_lanc"] = sum(por[e]["n_lanc"] for e in todos)
    total_confere = ap_ok and todos_coletados and abs(ap_total - tot["apurado"]) <= TOL

    def status_estab(e):
        p = por[e]
        if p["d"] is None or not ap_ok:
            return STATUS_VER
        if abs(ap_estab.get(e, 0.0) - p["apurado"]) > TOL:
            return STATUS_DIST if total_confere else STATUS_DIV
        if lanc_disponivel and abs(p["contabilizado"] - p["v_lanc"]) > TOL:
            return STATUS_VER
        return STATUS_PEND if abs(p["saldo"]) > TOL else STATUS_OK

    if not ap_ok or not todos_coletados:
        status_total = STATUS_VER
    elif not total_confere:
        status_total = STATUS_DIV
    elif lanc_disponivel and abs(tot["contabilizado"] - tot["v_lanc"]) > TOL:
        status_total = STATUS_VER
    else:
        status_total = STATUS_PEND if abs(tot["saldo"]) > TOL else STATUS_OK

    def linha(rotulo, ap_v, p, status):
        return {"Estabelecimento": rotulo, "Valor apuração CBS (D - C)": ap_v if ap_ok else None,
                "Valor apurado na Contabilização": p["apurado"],
                "Diferença apuração x contabilização": round(ap_v - p["apurado"], 2) if ap_ok else None,
                "Valor contabilizado": p["contabilizado"], "Valor a contabilizar (saldo)": p["saldo"],
                "Qtd lançamentos": p["n_lanc"], "Valor dos lançamentos": p["v_lanc"], "Status": status}
    resumo = [linha(e, ap_estab.get(e, 0.0), por[e], status_estab(e)) for e in todos]
    resumo.append(linha("Total (empresa)", ap_total if ap_ok else 0.0, tot, status_total))

    verif = []

    def add(nome, estab, esperado, encontrado, status, detalhe):
        num = all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in (esperado, encontrado))
        verif.append({"Verificação": nome, "Estabelecimento": estab, "Esperado": esperado, "Encontrado": encontrado,
                      "Diferença": round(esperado - encontrado, 2) if num else None, "Status": status, "Detalhe": detalhe})

    if not ap_ok:
        add("Saldo da Apuração (D - C) x saldo apurado na Contabilização", "Empresa", None, tot["apurado"], STATUS_VER,
            f"Não foi possível obter o saldo da Apuração: {ap_msg}.")
    elif not todos_coletados:
        add("Saldo da Apuração (D - C) x saldo apurado na Contabilização", "Empresa", ap_total, None, STATUS_VER,
            "A consulta de algum estabelecimento da Contabilização não foi coletada: " + "; ".join(avisos) + ".")
    else:
        add("Saldo da Apuração (D - C) x saldo apurado na Contabilização", "Empresa", ap_total, tot["apurado"],
            STATUS_OK if total_confere else STATUS_DIV,
            "O saldo apurado na Contabilização (soma dos estabelecimentos) é igual ao saldo de débitos menos créditos de CBS da Apuração."
            if total_confere else
            "O saldo apurado na Contabilização difere do saldo da Apuração: conferir se a Apuração foi reprocessada depois da "
            "geração do saldo e se existe configuração contábil ativa para o sentido do saldo (a recolher ou a recuperar).")
        for e in todos:
            esperado, encontrado = ap_estab.get(e, 0.0), por[e]["apurado"]
            if abs(esperado - encontrado) > TOL:
                add("Saldo da Apuração por estabelecimento x saldo na Contabilização", e, esperado, encontrado,
                    STATUS_DIST if total_confere else STATUS_DIV,
                    "A Contabilização distribui o saldo entre os estabelecimentos de forma diferente da origem dos documentos da Apuração "
                    "(o total da empresa confere)." if total_confere else "Diferença no estabelecimento.")
    add("Saldo pendente de contabilização", "Empresa", 0.0, tot["saldo"], STATUS_PEND if abs(tot["saldo"]) > TOL else STATUS_OK,
        "Saldo apurado ainda não contabilizado (disponível para a ação Contabilizar)." if abs(tot["saldo"]) > TOL
        else "Não há saldo pendente de contabilização.")
    for e in estabs:
        d = por[e]["d"]
        if d is None:
            continue
        itens = d["itens"]
        if d.get("fonte") == "api":
            ruins = [i["configuracao"] for i in itens
                     if abs(i["apurado"] - i["contabilizado"] - i["saldo_disponivel"]) > TOL]
            add("Apurado = contabilizado + saldo disponível (visão sintética)", e, len(itens), len(itens) - len(ruins),
                STATUS_VER if ruins else STATUS_OK,
                ("Configuração(ões) em que a conta não fecha: " + _lista(ruins)) if ruins else
                ("Todas as configurações fecham." if itens else "Sem saldo na competência para este estabelecimento."))
        r, t = d.get("resumo") or {}, d.get("kpis_tela") or {}
        if r or t:
            tela_soma = (t.get("nao_contabilizados", 0) + t.get("contabilizados", 0) + t.get("estornados", 0)) if t else None
            api_soma = (r.get("naoContabilizados", 0) + r.get("contabilizados", 0) + r.get("estornados", 0)) if r else None
            esperado = r.get("total") if r else t.get("total")
            soma = api_soma if api_soma is not None else tela_soma
            coerente = soma == esperado and (not t or not r or (t.get("total") == r.get("total")))
            add("Totalizadores da visão sintética (situações somam o total e batem com a grade)", e, esperado, len(itens),
                STATUS_OK if coerente and len(itens) == esperado else STATUS_VER,
                f"Não contabilizados + contabilizados + estornados = {soma}; total informado = {esperado}; "
                f"linhas lidas na grade = {len(itens)}.")
        if lanc_disponivel:
            add("Contabilizado (sintética) x lançamentos gerados (analítica)", e, por[e]["contabilizado"], por[e]["v_lanc"],
                STATUS_OK if abs(por[e]["contabilizado"] - por[e]["v_lanc"]) <= TOL else STATUS_VER,
                f"{por[e]['n_lanc']} lançamento(s) da competência no estabelecimento (estornados desconsiderados).")
    if analit:
        k = analit.get("kpis_tela") or {}
        soma = (k.get("nao_contabilizados", 0) + k.get("contabilizados", 0) + k.get("estornados", 0)) if k else None
        exportadas = len(lanc) if analit.get("arquivo") else 0
        esperado = analit.get("total") or 0
        add("Totalizadores da visão analítica (situações somam o total e batem com o arquivo exportado)", "Empresa", esperado,
            exportadas, STATUS_OK if (k and soma == k.get("total")) and exportadas == esperado else STATUS_VER,
            f"Totalizadores da tela: soma das situações = {soma}, total = {k.get('total') if k else '—'}; "
            f"linhas no arquivo exportado = {exportadas}." + ("" if analit.get("arquivo") or not esperado else " Arquivo não exportado."))
    if len(lanc):
        outros = lanc[lanc["PERIODO"] != ano_mes]
        ativos = lanc[(lanc["PERIODO"] == ano_mes) & ~lanc["STATUS"].str.contains("estorn", case=False, na=False)]
        dup = ativos.groupby(["ESTAB", "CONFIGURACAO", "NATUREZA", "VALOR_LIQUIDO"]).size() if len(ativos) else pd.Series(dtype=int)
        dup = dup[dup > 1]
        add("Possível duplicidade de lançamentos (mesma configuração, estabelecimento e valor)", "Empresa", 0, int(len(dup)),
            STATUS_VER if len(dup) else STATUS_OK,
            ("Lançamentos repetidos: " + _lista(f"{e}/{c}: {int(q)}x {_brl(abs(v))}" for (e, c, n, v), q in dup.items())
             + ". Conferir se não houve contabilização em duplicidade.") if len(dup) else
            "Nenhum lançamento repetido na competência." + (f" O arquivo traz também {len(outros)} lançamento(s) de outras competências." if len(outros) else ""))
        if cfg_disponivel:
            chaves = ativos[["CONFIGURACAO", "NATUREZA"]].drop_duplicates()
            sem, inativas = [], []
            for nome, nat in zip(chaves["CONFIGURACAO"], chaves["NATUREZA"]):
                achadas = cfg[(cfg["NOME"].str.strip().str.lower() == str(nome).strip().lower()) & (cfg["NATUREZA"] == nat)]
                if achadas.empty:
                    sem.append(nome)
                elif not achadas["ATIVA"].any():
                    inativas.append(nome)
            add("Lançamentos x configurações cadastradas", "Empresa", int(len(chaves)), int(len(chaves) - len(sem) - len(inativas)),
                STATUS_VER if (sem or inativas) else STATUS_OK,
                ((("Sem configuração com o mesmo nome e sentido: " + _lista(sem) + ". ") if sem else "") +
                 (("Configuração hoje inativa: " + _lista(inativas) + ". ") if inativas else "")).strip()
                or "Todos os lançamentos usam configurações cadastradas e ativas.")
    if cfg_disponivel:
        cbs = cfg[(cfg["IMPOSTO"] == "CBS") & cfg["ATIVA"]]
        faltam = [rot for nat, rot in (("D", "Débito (a recolher)"), ("C", "Crédito (a recuperar)")) if cbs[cbs["NATUREZA"] == nat].empty]
        add("Configurações ativas de CBS para os dois sentidos do saldo", "Empresa", 2, 2 - len(faltam),
            STATUS_VER if faltam else STATUS_OK,
            ("Sem configuração ativa para: " + ", ".join(faltam) + ". Sem ela, o saldo apurado nesse sentido não gera lançamento.")
            if faltam else f"{len(cbs)} configuração(ões) ativa(s) de CBS cobrindo débito e crédito.")
        incompletas = [n for n, c, k in zip(cbs["NOME"], cbs["CONTA"], cbs["CONTRAPARTIDA"])
                       if not str(c).strip() or not str(k).strip() or str(c).strip() == str(k).strip()]
        add("Contas de lançamento e de contrapartida das configurações ativas", "Empresa", int(len(cbs)), int(len(cbs) - len(incompletas)),
            STATUS_VER if incompletas else STATUS_OK,
            ("Contas em branco ou iguais em: " + _lista(incompletas)) if incompletas else
            "Todas têm conta de lançamento e conta de contrapartida preenchidas e diferentes.")
        rep = cbs.groupby(["NATUREZA", "ESTAB"]).size() if len(cbs) else pd.Series(dtype=int)
        rep = rep[rep > 1]
        add("Uma única configuração ativa por sentido e estabelecimento", "Empresa", 0, int(len(rep)),
            STATUS_VER if len(rep) else STATUS_OK,
            ("Mais de uma configuração ativa em: " + _lista(f"{'Débito' if n == 'D' else 'Crédito'} {e or '(empresa)'}" for n, e in rep.index))
            if len(rep) else "Não há configurações ativas concorrentes.")
    elif confi:
        sem_cfg = confi.get("linhas_tela") == 0
        add("Configurações cadastradas", "Empresa", 0 if sem_cfg else None, 0 if sem_cfg else None, STATUS_VER,
            "Nenhuma configuração contábil está cadastrada para a empresa: sem configuração, o saldo apurado não gera lançamento."
            if sem_cfg else "As configurações não puderam ser exportadas ou lidas.")

    atencoes = sum(1 for v in verif if v["Status"] in (STATUS_DIV, STATUS_VER))
    sint_linhas = []
    for e in estabs:
        for i in por[e]["itens"]:
            sint_linhas.append({"Estabelecimento": e, "Configuração": i["configuracao"], "Natureza": "Débito" if _nat(i["natureza"]) == "D" else "Crédito",
                                "Conta de lançamento": i["conta"], "Conta de contrapartida": i["contrapartida"],
                                "Valor apurado": i["apurado"], "Valor contabilizado": i["contabilizado"],
                                "Saldo disponível": i["saldo_disponivel"], "Pode contabilizar": i["pode_contabilizar"],
                                "Data da operação": i["data_operacao"], "Situação": _situacao_item(i)})
    coleta = [{"Item": "Empresa", "Valor": ctb.get("empresa")}, {"Item": "Competência", "Valor": ctb.get("periodo")},
              {"Item": "Estabelecimentos", "Valor": ", ".join(estabs)},
              {"Item": "Abas habilitadas", "Valor": ", ".join(k for k, v in (ctb.get("abas") or {}).items() if v) or "—"},
              {"Item": "Abas desabilitadas no produto", "Valor": ", ".join(k for k, v in (ctb.get("abas") or {}).items() if not v) or "—"}]
    for e in estabs:
        d = por[e]["d"]
        if d:
            coleta.append({"Item": f"Totalizadores da sintética – {e}", "Valor": json.dumps(d.get("kpis_tela") or d.get("resumo") or {}, ensure_ascii=False)})
    if analit:
        coleta.append({"Item": "Totalizadores da analítica", "Valor": json.dumps(analit.get("kpis_tela") or {}, ensure_ascii=False)})
    for a in avisos:
        coleta.append({"Item": "Aviso da coleta", "Valor": a})

    lanc_x = lanc.copy()
    if len(lanc_x):
        lanc_x["CONFIGURACAO_CADASTRADA"] = [
            ("Sim" if not cfg[(cfg["NOME"].str.strip().str.lower() == str(n).strip().lower()) & (cfg["NATUREZA"] == t)].empty else "Não")
            if cfg_disponivel else "—" for n, t in zip(lanc_x["CONFIGURACAO"], lanc_x["NATUREZA"])]
    with pd.ExcelWriter(saida, engine="openpyxl") as xw:
        pd.DataFrame(resumo).to_excel(xw, sheet_name="Resumo", index=False)
        pd.DataFrame(verif or [{"Verificação": "Sem verificações executadas"}]).to_excel(xw, sheet_name="Verificações", index=False)
        pd.DataFrame(sint_linhas or [{"Resultado": "Sem saldo de CBS na Contabilização para a competência"}]).to_excel(
            xw, sheet_name="Sintética", index=False)
        (lanc_x if len(lanc_x) else pd.DataFrame([{"Resultado": "Nenhum lançamento contábil gerado na competência"}])).to_excel(
            xw, sheet_name="Lançamentos", index=False)
        (cfg if len(cfg) else pd.DataFrame([{"Resultado": "Configurações não exportadas"}])).to_excel(
            xw, sheet_name="Configurações", index=False)
        pd.DataFrame(coleta).to_excel(xw, sheet_name="Dados da coleta", index=False)
        _ajustar(xw)

    linhas_cfg = []
    if cfg_disponivel and len(cfg):
        ativas = cfg[cfg["ATIVA"]]
        linhas_cfg = [f"{n} ({'Débito' if t == 'D' else 'Crédito'}, conta {c}, contrapartida {k}{', estabelecimento ' + e if e else ''})"
                      for n, t, c, k, e in zip(ativas["NOME"], ativas["NATUREZA"], ativas["CONTA"], ativas["CONTRAPARTIDA"], ativas["ESTAB"])]
    if not cfg_disponivel:
        texto_cfg = ("Nenhuma configuração contábil está cadastrada para a empresa." if confi and confi.get("linhas_tela") == 0
                     else "As configurações não puderam ser exportadas nesta execução.")
    else:
        texto_cfg = (f"Foram exportadas {len(cfg)} configuração(ões) para a empresa {ctb.get('empresa')}: {int(cfg['ATIVA'].sum())} ativa(s) e "
                     f"{int((~cfg['ATIVA']).sum())} inativa(s)." + (" Ativas: " + "; ".join(linhas_cfg) + "." if linhas_cfg else
                                                                  " Não há configuração ativa."))
    linhas_sint = []
    for e in estabs:
        if por[e]["d"] is None:
            linhas_sint.append(f"Estabelecimento {e}: consulta não coletada.")
        elif not por[e]["itens"]:
            linhas_sint.append(f"Estabelecimento {e}: sem saldo de CBS na competência.")
        for i in por[e]["itens"]:
            linhas_sint.append(f"Estabelecimento {e}: {i['configuracao']} ({'Débito' if _nat(i['natureza']) == 'D' else 'Crédito'}) – "
                               f"apurado {_brl(i['apurado'])}, contabilizado {_brl(i['contabilizado'])}, "
                               f"saldo a contabilizar {_brl(i['saldo_disponivel'])} ({_situacao_item(i)}).")
    if not analit:
        texto_analitica = "A visão analítica não foi coletada nesta execução."
    elif not analit.get("total"):
        texto_analitica = "Nenhum lançamento contábil foi gerado na competência; não há arquivo a exportar da visão analítica."
    else:
        texto_analitica = (f"A visão analítica apresenta {analit['total']} lançamento(s) contábil(eis) de CBS"
                           + (f"; o arquivo exportado (CSV) tem {len(lanc)} linha(s)." if analit.get("arquivo") else "."))
    conferencia = []
    if ap_ok:
        conferencia.append(f"Saldo da Apuração de CBS (débitos − créditos): {_brl(ap_total)}.")
    conferencia.append(f"Saldo apurado na Contabilização (soma dos estabelecimentos): {_brl(tot['apurado'])}; "
                       f"contabilizado: {_brl(tot['contabilizado'])}; a contabilizar: {_brl(tot['saldo'])}; "
                       f"lançamentos da competência: {tot['n_lanc']} ({_brl(tot['v_lanc'])}).")
    conclusao = {
        STATUS_OK: "Os valores da Apuração e da Contabilização conferem e não há saldo pendente.",
        STATUS_PEND: "Os valores da Apuração e da Contabilização conferem; o saldo ainda está pendente de contabilização.",
        STATUS_DIV: "O saldo da Contabilização não confere com o saldo da Apuração.",
        STATUS_VER: "Há pontos a verificar na conferência entre a Apuração e a Contabilização.",
    }[status_total]
    if atencoes and status_total in (STATUS_OK, STATUS_PEND):
        conclusao += f" {atencoes} verificação(ões) complementar(es) pedem análise (aba Verificações do Excel)."
    narrativa = {"estabelecimentos": ", ".join(estabs), "configuracoes": texto_cfg, "sintetica": linhas_sint,
                 "analitica": texto_analitica, "conferencia": conferencia, "conclusao": conclusao}
    return {"resumo": resumo, "verificacoes": verif, "divergencias": atencoes, "saida": saida, "narrativa": narrativa,
            "status_total": status_total}


def relatorio_final(info, etapas, saida):
    linhas = [{"Item": "Empresa", "Valor": info.get("empresa")}, {"Item": "Período", "Valor": info.get("periodo")},
              {"Item": "Gerado em", "Valor": info.get("gerado_em")}]
    for nome, et in etapas:
        linhas.append({"Item": nome, "Valor": et.get("status", "Não executada")})
    from openpyxl import load_workbook
    with pd.ExcelWriter(saida, engine="openpyxl") as xw:
        pd.DataFrame(linhas).to_excel(xw, sheet_name="Resumo geral", index=False)
        for nome, et in etapas:
            arq = et.get("arquivo")
            if not arq or not os.path.exists(arq):
                continue
            prefixo = et.get("prefixo", nome[:10])
            origem = load_workbook(arq, read_only=True)
            for ws in origem.worksheets:
                destino = xw.book.create_sheet(f"{prefixo} - {ws.title}"[:31])
                for row in ws.iter_rows(values_only=True):
                    destino.append(row)
            origem.close()
        _ajustar(xw)
    return saida
