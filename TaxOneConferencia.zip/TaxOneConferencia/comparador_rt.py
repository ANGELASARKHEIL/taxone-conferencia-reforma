import json
import os
import re

import pandas as pd

import comparador

TOL = 0.01
IMPOSTOS = ["CBS", "IBS", "IS"]


def _num(v):
    s = str(v or "").replace("R$", "").replace("\xa0", "").strip()
    if s in ("", "-", "—"):
        return 0.0
    neg = s.startswith("-") or (s.startswith("(") and s.endswith(")"))
    s = s.strip("-()").strip()
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        return -float(s) if neg else float(s)
    except ValueError:
        return 0.0


def _doc(v):
    s = str(v or "").strip()
    return s.lstrip("0") or s


def _estab(v):
    return re.split(r"\s+[-–]\s+", str(v or "").strip())[0].strip()


def _col(df, *padroes):
    for p in padroes:
        for c in df.columns:
            if re.search(p, c, re.I):
                return c
    return None


def _ajustar(xw):
    comparador._ajustar_planilhas(xw)


def ler_apuracao(arquivos):
    out = {}
    for chave, caminho in arquivos.items():
        m = re.match(r"(CBS|IBS|IS)_(debitos|creditos)", chave)
        if not m or not os.path.exists(caminho):
            continue
        df = pd.read_csv(caminho, sep=";", dtype=str, encoding="utf-8-sig", keep_default_na=False)
        c_est = _col(df, r"^Estabelecimento")
        c_doc = _col(df, r"^N[º°o]\.? ?(do )?doc")
        c_val = _col(df, r"^Valor (do )?imposto")
        c_dat = _col(df, r"^Data fiscal", r"^Data de emiss")
        if not (c_est and c_doc and c_val):
            raise ValueError(f"Colunas inesperadas em {os.path.basename(caminho)}: {list(df.columns)}")
        n = pd.DataFrame({
            "COD_ESTAB": df[c_est].map(_estab), "NUM_DOC": df[c_doc].map(_doc), "DOC_ORIGINAL": df[c_doc],
            "DATA": df[c_dat] if c_dat else "", "VALOR_APURACAO": df[c_val].map(_num),
        })
        if "Tipo" in df.columns:
            n["TIPO_APURACAO"] = df["Tipo"]
        out.setdefault(m.group(1), {})[m.group(2)] = n
    return out


def docs_conferencia(rel_fis, rel_uti, imposto):
    partes = []
    for nome, caminho, cab in (("Fiscais", rel_fis, "SAFX3007"), ("Utilities", rel_uti, "SAFX3042")):
        if not caminho or not os.path.exists(caminho):
            continue
        rel = comparador.ler_relatorio(caminho)
        if rel.empty or "ORIGEM SAFX" not in rel.columns:
            continue
        cap = rel[rel["ORIGEM SAFX"] == cab]
        col_v = f"VLR_TOT_{imposto}"
        if col_v not in cap.columns or cap.empty:
            continue
        data = cap["DATA_FISCAL"] if "DATA_FISCAL" in cap.columns else cap.get("DAT_FISCAL", "")
        mov = cap["MOVTO_E_S"] if "MOVTO_E_S" in cap.columns else pd.Series(["9"] * len(cap), index=cap.index)
        partes.append(pd.DataFrame({
            "RELATORIO": nome, "COD_ESTAB": cap["COD_ESTAB"].map(_estab), "NUM_DOC": cap["NUM_DOCFIS"].map(_doc),
            "DOC_ORIGINAL": cap["NUM_DOCFIS"], "DATA": data, "MOVTO_E_S": mov,
            "COD_DOCTO": cap.get("COD_DOCTO", ""), "SERIE": cap.get("SERIE_DOCFIS", ""),
            "COD_FIS_JUR": cap.get("COD_FIS_JUR", ""), "VALOR_CONFERENCIA": cap[col_v].map(_num),
        }))
    if not partes:
        return pd.DataFrame(columns=["RELATORIO", "COD_ESTAB", "NUM_DOC", "MOVTO_E_S", "VALOR_CONFERENCIA"])
    df = pd.concat(partes, ignore_index=True)
    df["TIPO"] = df["MOVTO_E_S"].map(lambda m: "debitos" if str(m).strip() == "9" else "creditos")
    return df


def confrontar_conf_apuracao(rel_fis, rel_uti, apur_arquivos, saida):
    apur = ler_apuracao(apur_arquivos)
    resumo, detalhes = [], []
    for imp in IMPOSTOS:
        if imp not in apur:
            continue
        conf = docs_conferencia(rel_fis, rel_uti, imp)
        for tipo in ("debitos", "creditos"):
            a = apur[imp].get(tipo)
            if a is None:
                continue
            c = conf[(conf["TIPO"] == tipo) & (conf["VALOR_CONFERENCIA"].abs() > TOL)] if len(conf) else conf
            ca = c.groupby(["COD_ESTAB", "NUM_DOC"]).agg(
                VALOR_CONFERENCIA=("VALOR_CONFERENCIA", "sum"), QTD_CONF=("VALOR_CONFERENCIA", "size"),
                DATA_CONF=("DATA", "first"), RELATORIO=("RELATORIO", "first"), MOVTO_E_S=("MOVTO_E_S", "first"),
                COD_DOCTO=("COD_DOCTO", "first"), SERIE=("SERIE", "first"), COD_FIS_JUR=("COD_FIS_JUR", "first"),
                DOC_CONF=("DOC_ORIGINAL", "first")).reset_index() if len(c) else pd.DataFrame(
                columns=["COD_ESTAB", "NUM_DOC", "VALOR_CONFERENCIA"])
            aa = a.groupby(["COD_ESTAB", "NUM_DOC"]).agg(
                VALOR_APURACAO=("VALOR_APURACAO", "sum"), QTD_APUR=("VALOR_APURACAO", "size"),
                DATA_APUR=("DATA", "first"), DOC_APUR=("DOC_ORIGINAL", "first")).reset_index()
            m = ca.merge(aa, on=["COD_ESTAB", "NUM_DOC"], how="outer", indicator=True)
            m["VALOR_CONFERENCIA"] = pd.to_numeric(m["VALOR_CONFERENCIA"], errors="coerce").fillna(0.0)
            m["VALOR_APURACAO"] = pd.to_numeric(m["VALOR_APURACAO"], errors="coerce").fillna(0.0)
            m["DIFERENCA"] = (m["VALOR_CONFERENCIA"] - m["VALOR_APURACAO"]).round(2)

            def status(r):
                if r["_merge"] == "left_only":
                    return "Só no relatório de conferência"
                if r["_merge"] == "right_only":
                    return "Só na apuração"
                return "OK" if abs(r["DIFERENCA"]) <= TOL else "Valor diferente"
            m["STATUS"] = m.apply(status, axis=1) if len(m) else []
            m.insert(0, "TIPO", "Débito" if tipo == "debitos" else "Crédito")
            m.insert(0, "IMPOSTO", imp)
            cnt = m["STATUS"].value_counts().to_dict() if len(m) else {}
            soma = lambda st, col: round(float(m.loc[m["STATUS"] == st, col].sum()), 2) if len(m) else 0.0
            resumo.append({
                "Imposto": imp, "Tipo": "Débito" if tipo == "debitos" else "Crédito",
                "Docs conferência": len(ca), "Valor conferência": round(float(ca["VALOR_CONFERENCIA"].sum()), 2) if len(ca) else 0.0,
                "Docs apuração": len(aa), "Valor apuração": round(float(aa["VALOR_APURACAO"].sum()), 2),
                "Diferença total": round((float(ca["VALOR_CONFERENCIA"].sum()) if len(ca) else 0.0) - float(aa["VALOR_APURACAO"].sum()), 2),
                "OK": cnt.get("OK", 0), "Valor diferente": cnt.get("Valor diferente", 0),
                "Só conferência (qtd)": cnt.get("Só no relatório de conferência", 0),
                "Só conferência (valor)": soma("Só no relatório de conferência", "VALOR_CONFERENCIA"),
                "Só apuração (qtd)": cnt.get("Só na apuração", 0),
                "Só apuração (valor)": soma("Só na apuração", "VALOR_APURACAO"),
            })
            detalhes.append(m[m["STATUS"] != "OK"].drop(columns=["_merge"]))
    det = pd.concat(detalhes, ignore_index=True) if detalhes else pd.DataFrame()
    with pd.ExcelWriter(saida, engine="openpyxl") as xw:
        pd.DataFrame(resumo or [{"Resultado": "Sem relatórios da apuração para comparar"}]).to_excel(xw, sheet_name="Resumo", index=False)
        (det if len(det) else pd.DataFrame([{"Resultado": "Todos os documentos batem"}])).to_excel(
            xw, sheet_name="Divergências", index=False)
        _ajustar(xw)
    return {"resumo": resumo, "divergencias": len(det), "saida": saida}


def _totais_apuracao(apur_arquivos):
    apur = ler_apuracao(apur_arquivos)
    out = {}
    for imp, d in apur.items():
        deb = float(d["debitos"]["VALOR_APURACAO"].sum()) if "debitos" in d else 0.0
        cre = float(d["creditos"]["VALOR_APURACAO"].sum()) if "creditos" in d else 0.0
        out[imp] = {"debitos": round(deb, 2), "creditos": round(cre, 2), "saldo": round(deb - cre, 2)}
    return out


STATUS_CONC = {"UNMATCHED": "Sem correspondência no Fisco", "MATCHED": "Conciliado", "DIVERGENT": "Divergente",
               "DIVERGENCE": "Divergente", "PENDING": "Pendente"}


def ler_conciliacao(arquivos):
    partes = []
    for nome in ("debitos", "creditos"):
        caminho = arquivos.get(nome)
        if not caminho or not os.path.exists(caminho):
            continue
        df = pd.read_csv(caminho, sep=None, engine="python", dtype=str, encoding="utf-8-sig", keep_default_na=False)
        if df.empty:
            continue
        c_doc, c_est = _col(df, r"^N[º°o]\.? ?Documento"), _col(df, r"^Estabelecimento")
        c_trib, c_st = _col(df, r"^Tipo Tributo"), _col(df, r"^Status")
        partes.append(pd.DataFrame({
            "IMPOSTO": df[c_trib].str.upper() if c_trib else "CBS",
            "TIPO": "debitos" if nome == "debitos" else "creditos",
            "COD_ESTAB": df[c_est].map(_estab), "NUM_DOC": df[c_doc].map(_doc), "DOC_ORIGINAL": df[c_doc],
            "STATUS_CONCILIACAO": df[c_st].map(lambda s: STATUS_CONC.get(s.strip().upper(), s)) if c_st else "",
            "VALOR_CONTRIBUINTE": df[_col(df, r"^Valor Contribuinte")].map(_num),
            "VALOR_FISCO": df[_col(df, r"^Valor Fisco")].map(_num) if _col(df, r"^Valor Fisco") else 0.0,
        }))
    return pd.concat(partes, ignore_index=True) if partes else pd.DataFrame(
        columns=["IMPOSTO", "TIPO", "COD_ESTAB", "NUM_DOC", "STATUS_CONCILIACAO", "VALOR_CONTRIBUINTE", "VALOR_FISCO"])


def confrontar_apur_conciliacao(apur_arquivos, conc, saida):
    apur = ler_apuracao(apur_arquivos)
    cdf = ler_conciliacao(conc.get("arquivos", {}))
    tot_dash = {k: (_num(v[0]) if v and v[0] != "-" else None) for k, v in conc.get("totais", {}).items()}
    um_imposto = len(apur) == 1
    resumo, detalhes = [], []
    for imp in IMPOSTOS:
        if imp not in apur:
            continue
        for tipo in ("debitos", "creditos"):
            a = apur[imp].get(tipo)
            if a is None:
                continue
            aa = a.groupby(["COD_ESTAB", "NUM_DOC"]).agg(VALOR_APURACAO=("VALOR_APURACAO", "sum"),
                                                         DATA_APUR=("DATA", "first"), DOC_APUR=("DOC_ORIGINAL", "first")).reset_index()
            c = cdf[(cdf["IMPOSTO"] == imp) & (cdf["TIPO"] == tipo)]
            ca = c.groupby(["COD_ESTAB", "NUM_DOC"]).agg(
                VALOR_CONTRIBUINTE=("VALOR_CONTRIBUINTE", "sum"), VALOR_FISCO=("VALOR_FISCO", "sum"),
                STATUS_CONCILIACAO=("STATUS_CONCILIACAO", "first"), DOC_CONC=("DOC_ORIGINAL", "first")).reset_index() if len(c) else \
                pd.DataFrame(columns=["COD_ESTAB", "NUM_DOC", "VALOR_CONTRIBUINTE", "VALOR_FISCO", "STATUS_CONCILIACAO"])
            m = aa.merge(ca, on=["COD_ESTAB", "NUM_DOC"], how="outer", indicator=True)
            for col in ("VALOR_APURACAO", "VALOR_CONTRIBUINTE", "VALOR_FISCO"):
                m[col] = pd.to_numeric(m[col], errors="coerce").fillna(0.0)
            m["DIFERENCA_APUR_X_CONC"] = (m["VALOR_APURACAO"] - m["VALOR_CONTRIBUINTE"]).round(2)

            def status(r):
                if r["_merge"] == "left_only":
                    return "Só na apuração (sem inconsistência na conciliação)"
                if r["_merge"] == "right_only":
                    return "Só na conciliação (não está na apuração)"
                return "Valor igual" if abs(r["DIFERENCA_APUR_X_CONC"]) <= TOL else "Valor diferente"
            m["STATUS"] = m.apply(status, axis=1) if len(m) else []
            if len(m):
                so_a, so_c = m[m["_merge"] == "left_only"], m[m["_merge"] == "right_only"]

                def mapa(df, col):
                    d = {}
                    for n, e, v in zip(df["NUM_DOC"], df["COD_ESTAB"], df[col]):
                        d.setdefault(n, []).append(f"{e}: {v:,.2f}")
                    return {k: "; ".join(v) for k, v in d.items()}
                mapa_c, mapa_a = mapa(so_c, "VALOR_CONTRIBUINTE"), mapa(so_a, "VALOR_APURACAO")
                m["MESMO_NUM_EM_OUTRO_ESTAB"] = ""
                m.loc[m["_merge"] == "left_only", "MESMO_NUM_EM_OUTRO_ESTAB"] = so_a["NUM_DOC"].map(mapa_c).fillna("")
                m.loc[m["_merge"] == "right_only", "MESMO_NUM_EM_OUTRO_ESTAB"] = so_c["NUM_DOC"].map(mapa_a).fillna("")
            m.insert(0, "TIPO", "Débito" if tipo == "debitos" else "Crédito")
            m.insert(0, "IMPOSTO", imp)
            cnt = m["STATUS"].value_counts().to_dict() if len(m) else {}
            soma = lambda st, col: round(float(m.loc[m["STATUS"] == st, col].sum()), 2) if len(m) else 0.0
            total_apur = round(float(aa["VALOR_APURACAO"].sum()), 2)
            total_conc = tot_dash.get(tipo) if um_imposto else None
            if total_conc is None:
                total_conc = round(float(ca["VALOR_CONTRIBUINTE"].sum()), 2) if len(ca) else 0.0
            linha = {
                "Imposto": imp, "Tipo": "Débito" if tipo == "debitos" else "Crédito",
                "Total apuração": total_apur, "Total contribuinte (conciliação)": total_conc,
                "Diferença total": round(total_apur - total_conc, 2),
                "Docs apuração": len(aa), "Docs nas inconsistências da conciliação": len(ca),
                "Valor igual": cnt.get("Valor igual", 0), "Valor diferente": cnt.get("Valor diferente", 0),
                "Só apuração (qtd)": cnt.get("Só na apuração (sem inconsistência na conciliação)", 0),
                "Só apuração (valor)": soma("Só na apuração (sem inconsistência na conciliação)", "VALOR_APURACAO"),
                "Só conciliação (qtd)": cnt.get("Só na conciliação (não está na apuração)", 0),
                "Só conciliação (valor)": soma("Só na conciliação (não está na apuração)", "VALOR_CONTRIBUINTE"),
            }
            if len(c):
                for st, q in c["STATUS_CONCILIACAO"].value_counts().items():
                    linha[f"Conciliação: {st}"] = int(q)
            resumo.append(linha)
            detalhes.append(m.drop(columns=["_merge"]))
    det = pd.concat(detalhes, ignore_index=True) if detalhes else pd.DataFrame()
    diverg = det[det["STATUS"] != "Valor igual"] if len(det) else det
    with pd.ExcelWriter(saida, engine="openpyxl") as xw:
        pd.DataFrame(resumo or [{"Resultado": "Sem dados da apuração para comparar"}]).to_excel(xw, sheet_name="Resumo", index=False)
        (diverg if len(diverg) else pd.DataFrame([{"Resultado": "Apuração e conciliação batem documento a documento"}])).to_excel(
            xw, sheet_name="Divergências", index=False)
        (cdf if len(cdf) else pd.DataFrame([{"Resultado": "Sem inconsistências exportadas"}])).to_excel(
            xw, sheet_name="Inconsistências conciliação", index=False)
        pd.DataFrame([{"Filial": conc.get("filial"), "Período": conc.get("periodo"), "Última sessão": conc.get("ultima_sessao"),
                       "Débitos contribuinte (painel)": conc.get("totais", {}).get("debitos", ("-",))[0],
                       "Débitos fisco (painel)": conc.get("totais", {}).get("debitos", ("-", "-"))[1],
                       "Créditos contribuinte (painel)": conc.get("totais", {}).get("creditos", ("-",))[0],
                       "Créditos fisco (painel)": conc.get("totais", {}).get("creditos", ("-", "-"))[1]}]).to_excel(
            xw, sheet_name="Painel conciliação", index=False)
        _ajustar(xw)
    return {"resumo": resumo, "divergencias": len(diverg), "saida": saida}

def relatorio_final(info, etapas, saida):
    linhas = [{"Item": "Empresa", "Valor": info.get("empresa")}, {"Item": "Período", "Valor": info.get("periodo")},
              {"Item": "Gerado em", "Valor": info.get("gerado_em")}]
    for nome, et in etapas:
        linhas.append({"Item": nome, "Valor": et.get("status", "Não executada")})
    from openpyxl import load_workbook
    with pd.ExcelWriter(saida, engine="openpyxl") as xw:
        pd.DataFrame(linhas).to_excel(xw, sheet_name="Resumo geral", index=False)
        for nome, et in etapas:
            arq = et.get("arquivo")
            if not arq or not os.path.exists(arq):
                continue
            prefixo = et.get("prefixo", nome[:10])
            origem = load_workbook(arq, read_only=True)
            for ws in origem.worksheets:
                destino = xw.book.create_sheet(f"{prefixo} - {ws.title}"[:31])
                for row in ws.iter_rows(values_only=True):
                    destino.append(row)
            origem.close()
        _ajustar(xw)
    return saida
