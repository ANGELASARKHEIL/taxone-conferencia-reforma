# Conferência Reforma Tributária – TAX ONE (UAT)

Site que, com o acesso do cliente no TAX ONE UAT (`uat.onesourcetax.com`) — usuário e senha do ONESOURCE ou conta Thomson Reuters (e-mail):

1. Gera e baixa o **Relatório de Conferência dos Documentos Fiscais e Utilities – Reforma Tributária** (Data Warehouse)
2. Confronta as **SAFX3007/3008/3009/3042/3043** com o relatório (opcional)
3. Compara débitos e créditos da **Apuração Fiscal CBS-IBS-IS** com o relatório
4. Cria a sessão de **Conciliação Fiscal-Contábil** e compara com a apuração
5. Consulta e exporta a **Contabilização** de CBS (configurações, visão sintética e visão analítica) e confere o saldo com a apuração (só leitura: nada é contabilizado nem estornado)
6. Gera o **relatório final em Excel** e o **Plano de Testes em Word** (prints de tela e Excel anexados)

## Usar pelo navegador (sem instalar nada)

1. Nesta página, clique em **Code › Codespaces › Create codespace on main**.
2. Aguarde a preparação (alguns minutos só na primeira vez).
3. O site abre sozinho numa nova aba. Se não abrir, vá na aba **PORTS** do Codespace e clique no globo da porta **5055**.
4. Escolha como entra no ONESOURCE (usuário e senha, ou conta Thomson Reuters por e-mail), informe empresa e período e clique em **Executar relatório** ou **Executar todas as etapas**.

Ao terminar, baixe os resultados pelos botões do site. Para não consumir horas de Codespaces, pare o codespace em <https://github.com/codespaces> quando não estiver usando.

## Usar no próprio computador (Windows)

Requisitos: Python 3.10+, Microsoft Edge e Microsoft Word.

1. Baixe o repositório (**Code › Download ZIP**) e extraia.
2. Na primeira vez, rode `instalar.bat`.
3. Para usar, rode `iniciar.bat` – o site abre em `http://127.0.0.1:5055`.

## Dois jeitos de entrar no ONESOURCE

- **Usuário e senha do ONESOURCE:** o login tradicional.
- **Conta Thomson Reuters (e-mail):** o robô clica em *Thomson Reuters sign-in*, informa o e-mail e escolhe o cliente na lista de contas. Com e-mail `@thomsonreuters.com`, o navegador do robô para na tela de login corporativo: digite ID e senha (se a tela pedir) e aprove o PingID nessa janela (o robô espera até 10 minutos). Com e-mail de cliente, o robô digita a senha cadastrada no TAX ONE dele. Se o robô não conseguir escolher o cliente sozinho na lista de contas, ele avisa e espera você escolher o cliente e clicar em *Continue* na janela; depois segue sozinho. Se o Edge fechar sozinho durante o login, o robô tenta de novo no Chrome (se instalado) e passa a usar o navegador que funcionou; o campo *Navegador do robô* permite fixar Edge ou Chrome. Só funciona no Windows. A janela do robô só é necessária para o login: depois dele, o robô fecha a janela de propósito e segue em segundo plano com a mesma sessão (com *Prints com a tela inteira do computador* marcado, a janela fica aberta até o fim: não minimize nem feche). Com o acesso salvo (até 12 horas), as próximas etapas já começam em segundo plano; se ele não valer mais, o robô avisa e abre a janela para você refazer o login.

## Segurança

- A senha do cliente fica apenas na memória do site durante a execução e nunca é gravada em disco.
- Com a conta Thomson Reuters, o acesso (cookies da sessão, nunca a senha) pode ser lembrado por 12 horas para não pedir o PingID a cada etapa. Fica criptografado pelo Windows em `%LOCALAPPDATA%\TaxOneConferencia\acessos`; o botão **Esquecer acessos salvos** apaga.
- Se o login pela conta Thomson Reuters falhar ou precisar de ajuda manual, o robô salva um diagnóstico (`.json` e `.png`) em `%LOCALAPPDATA%\TaxOneConferencia\diagnostico`, fora das evidências (a lista de contas mostra outros clientes). Se o navegador fechar durante o login, ele salva também `login_ciam_eventos_AAAAMMDD_HHMMSS.json`, com a linha do tempo (endereços sem parâmetros, abas e janelas) e sem nada do que foi digitado.
- Se uma etapa falhar depois do login (Apuração, Conciliação ou Contabilização), o robô salva `erro_tela.png` e `erro_tela.json` na pasta da etapa em `execucoes/<execução>/` (print da tela, se a janela estava visível, tamanho da janela, estado dos campos de seleção e o que estava cobrindo o clique). Os endereços ficam sem parâmetros e nada do que foi digitado é guardado.
- Cada pessoa usa o seu próprio codespace (o endereço do site é privado e exige login no GitHub).
- Os resultados ficam na pasta `execucoes/`, que não é enviada para o repositório.
