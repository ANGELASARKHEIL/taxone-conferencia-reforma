# Conferência Reforma Tributária – TAX ONE (UAT)

Site que, com o usuário e a senha do cliente no TAX ONE UAT (`uat.onesourcetax.com`):

1. Gera e baixa o **Relatório de Conferência dos Documentos Fiscais e Utilities – Reforma Tributária** (Data Warehouse)
2. Confronta as **SAFX3007/3008/3009/3042/3043** com o relatório (opcional)
3. Compara débitos e créditos da **Apuração Fiscal CBS-IBS-IS** com o relatório
4. Cria a sessão de **Conciliação Fiscal-Contábil** e compara com a apuração
5. Gera o **relatório final em Excel** e o **Plano de Testes em Word** (prints de tela e Excel anexados)

## Usar pelo navegador (sem instalar nada)

1. Nesta página, clique em **Code › Codespaces › Create codespace on main**.
2. Aguarde a preparação (alguns minutos só na primeira vez).
3. O site abre sozinho numa nova aba. Se não abrir, vá na aba **PORTS** do Codespace e clique no globo da porta **5055**.
4. Informe usuário e senha do cliente, empresa e período e clique em **Executar relatório** ou **Executar todas as etapas**.

Ao terminar, baixe os resultados pelos botões do site. Para não consumir horas de Codespaces, pare o codespace em <https://github.com/codespaces> quando não estiver usando.

## Usar no próprio computador (Windows)

Requisitos: Python 3.10+, Microsoft Edge e Microsoft Word.

1. Baixe o repositório (**Code › Download ZIP**) e extraia.
2. Na primeira vez, rode `instalar.bat`.
3. Para usar, rode `iniciar.bat` – o site abre em `http://127.0.0.1:5055`.

## Segurança

- A senha do cliente fica apenas na memória do site durante a execução e nunca é gravada em disco.
- Cada pessoa usa o seu próprio codespace (o endereço do site é privado e exige login no GitHub).
- Os resultados ficam na pasta `execucoes/`, que não é enviada para o repositório.
