import os
import re
import threading
import time
import traceback
import uuid
import webbrowser

from flask import Flask, abort, jsonify, render_template_string, request, send_from_directory, url_for
from werkzeug.utils import secure_filename

import comparador
import comparador_rt
import plano_teste
import robo_rt
import robo_taxone

AQUI = os.path.dirname(os.path.abspath(__file__))
EXECUCOES = os.path.join(AQUI, "execucoes")
PORTA = int(os.environ.get("TAXONE_CONF_PORTA", "5055"))

app = Flask(__name__)
app.json.sort_keys = False
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024
JOBS = {}
ETAPAS = ["rel", "safx", "apur", "conc", "final"]

PAGINA = """<!doctype html>
<html lang="pt-br"><head><meta charset="utf-8"><title>Conferência Reforma Tributária — TAX ONE</title>
<style>
 body{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f4f4f4;color:#333}
 header{background:#000;color:#fff;padding:14px 28px} header b{color:#fa6400;font-size:13px;letter-spacing:.5px} header span{font-size:20px}
 main{max-width:1000px;margin:24px auto}
 section{background:#fff;padding:20px 30px;border-top:3px solid #fa6400;margin-bottom:20px}
 section.off{opacity:.45;pointer-events:none}
 h2{font-weight:400;margin:0 0 6px} h2 i{font-style:normal;background:#fa6400;color:#fff;border-radius:50%;padding:1px 9px;margin-right:8px;font-size:16px}
 p.desc{margin:0 0 10px;color:#666;font-size:13px}
 label{display:block;font-size:13px;margin:12px 0 4px}
 input[type=text],input[type=password],select{width:100%;padding:8px;border:1px solid #bbb;box-sizing:border-box;font-size:14px}
 .row{display:flex;gap:16px} .row>div{flex:1} small{color:#777}
 details{margin-top:12px;font-size:13px} summary{cursor:pointer;color:#555}
 button{background:#fa6400;color:#fff;border:0;padding:11px 26px;font-size:14px;cursor:pointer;margin:16px 10px 0 0}
 button:hover{background:#d45500} button:disabled{background:#aaa;cursor:default}
 button.sec{background:#fff;color:#333;border:1px solid #999} button.sec:hover{background:#eee}
 .status{margin-top:14px;font-size:14px} .ok{color:#2e7d32;font-weight:600} .err{color:#c62828;font-weight:600} .run{color:#e65100;font-weight:600} .skip{color:#777;font-weight:600}
 a.dl{display:inline-block;background:#333;color:#fff;padding:9px 16px;text-decoration:none;margin:10px 8px 0 0;font-size:13px}
 a.dl.main{background:#2e7d32} a.dl.warn{background:#c62828} a.dl.final{background:#fa6400;font-size:15px;padding:12px 22px}
 pre{background:#111;color:#ddd;padding:10px;max-height:220px;overflow:auto;font-size:12px}
 table{border-collapse:collapse;width:100%;font-size:12px;margin-top:12px} th,td{border:1px solid #ddd;padding:4px 7px;text-align:left} th{background:#f0f0f0}
 td.num{text-align:right} tr.bad td{background:#fff3f0}
 .drop{border:2px dashed #bbb;padding:16px;text-align:center;margin-top:6px;background:#fafafa}
 ul.files{font-size:13px;margin:8px 0 0;padding-left:18px}
</style></head>
<body>
<header><b>THOMSON REUTERS</b><br><span>Conferência Reforma Tributária — TAX ONE</span></header>
<main>

<section id="s_rel">
 <h2><i>1</i>Relatório de conferência (obrigatório)</h2>
 <p class="desc">Data Warehouse › Relatórios › Conferências › Documentos Fiscais e Utilities - Reforma Tributária.</p>
 <form id="f_rel">
  <p class="desc" style="margin:0 0 4px">Ambiente: <b>TAX ONE UAT</b> — uat.onesourcetax.com</p>
  <div class="row">
   <div><label>Usuário</label><input type="text" name="usuario" autocomplete="off" required></div>
   <div><label>Senha</label><input type="password" name="senha" autocomplete="new-password" required></div>
  </div>
  <div class="row">
   <div><label>Empresa (código)</label><input type="text" name="empresa" placeholder="ex.: C04" required></div>
   <div><label>Período (MM/AAAA)</label><input type="text" name="periodo" placeholder="10/2026" required pattern="\\d{2}/\\d{4}"></div>
  </div>
  <details><summary>Opções avançadas</summary>
   <div class="row">
    <div><label>Estabelecimento</label><input type="text" name="estabelecimento" value="[ Todos ]"></div>
    <div><label>Origem</label><input type="text" name="origem" value="Todas"></div>
   </div>
  </details>
  <label style="display:flex;gap:8px;align-items:center;margin-top:14px"><input type="checkbox" name="tela_real" value="1" checked> Prints com a tela inteira do computador, mostrando a data e a hora do Windows (o navegador do robô aparece na tela durante a execução — evite usar o computador enquanto ele roda)</label>
  <small>A senha fica só na memória deste site enquanto as etapas rodam (é usada de novo na Apuração e na Conciliação) e nunca é gravada em disco.</small><br>
  <button id="b_rel" type="submit">Executar relatório</button>
  <div style="margin-top:22px;padding:14px 16px;background:#fff7f0;border:1px solid #fad3b5">
   <b>Executar tudo de uma vez</b> — roda as etapas 1 a 5 em sequência (relatório › SAFX › apuração › conciliação › relatório final e plano de teste em Word). Depois é só baixar os resultados de cada etapa.
   <label>SAFX para a etapa 2 (opcional — sem arquivos, a etapa 2 é pulada)</label>
   <input type="file" id="safx_tudo" multiple accept=".txt,.csv,.xlsx,.xlsm">
   <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="criar_tudo" checked> Criar nova sessão de conciliação</label>
   <button id="b_tudo" type="button">Executar todas as etapas</button>
  </div>
 </form>
 <div class="status" id="st_rel"></div><div id="dl_rel"></div>
</section>

<section id="s_safx" class="off">
 <h2><i>2</i>Análise SAFX x relatório (opcional)</h2>
 <p class="desc">Anexe as SAFX que tiver (3007, 3008, 3009, 3042, 3043). O nome do arquivo precisa conter o número da SAFX.</p>
 <form id="f_safx">
  <div class="drop"><input type="file" id="safx" name="safx" multiple accept=".txt,.csv,.xlsx,.xlsm"></div>
  <ul class="files" id="lista"></ul>
  <small>O alinhamento dos campos é descoberto automaticamente pelos dados (posição na SAFX x coluna do relatório, inclusive casas decimais); o resultado traz a aba "Mapeamento de campos".</small><br>
  <button id="b_safx" type="submit">Executar análise</button>
  <button id="b_pular" type="button" class="sec">Pular esta etapa</button>
 </form>
 <div class="status" id="st_safx"></div><div id="dl_safx"></div><div id="res_safx"></div>
</section>

<section id="s_apur" class="off">
 <h2><i>3</i>Apuração x relatório de conferência</h2>
 <p class="desc">Reforma Tributária do Consumo › Apuração Fiscal CBS-IBS-IS: exporta débitos e créditos do mesmo período e compara documento a documento.</p>
 <button id="b_apur" type="button">Gerar apuração e comparar</button>
 <div class="status" id="st_apur"></div><div id="dl_apur"></div><div id="res_apur"></div>
</section>

<section id="s_conc" class="off">
 <h2><i>4</i>Conciliação Fiscal-Contábil x apuração</h2>
 <p class="desc">Reforma Tributária do Consumo › Conciliação Fiscal-Contábil: empresa, primeira filial e mesmo período. Cria a sessão Contribuinte x Fisco, aguarda concluir, exporta as inconsistências de débitos e créditos e compara com a apuração.</p>
 <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="criar" checked> Criar nova sessão de conciliação (desmarque para usar a última sessão já processada do período)</label>
 <button id="b_conc" type="button">Gerar conciliação e comparar</button>
 <div class="status" id="st_conc"></div><div id="dl_conc"></div><div id="res_conc"></div>
</section>

<section id="s_final" class="off">
 <h2><i>5</i>Relatório final</h2>
 <p class="desc">Um Excel consolidado com o resumo e as divergências de todas as etapas e o <b>plano de teste em Word</b> (modelo do cliente preenchido com cliente, ambiente, período, prints de tela de cada etapa e os Excel anexados). É gerado automaticamente ao fim da etapa 4.</p>
 <button id="b_final" type="button" class="sec">Gerar relatório final agora</button>
 <div class="status" id="st_final"></div><div id="dl_final"></div>
</section>

<section><h2 style="font-size:15px">Andamento</h2><pre id="log">—</pre></section>
</main>
<script>
let JOB = new URLSearchParams(location.search).get('job');
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmt = v => typeof v === 'number' ? v.toLocaleString('pt-BR', {maximumFractionDigits: 2}) : esc(v);

$('safx').onchange = () => { $('lista').innerHTML = [...$('safx').files].map(f => `<li>${esc(f.name)}</li>`).join(''); };

async function post(url, body, st){
  const r = await fetch(url, {method:'POST', body});
  const j = await r.json().catch(() => ({erro:'Erro de comunicação com o site.'}));
  if (!r.ok) { $(st).innerHTML = `<span class="err">${esc(j.erro)}</span>`; return null; }
  return j;
}

$('f_rel').onsubmit = async e => {
  e.preventDefault(); $('b_rel').disabled = true;
  const j = await post('relatorio', new FormData($('f_rel')), 'st_rel');
  if (!j) { $('b_rel').disabled = false; return; }
  $('f_rel').senha.value = ''; JOB = j.id; history.replaceState(null, '', '?job=' + JOB);
  ['safx','apur','conc','final'].forEach(k => { $('st_'+k).innerHTML=''; $('dl_'+k).innerHTML=''; if ($('res_'+k)) $('res_'+k).innerHTML=''; });
  poll();
};
$('b_tudo').onclick = async () => {
  const f1 = $('f_rel'); if (!f1.reportValidity()) return;
  $('b_tudo').disabled = true; $('b_rel').disabled = true;
  const fd = new FormData(f1);
  [...$('safx_tudo').files].forEach(x => fd.append('safx', x));
  fd.append('criar', $('criar_tudo').checked ? '1' : '0');
  const j = await post('executar_tudo', fd, 'st_rel');
  if (!j) { $('b_tudo').disabled = false; $('b_rel').disabled = false; return; }
  f1.senha.value = ''; JOB = j.id; history.replaceState(null, '', '?job=' + JOB);
  ['safx','apur','conc','final'].forEach(k => { $('st_'+k).innerHTML=''; $('dl_'+k).innerHTML=''; if ($('res_'+k)) $('res_'+k).innerHTML=''; });
  poll();
};
$('f_safx').onsubmit = async e => {
  e.preventDefault();
  if (!$('safx').files.length) { $('st_safx').innerHTML = '<span class="err">Anexe pelo menos uma SAFX ou clique em Pular.</span>'; return; }
  if (await post(`job/${JOB}/analise`, new FormData($('f_safx')), 'st_safx')) poll();
};
$('b_pular').onclick = async () => { if (await post(`job/${JOB}/pular`, new FormData(), 'st_safx')) poll(); };
$('b_apur').onclick = async () => { if (await post(`job/${JOB}/apuracao`, new FormData(), 'st_apur')) poll(); };
$('b_conc').onclick = async () => { const f = new FormData(); f.append('criar', $('criar').checked ? '1' : '0');
  if (await post(`job/${JOB}/conciliacao`, f, 'st_conc')) poll(); };
$('b_final').onclick = async () => { if (await post(`job/${JOB}/final`, new FormData(), 'st_final')) poll(); };

function tabela(linhas, cols){
  if (!linhas || !linhas.length) return '';
  cols = cols || Object.keys(linhas[0]);
  return '<table><tr>' + cols.map(c => `<th>${esc(c)}</th>`).join('') + '</tr>' + linhas.map(l => {
    const bad = (l['Status'] && l['Status'] !== 'OK' && l['Status'] !== 'Confrontado') || (l['Diferença total'] && Math.abs(l['Diferença total']) > 0.01);
    return `<tr class="${bad?'bad':''}">` + cols.map(c => `<td class="${typeof l[c]==='number'?'num':''}">${fmt(l[c])}</td>`).join('') + '</tr>'; }).join('') + '</table>';
}
const COLS_SAFX = ["SAFX","Arquivo","Registros na SAFX","OK","Com divergência","Não encontrados","Fora do período","Status"];

async function poll(){
  if (!JOB) return;
  const r = await fetch(`job/${JOB}/status`); if (!r.ok) return;
  const s = await r.json();
  $('log').textContent = s.log.join('\\n') || '—'; $('log').scrollTop = 1e9;
  let rodando = false;
  for (const k of ['rel','safx','apur','conc','final']) {
    const E = s.etapas[k];
    $('s_'+k).classList.toggle('off', !E.habilitada);
    if (E.status) {
      const cls = E.pulada ? 'skip' : (!E.fim ? 'run' : (E.ok ? 'ok' : 'err'));
      const ic = E.pulada ? '⤼' : (!E.fim ? '⏳' : (E.ok ? '✔' : '✖'));
      $('st_'+k).innerHTML = `<span class="${cls}">${ic} ${esc(E.status)}${E.fim ? '' : '...'}</span>`;
    }
    $('dl_'+k).innerHTML = E.arquivos.map(a => `<a class="dl ${a.cls||''}" href="${a.url}">⬇ ${esc(a.rotulo)}</a>`).join('');
    if ($('res_'+k)) $('res_'+k).innerHTML = tabela(E.resumo, k === 'safx' ? COLS_SAFX : null);
    if (E.status && !E.fim) rodando = true;
  }
  if (s.tudo) rodando = true;
  document.querySelectorAll('section button').forEach(b => { if (b.id !== 'b_rel') b.disabled = rodando; });
  $('b_rel').disabled = rodando;
  if (rodando) setTimeout(poll, 3000);
}
poll();
</script>
</body></html>
"""


def _codigo(txt):
    return (txt or "").split(" - ")[0].strip()


def _log(j, msg):
    j["log"].append(time.strftime("%H:%M:%S ") + msg)


def _url(jid, j, caminho):
    return url_for("arquivo", jid=jid, rel=os.path.relpath(caminho, j["pasta"]).replace("\\", "/"))


def _nova_etapa():
    return {"status": None, "fim": False, "ok": False, "pulada": False, "arquivos": [], "resumo": None, "saida": None}


def _iniciar(j, chave, status):
    e = j[chave] = _nova_etapa()
    e["status"] = status
    return e


def _executar(jid, chave, alvo, *args):
    j = JOBS[jid]
    e = j[chave]

    def log(m):
        _log(j, m)
        e["status"] = m.rstrip(".")
    try:
        alvo(j, e, log, *args)
        e["ok"] = True
    except robo_taxone.ErroRobo as ex:
        _log(j, "ERRO: " + str(ex))
        e["status"] = str(ex)
    except Exception as ex:
        _log(j, "ERRO inesperado: " + str(ex))
        _log(j, traceback.format_exc())
        e["status"] = "Erro inesperado: " + str(ex)
    finally:
        e["fim"] = True


def _base(j):
    return f"{_codigo(j['empresa'])}_{j['periodo'].replace('/', '')}"


def _etapa_relatorio(j, e, log, senha):
    res = robo_taxone.gerar_relatorio(
        j["usuario"], senha, j["empresa"], j["periodo"], os.path.join(j["pasta"], "relatorio"),
        estabelecimento=j["estabelecimento"], origem=j["origem"], empresas=[_codigo(j["empresa"])], log=log,
        evid_dir=j["evid"], ambiente=j["amb_sel"], tela_real=j["tela_real"])
    j["rel_fiscais"], j["rel_utilities"] = res.get("fiscais"), res.get("utilities")
    j["ambiente"], j["processo"] = res.get("ambiente") or {}, res.get("processo")
    for tipo, rotulo in (("fiscais", "Relatório Documentos Fiscais"), ("utilities", "Relatório Utilities")):
        if res.get(tipo):
            e["arquivos"].append((rotulo, res[tipo], ""))
    e["status"] = f"Relatório gerado (processo {res.get('processo')})"


def _etapa_safx(j, e, log, arquivos):
    log("Analisando " + ", ".join(os.path.basename(a) for a in arquivos))
    base = f"{_base(j)}_{time.strftime('%H%M%S')}"
    saida = os.path.join(j["pasta"], f"Resultado_SAFX_x_Relatorio_{base}.xlsx")
    nao_enc = os.path.join(j["pasta"], f"Documentos_Nao_Encontrados_{base}.xlsx")
    r = comparador.confrontar(arquivos, j["rel_fiscais"], j["rel_utilities"], saida,
                              periodo=j["periodo"], saida_nao_encontrados=nao_enc)
    e["resumo"], e["saida"], e["extras"] = r["resumo"], saida, [nao_enc]
    e["nomes"] = [os.path.basename(a) for a in arquivos]
    e["arquivos"] += [("Resultado da análise", saida, "main"),
                      (f"Documentos não encontrados ({r['nao_integrados']})", nao_enc, "warn")]
    e["status"] = f"Análise concluída: {r['divergencias']} divergência(s), {r['nao_integrados']} não encontrado(s)"
    _log(j, e["status"])


def _etapa_apuracao(j, e, log):
    pasta = os.path.join(j["pasta"], "apuracao")
    arqs = robo_rt.gerar_apuracao(j["usuario"], j["_senha"], j["empresa"], j["periodo"], pasta, log=log,
                                  evid_dir=j["evid"], ambiente=j["amb_sel"], tela_real=j["tela_real"])
    j["apur_arquivos"] = arqs
    log("Comparando apuração x relatório de conferência")
    saida = os.path.join(j["pasta"], f"Resultado_Apuracao_x_Conferencia_{_base(j)}.xlsx")
    r = comparador_rt.confrontar_conf_apuracao(j["rel_fiscais"], j["rel_utilities"], arqs, saida)
    e["resumo"], e["saida"] = r["resumo"], saida
    e["arquivos"].append(("Resultado Apuração x Conferência", saida, "main"))
    for k in sorted(arqs):
        e["arquivos"].append((f"Apuração {k.replace('_', ' ')}", arqs[k], ""))
    e["status"] = f"Comparação concluída: {r['divergencias']} documento(s) com diferença"
    _log(j, e["status"])


def _etapa_conc(j, e, log, criar):
    pasta = os.path.join(j["pasta"], "conciliacao")
    res = robo_rt.gerar_conciliacao(j["usuario"], j["_senha"], j["empresa"], j["periodo"], pasta, log=log, criar=criar,
                                    evid_dir=j["evid"], ambiente=j["amb_sel"], tela_real=j["tela_real"])
    j["conc_res"] = res
    log("Comparando conciliação x apuração")
    saida = os.path.join(j["pasta"], f"Resultado_Conciliacao_x_Apuracao_{_base(j)}.xlsx")
    r = comparador_rt.confrontar_apur_conciliacao(j["apur_arquivos"], res, saida)
    e["resumo"], e["saida"] = r["resumo"], saida
    e["arquivos"].append(("Resultado Conciliação x Apuração", saida, "main"))
    for k, c in sorted(res["arquivos"].items()):
        e["arquivos"].append((f"Conciliação {k}", c, ""))
    e["status"] = f"Comparação concluída: {r['divergencias']} documento(s) com diferença (sessão {res['ultima_sessao']})"
    _log(j, e["status"])
    j["_senha"] = None
    _gerar_final(j)


def _texto_conclusao(resumo, chaves):
    partes = []
    for l in resumo or []:
        itens = []
        for k in chaves:
            v = l.get(k)
            if v is None or v == "" or (isinstance(v, float) and (v != v or v == 0)) or v == 0:
                continue
            texto = plano_teste.formatar_valor(v, k)
            if plano_teste.monetario(k):
                texto = "R$ " + texto
            itens.append(f"{k}: {texto}")
        cab = " ".join(str(l.get(c, "")) for c in ("Imposto", "Tipo", "SAFX") if l.get(c))
        if itens:
            partes.append(f"{cab} — " + "; ".join(itens))
    return ". ".join(partes) + ("." if partes else "")


def _gerar_word(j, final_xlsx):
    amb = j.get("ambiente") or {}
    base = _base(j)
    bases = os.path.join(j["pasta"], "bases")
    os.makedirs(bases, exist_ok=True)
    rel_x = plano_teste._converter_para_xlsx(
        [("Documentos Fiscais", j["rel_fiscais"]), ("Utilities", j["rel_utilities"])],
        os.path.join(bases, f"Relatorio_Conferencia_{base}.xlsx")) if j["rel_fiscais"] else None
    apur_x = plano_teste._converter_para_xlsx(
        [(k.replace("_", " "), v) for k, v in sorted((j["apur_arquivos"] or {}).items())],
        os.path.join(bases, f"Bases_Apuracao_{base}.xlsx")) if j["apur_arquivos"] else None
    conc = j.get("conc_res") or {}
    conc_x = plano_teste._converter_para_xlsx(
        [(f"Conciliação {k}", v) for k, v in sorted(conc.get("arquivos", {}).items())],
        os.path.join(bases, f"Bases_Conciliacao_{base}.xlsx")) if conc.get("arquivos") else None

    def st(k):
        e = j[k]
        return "Pulada pelo usuário" if e["pulada"] else (e["status"] or "Não executada")
    etapas = [
        {"titulo": "Módulo Data Warehouse – Relatório de Conferência", "status": st("rel"),
         "metodo": "Relatório de Conferência dos Documentos Fiscais e Utilities – Reforma Tributária gerado no módulo Data "
                   "Warehouse (agrupamento Básicos), execução imediata, origem Todas, baixado pela Transferência de arquivos. "
                   "É a base de referência para os confrontos das etapas seguintes.",
         "excels": [rel_x]},
        {"titulo": "Validação das SAFX x Relatório de Conferência", "status": st("safx"), "resumo": j["safx"]["resumo"],
         "metodo": "Cada registro das SAFX anexadas foi localizado no Relatório de Conferência pela chave do documento (empresa, "
                   "estabelecimento, data fiscal, movimento, norma/devolução, tipo de documento, pessoa física/jurídica, número, "
                   "série e subsérie, mais o número do item nas SAFX de itens). Os demais campos foram comparados valor a valor; "
                   "a correspondência entre posição da SAFX e coluna do relatório (inclusive casas decimais) foi identificada "
                   "automaticamente pelos dados e está na aba Mapeamento de campos.",
         "colunas": ["SAFX", "Arquivo", "Registros na SAFX", "OK", "Com divergência", "Não encontrados", "Fora do período"],
         "conclusao": _texto_conclusao(j["safx"]["resumo"], ["Registros na SAFX", "OK", "Com divergência", "Não encontrados"]),
         "excels": [j["safx"].get("saida")] + (j["safx"].get("extras") or [])},
        {"titulo": "Módulo Apuração Fiscal CBS-IBS-IS x Relatório de Conferência", "status": st("apur"), "resumo": j["apur"]["resumo"],
         "metodo": "Os relatórios de Débitos e Créditos exportados da Apuração foram confrontados documento a documento "
                   "(estabelecimento + número do documento) com as capas do Relatório de Conferência: saídas (movimento 9) "
                   "como débito e entradas como crédito, comparando o valor total do tributo.",
         "colunas": ["Imposto", "Tipo", "Docs conferência", "Valor conferência", "Docs apuração", "Valor apuração",
                     "Diferença total", "OK", "Valor diferente", "Só conferência (qtd)", "Só apuração (qtd)"],
         "conclusao": _texto_conclusao(j["apur"]["resumo"], ["OK", "Valor diferente", "Só conferência (qtd)",
                                                           "Só conferência (valor)", "Só apuração (qtd)", "Só apuração (valor)"]),
         "excels": [j["apur"].get("saida"), apur_x]},
        {"titulo": "Módulo Conciliação Fiscal-Contábil x Apuração", "status": st("conc"), "resumo": j["conc"]["resumo"],
         "metodo": "Foi criada a sessão de conciliação Contribuinte x Fisco do período e exportadas as inconsistências de "
                   "documentos, débitos e créditos. O total do Contribuinte no painel da conciliação e os documentos exportados "
                   "foram confrontados com os débitos e créditos da Apuração.",
         "colunas": ["Imposto", "Tipo", "Total apuração", "Total contribuinte (conciliação)", "Diferença total",
                     "Valor igual", "Valor diferente", "Só apuração (qtd)", "Só conciliação (qtd)"],
         "conclusao": _texto_conclusao(j["conc"]["resumo"], ["Diferença total", "Valor igual", "Valor diferente",
                                                           "Só apuração (qtd)", "Só conciliação (qtd)"]),
         "excels": [j["conc"].get("saida"), conc_x]},
        {"titulo": "Relatório final consolidado", "status": "Gerado",
         "metodo": "Planilha única com o resumo geral e as abas de resultado de todas as etapas executadas.",
         "excels": [final_xlsx]},
    ]
    empresa_nome = amb.get("empresa_nome") or j["empresa"]
    tipos_safx = sorted({comparador.identificar_safx(n) or n for n in (j["safx"].get("nomes") or [])})
    estab = conc.get("filial") or ("Todos" if "Todos" in (j["estabelecimento"] or "Todos") else j["estabelecimento"])
    info = {"cliente": amb.get("cliente"), "ambiente_completo": amb.get("ambiente_completo"),
            "safx": tipos_safx, "estabelecimentos": estab,
            "empresa": j["empresa"], "empresa_nome": empresa_nome, "periodo": j["periodo"],
            "usuario": j["usuario"], "usuario_nome": amb.get("usuario_nome")}
    razao = empresa_nome.split(" - ", 1)[-1]
    razao = re.sub(r"\s+", " ", re.sub(r'[\\/:*?"<>|.,]+', " ", razao)).strip() or _codigo(j["empresa"])
    saida = os.path.join(j["pasta"], f"{razao}_Plano de Teste_{j['periodo'].replace('/', '-')}.docx")
    return plano_teste.gerar_plano(info, etapas, j["evid"], saida)


def _gerar_final(j):
    f = j["final"] = _nova_etapa()
    f["status"] = "Gerando relatório final e plano de teste"
    try:
        nomes = (("Relatório de conferência", "rel", "Relatorio"), ("SAFX x Relatório", "safx", "SAFX"),
                 ("Apuração x Conferência", "apur", "Apur x Conf"), ("Conciliação x Apuração", "conc", "Conc x Apur"))
        etapas = []
        for nome, k, pref in nomes:
            e = j[k]
            st = "Pulada" if e["pulada"] else (e["status"] or "Não executada")
            etapas.append((nome, {"status": st, "arquivo": e.get("saida"), "prefixo": pref}))
        saida = os.path.join(j["pasta"], f"Relatorio_Final_{_base(j)}_{time.strftime('%H%M%S')}.xlsx")
        comparador_rt.relatorio_final({"empresa": j["empresa"], "periodo": j["periodo"],
                                       "gerado_em": time.strftime("%d/%m/%Y %H:%M")}, etapas, saida)
        f["arquivos"].append(("Relatório final (Excel)", saida, "final"))
        f["saida"] = saida
        _log(j, "Relatório final gerado. Montando o plano de teste em Word...")
        word = _gerar_word(j, saida)
        f["arquivos"].append(("Plano de teste (Word)", word, "final"))
        f.update(status="Relatório final e plano de teste gerados", ok=True)
        _log(j, "Plano de teste em Word gerado.")
    except Exception as ex:
        _log(j, "ERRO no relatório final: " + str(ex))
        _log(j, traceback.format_exc())
        f["status"] = "Erro no relatório final: " + str(ex)
        f["ok"] = bool(f["arquivos"])
    finally:
        f["fim"] = True


def _ocupado(j):
    return any(j[k]["status"] and not j[k]["fim"] for k in ETAPAS)


def _habilitadas(j):
    rel_ok = j["rel"]["ok"]
    safx_ok = j["safx"]["ok"] or j["safx"]["pulada"]
    return {"rel": True, "safx": rel_ok, "apur": rel_ok and safx_ok, "conc": j["apur"]["ok"],
            "final": j["apur"]["ok"] or j["final"]["ok"]}


def _job(jid):
    return JOBS.get(jid) or abort(404)


@app.get("/")
def index():
    return render_template_string(PAGINA)


def _novo_job(fm):
    usuario, senha = fm.get("usuario", "").strip(), fm.get("senha", "")
    empresa, periodo = fm.get("empresa", "").strip(), fm.get("periodo", "").strip()
    if not usuario or not senha or not empresa:
        return None, "Preencha usuário, senha e empresa."
    amb_sel = "QA"
    if not re.fullmatch(r"(0[1-9]|1[0-2])/\d{4}", periodo):
        return None, "Período inválido. Use MM/AAAA."
    jid = time.strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]
    pasta = os.path.join(EXECUCOES, jid)
    j = {"id": jid, "pasta": pasta, "evid": os.path.join(pasta, "evidencias"), "usuario": usuario, "empresa": empresa,
         "amb_sel": amb_sel, "tela_real": fm.get("tela_real") == "1",
         "periodo": periodo, "estabelecimento": fm.get("estabelecimento", "").strip() or "[ Todos ]",
         "origem": fm.get("origem", "").strip() or "Todas", "_senha": senha, "log": [], "tudo": False,
         "rel_fiscais": None, "rel_utilities": None, "apur_arquivos": None, "conc_res": None,
         "ambiente": {}, "processo": None}
    for k in ETAPAS:
        j[k] = _nova_etapa()
    JOBS[jid] = j
    os.makedirs(pasta, exist_ok=True)
    return j, None


def _salvar_safx(j, arquivos_enviados):
    pasta = os.path.join(j["pasta"], "safx", time.strftime("%H%M%S"))
    os.makedirs(pasta, exist_ok=True)
    arquivos = []
    for f in arquivos_enviados:
        if f and f.filename:
            caminho = os.path.join(pasta, secure_filename(f.filename) or f"safx_{len(arquivos)}.txt")
            f.save(caminho)
            arquivos.append(caminho)
    sem_tipo = [os.path.basename(a) for a in arquivos if not comparador.identificar_safx(a)]
    if sem_tipo:
        return arquivos, ("Não identifiquei a SAFX pelo nome do arquivo: " + ", ".join(sem_tipo) +
                          ". O nome precisa conter 3007, 3008, 3009, 3042 ou 3043.")
    return arquivos, None


def _rodar_tudo(jid, senha, safx, criar):
    j = JOBS[jid]
    j["tudo"] = True
    try:
        _log(j, "Execução completa iniciada (etapas 1 a 5).")
        _iniciar(j, "rel", "Iniciando")
        _executar(jid, "rel", _etapa_relatorio, senha)
        if not j["rel"]["ok"]:
            return
        if safx:
            _iniciar(j, "safx", "Analisando")
            _executar(jid, "safx", _etapa_safx, safx)
        else:
            e = _iniciar(j, "safx", "Etapa pulada (nenhuma SAFX anexada)")
            e.update(fim=True, pulada=True)
            _log(j, "Análise SAFX pulada (nenhuma SAFX anexada).")
        _iniciar(j, "apur", "Iniciando")
        _executar(jid, "apur", _etapa_apuracao)
        if not j["apur"]["ok"]:
            _gerar_final(j)
            return
        _iniciar(j, "conc", "Iniciando")
        _executar(jid, "conc", _etapa_conc, criar)
        if not j["conc"]["ok"]:
            _gerar_final(j)
        _log(j, "Execução completa finalizada.")
    finally:
        j["_senha"] = None
        j["tudo"] = False


@app.post("/relatorio")
def relatorio():
    j, erro = _novo_job(request.form)
    if erro:
        return jsonify(erro=erro), 400
    _iniciar(j, "rel", "Iniciando")
    threading.Thread(target=_executar, args=(j["id"], "rel", _etapa_relatorio, request.form.get("senha", "")),
                     daemon=True).start()
    return jsonify(id=j["id"])


@app.post("/executar_tudo")
def executar_tudo():
    j, erro = _novo_job(request.form)
    if erro:
        return jsonify(erro=erro), 400
    safx, erro = _salvar_safx(j, request.files.getlist("safx"))
    if erro:
        JOBS.pop(j["id"], None)
        return jsonify(erro=erro), 400
    threading.Thread(target=_rodar_tudo, args=(j["id"], request.form.get("senha", ""), safx,
                                               request.form.get("criar") == "1"),
                     daemon=True).start()
    return jsonify(id=j["id"])


@app.post("/job/<jid>/analise")
def analise(jid):
    j = _job(jid)
    if _ocupado(j) or not _habilitadas(j)["safx"]:
        return jsonify(erro="Aguarde o relatório de conferência ficar pronto."), 400
    arquivos, erro = _salvar_safx(j, request.files.getlist("safx"))
    if erro:
        return jsonify(erro=erro), 400
    if not arquivos:
        return jsonify(erro="Anexe pelo menos uma SAFX ou clique em Pular."), 400
    _iniciar(j, "safx", "Analisando")
    threading.Thread(target=_executar, args=(jid, "safx", _etapa_safx, arquivos),
                     daemon=True).start()
    return jsonify(ok=True)


@app.post("/job/<jid>/pular")
def pular(jid):
    j = _job(jid)
    if _ocupado(j) or not _habilitadas(j)["safx"]:
        return jsonify(erro="Aguarde o relatório de conferência ficar pronto."), 400
    e = _iniciar(j, "safx", "Etapa pulada")
    e.update(fim=True, pulada=True)
    _log(j, "Análise SAFX pulada pelo usuário.")
    return jsonify(ok=True)


@app.post("/job/<jid>/apuracao")
def apuracao(jid):
    j = _job(jid)
    if _ocupado(j) or not _habilitadas(j)["apur"]:
        return jsonify(erro="Conclua (ou pule) a etapa 2 primeiro."), 400
    if not j["_senha"]:
        return jsonify(erro="A senha não está mais na memória. Gere o relatório (etapa 1) novamente."), 400
    _iniciar(j, "apur", "Iniciando")
    threading.Thread(target=_executar, args=(jid, "apur", _etapa_apuracao), daemon=True).start()
    return jsonify(ok=True)


@app.post("/job/<jid>/conciliacao")
def conciliacao(jid):
    j = _job(jid)
    if _ocupado(j) or not _habilitadas(j)["conc"]:
        return jsonify(erro="Conclua a etapa 3 primeiro."), 400
    if not j["_senha"]:
        return jsonify(erro="A senha não está mais na memória. Gere o relatório (etapa 1) novamente."), 400
    _iniciar(j, "conc", "Iniciando")
    threading.Thread(target=_executar, args=(jid, "conc", _etapa_conc, request.form.get("criar") == "1"),
                     daemon=True).start()
    return jsonify(ok=True)


@app.post("/job/<jid>/final")
def final(jid):
    j = _job(jid)
    if _ocupado(j) or j["tudo"] or not _habilitadas(j)["final"]:
        return jsonify(erro="Conclua pelo menos a etapa 3."), 400
    j["final"] = _nova_etapa()
    j["final"]["status"] = "Gerando relatório final e plano de teste"
    threading.Thread(target=_gerar_final, args=(j,), daemon=True).start()
    return jsonify(ok=True)


@app.get("/job/<jid>/status")
def status(jid):
    j = _job(jid)
    hab = _habilitadas(j)
    etapas = {}
    for k in ETAPAS:
        e = j[k]
        etapas[k] = {"status": e["status"], "fim": e["fim"], "ok": e["ok"], "pulada": e["pulada"], "habilitada": hab[k],
                     "resumo": e["resumo"],
                     "arquivos": [{"rotulo": r, "url": _url(jid, j, c), "cls": cls} for r, c, cls in e["arquivos"]]}
    return jsonify(log=j["log"], etapas=etapas, tudo=j["tudo"])


@app.get("/job/<jid>/arquivo/<path:rel>")
def arquivo(jid, rel):
    j = _job(jid)
    return send_from_directory(j["pasta"], rel, as_attachment=True)


if __name__ == "__main__":
    import sys
    os.makedirs(EXECUCOES, exist_ok=True)
    if not os.environ.get("TAXONE_CONF_SEM_NAVEGADOR") and "--sem-navegador" not in sys.argv:
        threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{PORTA}")).start()
    app.run(host=os.environ.get("TAXONE_CONF_HOST", "127.0.0.1"), port=PORTA, threaded=True)
