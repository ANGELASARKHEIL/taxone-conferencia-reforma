@echo off
cd /d "%~dp0"
title Conferencia SAFX x TAX ONE
netstat -ano | findstr /R /C:":5055 .*LISTENING" >nul
if not errorlevel 1 (
  start "" http://127.0.0.1:5055
  exit /b
)
echo Abrindo o site em http://127.0.0.1:5055  (feche esta janela para encerrar)
call "%~dp0achar_python.bat"
if not defined PY (
  echo Python nao encontrado. Rode o instalar.bat primeiro.
  pause
  exit /b 1
)
"%PY%" app.py
pause
