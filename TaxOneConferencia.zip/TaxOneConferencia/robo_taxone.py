import hashlib
import io
import json
import os
import re
import shutil
import threading
import time
import zipfile
from urllib.parse import urlsplit

from PIL import Image, ImageDraw, ImageFont
from playwright.sync_api import sync_playwright

AMBIENTES = {"QA": "https://uat.onesourcetax.com"}
NOMES_AMBIENTE = {"QA": "UAT (uat.onesourcetax.com)"}
RELATORIO = "Documentos Fiscais e Utilities - Reforma Tributária"
_cfg = threading.local()


def definir_ambiente(ambiente):
    if ambiente not in AMBIENTES:
        raise ValueError(f"Ambiente inválido: {ambiente}")
    _cfg.base = AMBIENTES[ambiente]


def base_url():
    return getattr(_cfg, "base", AMBIENTES["QA"])


class ErroRobo(Exception):
    pass


class NavegadorFechou(ErroRobo):
    pass


class PrecisaJanela(ErroRobo):
    pass


def _log(cb, msg):
    if cb:
        cb(msg)
    else:
        print(msg, flush=True)


VALIDADE_ACESSO_H = 12


def _arquivo_preferencias():
    return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TaxOneConferencia", "preferencias.json")


def _preferencia_navegador():
    try:
        with open(_arquivo_preferencias(), encoding="utf-8") as f:
            valor = str(json.load(f).get("navegador") or "").lower()
    except Exception:
        return ""
    return valor if valor in ("edge", "chrome") else ""


def salvar_preferencia_navegador(valor):
    if valor not in ("edge", "chrome"):
        return
    try:
        arq = _arquivo_preferencias()
        os.makedirs(os.path.dirname(arq), exist_ok=True)
        with open(arq, "w", encoding="utf-8") as f:
            json.dump({"navegador": valor}, f)
    except Exception:
        pass


def navegador_efetivo(acesso):
    escolha = str((acesso or {}).get("navegador") or "").strip().lower()
    return escolha if escolha in ("edge", "chrome") else (_preferencia_navegador() or "edge")


def chrome_instalado():
    if os.name != "nt":
        return False
    bases = (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"), os.environ.get("LOCALAPPDATA"))
    return any(os.path.exists(os.path.join(b, "Google", "Chrome", "Application", "chrome.exe")) for b in bases if b)


def outro_navegador(acesso):
    a = acesso or {}
    if a.get("modo") != "ciam" or os.name != "nt" or str(a.get("navegador") or "").strip() or a.get("troca"):
        return None
    outro = "chrome" if navegador_efetivo(a) == "edge" else "edge"
    return outro if (outro == "edge" or chrome_instalado()) else None


def definir_acesso(acesso, email=""):
    a = acesso or {}
    modo = a.get("modo") or "classico"
    if modo not in ("classico", "ciam"):
        raise ValueError(f"Tipo de login inválido: {modo}")
    _cfg.acesso = {"modo": modo, "cliente": (a.get("cliente") or "").strip(), "lembrar": bool(a.get("lembrar")),
                   "email": (email or "").strip().lower(), "navegador": navegador_efetivo(a), "troca": bool(a.get("troca"))}
    _cfg.canal_usado = ""
    _cfg.login_ok = False
    _cfg.acesso_carregado = False
    _cfg.janela = bool(a.get("janela")) or not _acesso_recente()


def modo_ciam():
    return getattr(_cfg, "acesso", {}).get("modo") == "ciam"


def _navegador_visivel():
    return tela_real() or (modo_ciam() and os.name == "nt" and getattr(_cfg, "janela", True))


def _usa_acesso_salvo():
    a = getattr(_cfg, "acesso", {})
    return bool(a.get("modo") == "ciam" and a.get("lembrar") and a.get("email") and os.name == "nt")


def _acesso_recente():
    if not _usa_acesso_salvo():
        return False
    try:
        return time.time() - os.path.getmtime(_arquivo_acesso()) <= VALIDADE_ACESSO_H * 3600
    except OSError:
        return False


def _pasta_acessos():
    return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "TaxOneConferencia", "acessos")


def _arquivo_acesso():
    chave = f"{base_url()}|{_cfg.acesso['email']}"
    return os.path.join(_pasta_acessos(), hashlib.sha256(chave.encode("utf-8")).hexdigest()[:24] + ".bin")


def _dpapi(dados, proteger):
    import win32crypt
    if proteger:
        return win32crypt.CryptProtectData(dados, "TaxOneConferencia", None, None, None, 0)
    return win32crypt.CryptUnprotectData(dados, None, None, None, 0)[1]


def _acesso_salvo():
    if not _usa_acesso_salvo():
        return None
    arq = _arquivo_acesso()
    try:
        if time.time() - os.path.getmtime(arq) > VALIDADE_ACESSO_H * 3600:
            os.remove(arq)
            return None
        with open(arq, "rb") as f:
            estado = json.loads(_dpapi(f.read(), False).decode("utf-8"))
        _cfg.acesso_carregado = True
        return estado
    except Exception:
        return None


def _salvar_acesso(ctx):
    if not _usa_acesso_salvo():
        return
    try:
        arq = _arquivo_acesso()
        os.makedirs(os.path.dirname(arq), exist_ok=True)
        with open(arq, "wb") as f:
            f.write(_dpapi(json.dumps(ctx.storage_state()).encode("utf-8"), True))
    except Exception:
        pass


def esquecer_acessos():
    pasta = _pasta_acessos()
    qtd = len(os.listdir(pasta)) if os.path.isdir(pasta) else 0
    shutil.rmtree(pasta, ignore_errors=True)
    return qtd


def _limpar_cookies(pg):
    if modo_ciam():
        pg.context.clear_cookies(domain=re.compile(r"onesourcetax\.com$"))
    else:
        pg.context.clear_cookies()


def _login(pg, usuario, senha, log):
    _cfg.cred = (usuario, senha)
    if modo_ciam():
        import login_ciam
        return login_ciam.entrar(pg, usuario, senha, log)
    _log(log, "Abrindo login do ONESOURCE...")
    for tentativa in range(3):
        try:
            pg.goto(base_url() + "/auth/signin", wait_until="domcontentloaded", timeout=90000)
            pg.wait_for_selector("input[name=username]", timeout=60000)
            break
        except Exception:
            if tentativa == 2:
                raise ErroRobo("A página de login do ONESOURCE não abriu (verifique a conexão/VPN/ZScaler).")
            _log(log, f"Login do ONESOURCE não carregou (tentativa {tentativa + 1}/3), tentando de novo...")
    passo(pg, f"Tela de login do ONESOURCE ({urlsplit(base_url()).netloc})")
    pg.fill("input[name=username]", usuario)
    pg.fill("input[name=password]", senha)
    passo(pg, "Usuário e senha informados (senha mascarada)")
    pg.keyboard.press("Enter")
    t0 = time.time()
    while time.time() - t0 < 90:
        if "/platform/" in pg.url:
            pg.wait_for_timeout(4000)
            passo(pg, "Login realizado – portal ONESOURCE")
            return pg
        err = pg.locator("text=/inválid|incorrect|invalid|incorret/i").first
        if err.count() and err.is_visible():
            raise ErroRobo("Usuário ou senha inválidos no ONESOURCE.")
        falha = pg.locator("text=/error has occurred|ocorreu um erro/i").first
        if falha.count() and falha.is_visible():
            raise ErroRobo("O ONESOURCE respondeu \"An error has occurred\" no login. É instabilidade da plataforma "
                           "(veja o aviso na tela de login). Tente novamente em alguns minutos.")
        pg.wait_for_timeout(1000)
    raise ErroRobo("O login não foi concluído (verifique usuário/senha ou MFA).")


def _abrir_taxone(pg, log):
    _log(log, "Abrindo o TAX ONE...")
    for tentativa in range(5):
        alvo = pg
        try:
            tile = pg.get_by_text("TAX ONE\u200e", exact=True).locator("visible=true").first
            tile.wait_for(timeout=45000)
            try:
                with pg.context.expect_page(timeout=15000) as nova:
                    tile.click()
                alvo = nova.value
                alvo.on("dialog", lambda d: d.accept())
                _log(log, "TAX ONE abriu em nova aba.")
            except Exception:
                alvo = pg
            fr = None
            t0 = time.time()
            while time.time() - t0 < 120 and fr is None:
                if alvo.locator("#iframe-app-container").count():
                    fr = alvo.frame_locator("#iframe-app-container")
                elif alvo.locator("div.bento-combobox input.form-control, #m_funcoes5").count():
                    fr = alvo
                else:
                    alvo.wait_for_timeout(2000)
            if fr is None:
                raise ErroRobo("TAX ONE não carregou")
            fr.locator("div.bento-combobox input.form-control, #m_funcoes5").first.wait_for(timeout=90000)
            alvo.wait_for_timeout(2000)
            _fechar_avisos(alvo)
            passo(alvo, "Tax One aberto – tela de seleção de empresa, estabelecimento, agrupamento e módulo")
            return alvo, fr
        except Exception:
            if alvo is not pg:
                try:
                    alvo.close()
                except Exception:
                    pass
            _log(log, f"Portal ONESOURCE/TAX ONE ainda carregando (tentativa {tentativa + 1}/5)...")
            try:
                if tentativa == 0:
                    pg.reload(wait_until="domcontentloaded", timeout=90000)
                elif tentativa == 1:
                    pg.goto(base_url() + "/platform/home", wait_until="domcontentloaded", timeout=90000)
                elif getattr(_cfg, "cred", None):
                    _log(log, "Refazendo o login no ONESOURCE...")
                    _limpar_cookies(pg)
                    pg = _login(pg, *_cfg.cred, log)
            except Exception:
                pass
    raise ErroRobo("O TAX ONE não abriu a partir do portal ONESOURCE (portal travado no carregamento). Tente novamente.")


def _fechar_avisos(pg):
    js = """() => {
        const re = /(password|senha|palavra-passe)[^.]{0,40}expir/i;
        const txt = e => (e.innerText || '');
        const cands = [...document.querySelectorAll('body *')].filter(e => txt(e).length < 300 && re.test(txt(e)));
        const folhas = cands.filter(e => ![...e.children].some(c => re.test(txt(c))));
        folhas.forEach(e => {
            let alvo = e, niveis = 0;
            const seguro = el => el && el !== document.body && !el.querySelector('iframe') && txt(el).length < 400;
            while (niveis < 4 && seguro(alvo.parentElement)) { alvo = alvo.parentElement; niveis++; }
            if (alvo.isConnected && seguro(alvo)) alvo.remove();
        });
    }"""
    pendo = """() => {
        document.querySelectorAll('button._pendo-close-guide, [id^=pendo-close-guide], ._pendo-close-guide').forEach(b => { try { b.click(); } catch (e) {} });
        document.querySelectorAll('#pendo-guide-container, ._pendo-guide-container, ._pendo-backdrop, #pendo-backdrop, [id^=pendo-base], ._pendo-step-container')
            .forEach(e => { const r = e.closest('[id^=pendo-base]') || e; r.remove(); });
    }"""
    for alvo in [pg] + [f for f in pg.frames if f != pg.main_frame]:
        for codigo in (js, pendo):
            try:
                alvo.evaluate(codigo)
            except Exception:
                pass


def _clicar(pg, loc, timeout=10000):
    _fechar_avisos(pg)
    try:
        loc.click(timeout=timeout)
    except Exception:
        loc.dispatch_event("click")


def reabrir_taxone(pg, log):
    """O TAX ONE às vezes abre com a lista de empresas vazia (erro do servidor): refaz o login e reabre."""
    _log(log, "TAX ONE não carregou a lista de empresas; refazendo o login e reabrindo...")
    _limpar_cookies(pg)
    pg.wait_for_timeout(5000)
    pg = _login(pg, *_cfg.cred, log)
    return _abrir_taxone(pg, log)


def encerrar(b):
    """Faz logout do ONESOURCE antes de fechar o navegador, para não deixar sessões abertas. Com o acesso Thomson Reuters
    salvo, mantém a sessão e grava os cookies atualizados para as próximas etapas."""
    try:
        for ctx in b.contexts:
            if _usa_acesso_salvo():
                if getattr(_cfg, "login_ok", False):
                    _salvar_acesso(ctx)
            elif ctx.pages:
                ctx.pages[0].goto(base_url() + "/auth/signin?Logout=2", wait_until="domcontentloaded", timeout=20000)
                ctx.pages[0].wait_for_timeout(2000)
    except Exception:
        pass
    b.close()


def sem_janela(p, b, ctx, log, largura, altura, preparar=None):
    """Depois do login Thomson Reuters (feito numa janela visível), segue em segundo plano com a mesma sessão,
    como no login clássico. Devolve (navegador, contexto, página) ou None se continuar na janela."""
    if not (modo_ciam() and os.name == "nt" and getattr(_cfg, "janela", False) and not tela_real()):
        return None
    _log(log, "Login concluído. A janela do robô vai fechar de propósito; o robô segue em segundo plano.")
    novo = None
    try:
        estado = ctx.storage_state()
        _cfg.janela = False
        novo = abrir_navegador(p, True)
        ctx2 = novo.new_context(viewport={"width": largura, "height": altura}, accept_downloads=True, storage_state=estado)
        if preparar:
            preparar(ctx2)
        pg2 = ctx2.new_page()
        pg2.on("dialog", lambda d: d.accept())
        pg2.goto(base_url() + "/platform/home", wait_until="domcontentloaded", timeout=90000)
        if "/platform/" not in pg2.url:
            raise ErroRobo("sessão não aceita em segundo plano")
    except Exception:
        _cfg.janela = True
        if novo:
            try:
                novo.close()
            except Exception:
                pass
        _log(log, "Não consegui seguir em segundo plano; o robô continua na janela (não minimize nem feche).")
        return None
    try:
        b.close()
    except Exception:
        pass
    return novo, ctx2, pg2


RX_CHAVE_ERRO = re.compile(r"intercepts pointer events|not visible|not enabled|not stable|outside of the viewport|detached|waiting for element to be|is not attached", re.I)
RX_CAUSA_FORTE = re.compile(r"intercepts pointer events|not visible|not enabled|not stable|outside of the viewport|detached|is not attached", re.I)
JS_FALHA = r"""
() => {
  const desc = e => e ? e.tagName.toLowerCase() + (e.id ? '#' + e.id : '')
    + (typeof e.className === 'string' && e.className.trim() ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '') : null;
  const selects = [...document.querySelectorAll('saf-select')].slice(0, 6).map(s => {
    const r = s.getBoundingClientRect();
    const alvo = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    const ops = [...s.querySelectorAll('saf-option')];
    return {rotulo: s.getAttribute('label') || '', desabilitado: s.hasAttribute('disabled') || s.getAttribute('aria-disabled') === 'true',
            aberto: s.getAttribute('aria-expanded') === 'true' || s.hasAttribute('open') || s.hasAttribute('opened'),
            retangulo: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
            opcoes: ops.length, opcoes_visiveis: ops.filter(o => { const q = o.getBoundingClientRect(); return q.width > 0 && q.height > 0; }).length,
            no_ponto_central: desc(alvo), ponto_central_e_o_proprio_select: !!alvo && (alvo === s || s.contains(alvo))};
  });
  const coberturas = [...document.querySelectorAll('body *')].filter(e => {
    const s = getComputedStyle(e);
    if (s.position !== 'fixed' && s.position !== 'absolute') return false;
    const r = e.getBoundingClientRect();
    return r.width > innerWidth * 0.5 && r.height > innerHeight * 0.4 && parseInt(s.zIndex || '0') > 100
      && s.visibility !== 'hidden' && s.display !== 'none';
  }).slice(0, 5).map(desc);
  return {visibilidade: document.visibilityState, com_foco: document.hasFocus(), janela: [innerWidth, innerHeight],
          selects, coberturas};
}
"""


def resumo_erro(ex, limite=300):
    """Primeira linha do erro do Playwright mais a linha do 'Call log' que diz por que a ação não andou."""
    linhas = [l.strip() for l in str(ex).splitlines() if l.strip()]
    if not linhas:
        return type(ex).__name__
    texto = linhas[0]
    chave = (next((l for l in reversed(linhas[1:]) if RX_CAUSA_FORTE.search(l)), "")
             or next((l for l in reversed(linhas[1:]) if RX_CHAVE_ERRO.search(l)), ""))
    if chave:
        texto += " (" + chave.lstrip("- ").strip()[:120] + ")"
    return texto[:limite]


def registrar_falha(alvo, pasta, log=None):
    """Guarda print e resumo da tela (visibilidade, foco, tamanho, selects e coberturas) quando uma etapa falha."""
    try:
        if hasattr(alvo, "pages"):
            pagina = next((q for q in reversed(alvo.pages) if not q.is_closed()), None)
        elif alvo is not None and alvo.is_closed():
            pagina = next((q for q in reversed(alvo.context.pages) if not q.is_closed()), None)
        else:
            pagina = alvo
        if pagina is None:
            return
        os.makedirs(pasta, exist_ok=True)
        png = os.path.join(pasta, "erro_tela.png")
        try:
            pagina.screenshot(path=png, timeout=10000)
            tela = True
        except Exception:
            tela = False
        if tela:
            try:
                info = pagina.evaluate(JS_FALHA)
            except Exception as ex:
                info = {"resumo": "indisponível: " + resumo_erro(ex, 120)}
        else:
            info = {"resumo": "a tela não respondeu ao pedido de print em 10 s"}
        partes = urlsplit(pagina.url)
        info["endereco"] = f"{partes.netloc}{partes.path}"
        with open(os.path.join(pasta, "erro_tela.json"), "w", encoding="utf-8") as f:
            json.dump(info, f, ensure_ascii=False, indent=1)
        _log(log, f"Print e resumo da tela no momento da falha salvos em {png} (e erro_tela.json)." if tela
             else f"Resumo da tela no momento da falha salvo em {os.path.join(pasta, 'erro_tela.json')} (o print não saiu).")
    except Exception:
        pass


def _frame(pg):
    el = pg.query_selector("#iframe-app-container")
    f = el.content_frame() if el else None
    return f or pg.main_frame


def definir_evidencias(pasta):
    _cfg.evid = pasta


FIG_DESC = {
    "fig01": "Seleção de empresa, estabelecimento, agrupamento Básicos e módulo Data Warehouse",
    "fig02": "Menu Relatórios > Conferências > Documentos Fiscais e Utilities - Reforma Tributária",
    "fig03": "Parâmetros do relatório preenchidos",
    "fig04": "Aba Processos com o processo encerrado",
    "fig05": "Aba Log do processo",
    "fig06": "Aba Arquivos com os arquivos gerados selecionados",
    "fig07": "Transferência de arquivos com os relatórios disponíveis",
    "fig08": "Seleção do agrupamento Reforma Tributária do Consumo e módulo Apuração Fiscal CBS-IBS-IS",
    "fig09": "Dashboard da Apuração do período",
    "fig10": "Detalhes da Apuração (débitos e créditos)",
    "fig11": "Detalhamento dos débitos da Apuração",
    "fig12": "Detalhamento dos créditos da Apuração",
    "fig13": "Seleção do módulo Conciliação Fiscal-Contábil",
    "fig14": "Tela inicial da Conciliação com empresa, filial e competência",
    "fig15": "Assistente de conciliação – escolha do tipo Contribuinte x Fisco",
    "fig16": "Assistente de conciliação – pergunta do período",
    "fig17": "Assistente de conciliação – resumo para confirmação",
    "fig18": "Assistente de conciliação – sessão criada com sucesso",
    "fig19": "Conciliação – acesso aos documentos sem inconsistências",
    "fig20": "Documentos sem inconsistências",
    "fig21": "Indicadores de inconsistências da conciliação",
    "fig22": "Inconsistências de documentos",
    "fig23": "Inconsistências nos débitos",
    "fig24": "Detalhes da conciliação",
    "fig25": "Histórico das sessões de conciliação",
    "fig27": "Seleção do módulo Contabilização",
    "fig28": "Tela inicial da Contabilização com empresa, estabelecimento e competência",
    "fig29": "Configurações contábeis cadastradas",
    "fig30": "Visualização de uma configuração contábil",
    "fig31": "Exportação das configurações contábeis",
    "fig32": "Contabilização – visão sintética (saldo da apuração por configuração)",
    "fig33": "Contabilização – visão analítica (lançamentos contábeis)",
    "fig34": "Exportação dos lançamentos contábeis",
}
_trava = threading.Lock()


def definir_tela_real(ativo):
    """Prints da tela inteira do computador (com o relógio do Windows); exige o navegador visível."""
    _cfg.tela_real = bool(ativo) and os.name == "nt"
    if _cfg.tela_real:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass


def tela_real():
    return getattr(_cfg, "tela_real", False)


def contexto(b, largura=1600, altura=900):
    kw = {"accept_downloads": True}
    estado = _acesso_salvo()
    if estado:
        kw["storage_state"] = estado
    if _navegador_visivel():
        return b.new_context(no_viewport=True, **kw)
    return b.new_context(viewport={"width": largura, "height": altura}, **kw)


def abrir_navegador(p, headless=True):
    """Edge instalado no Windows; Chromium do Playwright em Linux (ex.: GitHub Codespaces)."""
    args = ["--disable-features=Translate,TranslateUI,msEdgeTranslate,msTranslate", "--lang=pt-BR"]
    if _navegador_visivel():
        headless = False
        args.append("--start-maximized")
    if os.name == "nt":
        canais = ["msedge"]
        if modo_ciam():
            canais = ["chrome", "msedge"] if _cfg.acesso.get("navegador") == "chrome" else ["msedge", "chrome"]
        for canal in canais:
            try:
                b = p.chromium.launch(channel=canal, headless=headless, args=args)
            except Exception:
                continue
            _cfg.canal_usado = "Chrome" if canal == "chrome" else "Edge"
            return b
    _cfg.canal_usado = "Chromium"
    return p.chromium.launch(headless=headless, args=args)


def _janela(pg):
    import win32gui
    titulo = (pg.title() or "").strip()[:40]
    achadas = []

    def cb(h, _):
        if win32gui.IsWindowVisible(h) and win32gui.GetClassName(h) == "Chrome_WidgetWin_1":
            t = win32gui.GetWindowText(h)
            if t and (not titulo or t.startswith(titulo)):
                achadas.append(h)
    win32gui.EnumWindows(cb, None)
    return achadas[0] if achadas else None


def _captura_tela(pg):
    """Traz a janela do robô para frente e captura o monitor dela (com barra de tarefas e relógio).
    Devolve (imagem, função que converte coordenadas da página para a imagem)."""
    import win32api
    import win32con
    import win32gui
    from PIL import ImageGrab
    pg.bring_to_front()
    h = _janela(pg)
    if h:
        if win32gui.GetForegroundWindow() != h:
            win32gui.ShowWindow(h, win32con.SW_MINIMIZE)
            win32gui.ShowWindow(h, win32con.SW_MAXIMIZE)
            try:
                win32gui.SetForegroundWindow(h)
            except Exception:
                pass
        else:
            win32gui.ShowWindow(h, win32con.SW_MAXIMIZE)
    pg.wait_for_timeout(700)
    iw, ih, dpr = pg.evaluate("() => [window.innerWidth, window.innerHeight, window.devicePixelRatio]")
    try:
        pg.mouse.move(iw - 3, ih - 3)
        pg.wait_for_timeout(300)
    except Exception:
        pass
    if h:
        mon = win32api.GetMonitorInfo(win32api.MonitorFromWindow(h, 2))["Monitor"]
        cx, cy = win32gui.ClientToScreen(h, (0, 0))
        _, _, cw, ch = win32gui.GetClientRect(h)
    else:
        mon = (0, 0, win32api.GetSystemMetrics(0), win32api.GetSystemMetrics(1))
        cx, cy, cw, ch = 0, 0, mon[2], mon[3]
    img = ImageGrab.grab(bbox=tuple(mon), all_screens=True).convert("RGB")
    ox = cx + (cw - iw * dpr) / 2 - mon[0]
    oy = cy + ch - ih * dpr - mon[1]
    return img, (lambda c: (ox + c[0] * dpr, oy + c[1] * dpr, ox + c[2] * dpr, oy + c[3] * dpr))


def _destacar(img, destaques, elipses):
    d = ImageDraw.Draw(img)
    for (x1, y1, x2, y2) in destaques:
        d.rectangle((x1 - 4, y1 - 4, x2 + 4, y2 + 4), outline=(220, 30, 30), width=3)
    for (x1, y1, x2, y2) in elipses:
        d.ellipse((x1 - 14, y1 - 10, x2 + 14, y2 + 10), outline=(220, 30, 30), width=3)
    return img


def _fonte(tam, negrito=False):
    nomes = ("segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf") if negrito else ("segoeui.ttf", "arial.ttf", "DejaVuSans.ttf")
    for nome in nomes:
        try:
            return ImageFont.truetype(nome, tam)
        except OSError:
            continue
    return ImageFont.load_default()


def _carimbar(png, linha1, linha2):
    img = Image.open(io.BytesIO(png)).convert("RGB")
    faixa = 52
    nova = Image.new("RGB", (img.width, img.height + faixa), (32, 32, 32))
    nova.paste(img, (0, 0))
    d = ImageDraw.Draw(nova)
    d.rectangle((0, img.height, img.width, img.height + 3), fill=(250, 100, 0))
    d.text((14, img.height + 8), linha1, font=_fonte(17, True), fill=(255, 255, 255))
    d.text((14, img.height + 30), linha2, font=_fonte(14), fill=(200, 200, 200))
    return nova


def _caixa(pg, loc, rolagem):
    try:
        if loc is None or not loc.count():
            return None
        b = loc.first.bounding_box(timeout=3000)
        if not b:
            return None
        return (b["x"] + rolagem[0], b["y"] + rolagem[1], b["x"] + b["width"] + rolagem[0], b["y"] + b["height"] + rolagem[1])
    except Exception:
        return None


def _figura(png, destaques, elipses, recorte):
    img = _destacar(Image.open(io.BytesIO(png)).convert("RGB"), destaques, elipses)
    if recorte:
        x1, y1 = max(0, int(recorte[0])), max(0, int(recorte[1]))
        x2, y2 = min(img.width, int(recorte[2])), min(img.height, int(recorte[3]))
        if x2 - x1 > 50 and y2 - y1 > 50:
            img = img.crop((x1, y1, x2, y2))
    return img


def passo(pg, descricao, fig=None, evid=None, full=False, destaques=None, elipses=None, recorte=None, faixa=None):
    """Print com carimbo de data/hora (registro dos passos). Com fig, salva também a figura do plano: sem carimbo,
    recortada em `recorte` (locator) ou na faixa de `faixa` (locator da área) até o último destaque, com
    retângulos vermelhos em `destaques` e elipses em `elipses`."""
    evid = evid or getattr(_cfg, "evid", None)
    if not evid:
        return
    try:
        real = bool(fig) and tela_real()
        if real:
            full = False
            if destaques:
                try:
                    destaques[-1].first.scroll_into_view_if_needed(timeout=3000)
                except Exception:
                    pass
        rolagem = pg.evaluate("() => [window.scrollX, window.scrollY]") if full else (0, 0)
        caixas = [c for c in (_caixa(pg, l, rolagem) for l in (destaques or [])) if c]
        circulos = [c for c in (_caixa(pg, l, rolagem) for l in (elipses or [])) if c]
        corte = _caixa(pg, recorte, rolagem) if recorte is not None else None
        if faixa is not None:
            area = _caixa(pg, faixa, rolagem)
            if area and caixas:
                corte = (area[0], area[1], area[2], min(area[3], max(c[3] for c in caixas) + 60))
        tela = None
        if real:
            try:
                tela, converter = _captura_tela(pg)
                tela = _destacar(tela, [converter(c) for c in caixas], [converter(c) for c in circulos])
            except Exception:
                tela = None
        try:
            png = pg.screenshot(full_page=full, timeout=20000)
        except Exception:
            if tela is None:
                raise
            buf = io.BytesIO()
            tela.save(buf, format="PNG")
            png = buf.getvalue()
        agora = time.strftime("%d/%m/%Y %H:%M:%S")
        partes = urlsplit(pg.url)
        endereco = f"{partes.netloc}{partes.path}"
        pasta = os.path.join(evid, "passos")
        with _trava:
            os.makedirs(pasta, exist_ok=True)
            n = len([x for x in os.listdir(pasta) if x.endswith(".jpg")]) + 1
            img = _carimbar(png, f"{agora}   |   Passo {n}: {descricao}",
                            f"{endereco}   |   horário local (UTC{time.strftime('%z')})")
            reduzida = img.resize((1300, int(img.height * 1300 / img.width))) if img.width > 1300 else img
            reduzida.save(os.path.join(pasta, f"{n:03d}.jpg"), quality=72)
            with open(os.path.join(evid, "passos.jsonl"), "a", encoding="utf-8") as f:
                f.write(json.dumps({"n": n, "descricao": descricao, "hora": agora, "endereco": endereco,
                                    "arquivo": f"passos/{n:03d}.jpg", "figura": fig}, ensure_ascii=False) + "\n")
            if fig:
                (tela if tela is not None else _figura(png, caixas, circulos, corte)).save(os.path.join(evid, fig + ".png"))
    except Exception:
        pass


def area_taxone(pg):
    loc = pg.locator("#iframe-app-container")
    return loc if loc.count() else None


def shot(pg, evid, nome, full=False, **kw):
    base, _, imp = nome.partition("_")
    desc = FIG_DESC.get(nome) or (f"{FIG_DESC[base]} – aba {imp}" if imp and base in FIG_DESC else nome)
    passo(pg, desc, fig=nome, evid=evid, full=full, **kw)


def info_ambiente(pg):
    info = {"cliente": "", "ambiente": "", "ambiente_completo": "", "usuario_nome": "", "empresa_nome": ""}
    try:
        linhas = [l.strip() for l in pg.inner_text("body", timeout=10000).splitlines() if l.strip()][:80]
    except Exception:
        return info
    for i, l in enumerate(linhas):
        m = re.match(r"^TAX ONE\s+(.+?)\s*\((\w+)\)$", l)
        if m:
            nome = m.group(1).strip()
            amb = re.search(r"\s+(UAT|PRD|PROD|PRODUÇÃO|HML|HOMOLOG\w*|QA|DEV|TST|TESTE)$", nome, re.I)
            info["cliente"] = nome[:amb.start()].strip() if amb else nome
            info["ambiente"] = f"{amb.group(1) if amb else ''} ({m.group(2)})".strip()
            info["ambiente_completo"] = l
            info["usuario_nome"] = linhas[i - 1] if i else ""
            break
    return info

def _escolher(pg, fr, idx, texto, rotulo):
    itens = fr.locator(".bento-combobox-container:visible li")
    if " - " in texto or idx >= 2:
        alvo = itens.filter(has_text=texto)
    else:
        alvo = itens.filter(has_text=re.compile(rf"^\s*{re.escape(texto.strip())}\s*(-|$)", re.I))
    disp = []
    for tentativa in range(12):
        _fechar_avisos(pg)
        campo = fr.locator("div.bento-combobox input.form-control").nth(idx)
        try:
            campo.click(timeout=8000)
        except Exception:
            try:
                campo.click(timeout=8000, force=True)
            except Exception:
                pg.wait_for_timeout(3000)
                continue
        pg.wait_for_timeout(1500 + tentativa * 1000)
        if alvo.count():
            alvo.first.click()
            pg.wait_for_timeout(2500)
            return
        disp = [t.strip() for t in itens.all_inner_texts() if t.strip()]
        pg.keyboard.press("Escape")
        if disp:
            break
        pg.wait_for_timeout(3000)
    raise ErroRobo(f"{rotulo} '{texto}' não encontrado. Disponíveis: {', '.join(disp[:40]) or '(lista vazia — TAX ONE não carregou)'}")


def _selecionar_contexto(pg, fr, empresa, estabelecimento, log, evid=None):
    combos = fr.locator("div.bento-combobox input.form-control")
    if not combos.first.is_visible():
        _log(log, "Fechando módulo aberto anteriormente...")
        fr.locator("i.bento-icon-close-thick").first.click()
        combos.first.wait_for(timeout=60000)
        pg.wait_for_timeout(2000)
    _log(log, f"Selecionando empresa {empresa}...")
    _escolher(pg, fr, 0, empresa, "Empresa")
    try:
        nome_empresa = fr.locator("div.bento-combobox input.form-control").nth(0).input_value(timeout=3000).strip()
    except Exception:
        nome_empresa = ""
    passo(pg, f"Empresa selecionada: {nome_empresa or empresa}")
    _log(log, f"Selecionando estabelecimento {estabelecimento}...")
    _escolher(pg, fr, 1, estabelecimento, "Estabelecimento")
    passo(pg, f"Estabelecimento selecionado: {estabelecimento}")
    _log(log, "Selecionando agrupamento Básicos e módulo Data Warehouse...")
    _escolher(pg, fr, 2, "sicos", "Agrupamento")
    passo(pg, "Agrupamento selecionado: Básicos")
    if evid:
        fr.locator("div.bento-combobox input.form-control").nth(3).click()
        pg.wait_for_timeout(2000)
        shot(pg, evid, "fig01", destaques=[fr.locator(".bento-combobox-container:visible li", has_text="Data Warehouse")],
             recorte=area_taxone(pg))
        pg.keyboard.press("Escape")
        pg.wait_for_timeout(800)
    _escolher(pg, fr, 3, "Data Warehouse", "Módulo")
    fr.locator("#m_funcoes5").wait_for(timeout=90000)
    pg.wait_for_timeout(2500)
    passo(pg, "Módulo Data Warehouse aberto")
    return nome_empresa


def _abrir_relatorio(pg, fr, log, evid=None):
    _log(log, "Abrindo Relatórios > Conferências > " + RELATORIO + "...")
    fr.locator("#m_funcoes5").click()
    pg.wait_for_timeout(1500)
    passo(pg, "Menu Relatórios aberto")
    fr.get_by_text("Conferências", exact=True).first.click()
    pg.wait_for_timeout(1500)
    shot(pg, evid, "fig02", destaques=[fr.locator("#m_funcoes5"), fr.get_by_text("Conferências", exact=True),
                                       fr.get_by_text(RELATORIO, exact=True)], faixa=area_taxone(pg))
    fr.get_by_text(RELATORIO, exact=True).first.click()
    fr.locator("[id='d_lib_proc_par_header:pb_executar']").wait_for(timeout=90000)
    pg.wait_for_timeout(3000)
    passo(pg, "Tela do Relatório de Conferência – aba Parâmetros")


def _preencher_parametros(pg, fr, periodo, origem, empresas, log):
    _log(log, f"Preenchendo período {periodo} e origem {origem}...")
    per = fr.locator("input[placeholder='  /    ']").first
    per.click()
    per.press("Control+a")
    per.press("Delete")
    per.type(periodo.replace("/", ""), delay=80)
    per.press("Tab")
    pg.wait_for_timeout(800)
    if origem and fr.locator("#col2").inner_text().strip().lower() != origem.strip().lower():
        fr.locator("#col2 div.bento-combobox").click()
        pg.wait_for_timeout(1500)
        itens = fr.locator("#col2 li")
        disp = [t.strip() for t in itens.all_text_contents() if t.strip()]
        alvo = [i for i, t in enumerate(itens.all_text_contents()) if t.strip().lower() == origem.strip().lower()]
        if not alvo:
            raise ErroRobo(f"Origem '{origem}' não encontrada. Disponíveis: {', '.join(disp)}")
        itens.nth(alvo[0]).click(force=True)
        pg.wait_for_timeout(1000)

    _log(log, "Marcando empresas: " + ", ".join(empresas))
    pendentes = {e.split(" ")[0].strip().upper() for e in empresas}
    marcadas = set()
    desc = fr.locator("textarea[id='d_lib_proc_par_multiproc:descricao']")
    chk = fr.locator("input[id='d_lib_proc_par_multiproc:marcado']")
    desc.first.wait_for(timeout=60000)
    cont = desc.first.locator("xpath=ancestor::*[.//select[@ng-model='itemsPerPage']][1]")
    tamanho = cont.locator("select[ng-model='itemsPerPage']").first
    if cont.count() and tamanho.count():
        try:
            opcoes = [o for o in tamanho.locator("option").all_inner_texts() if o.strip().isdigit()]
            if opcoes:
                antes = desc.count()
                tamanho.select_option(label=max(opcoes, key=int), timeout=5000)
                for _ in range(20):
                    pg.wait_for_timeout(1000)
                    if desc.count() != antes:
                        break
        except Exception:
            pass
    vistos = set()
    for _ in range(300):
        _fechar_avisos(pg)
        for i in range(desc.count()):
            cod = desc.nth(i).input_value().split(" - ")[0].strip().upper()
            vistos.add(cod)
            if cod in pendentes and not chk.nth(i).is_checked():
                chk.nth(i).check()
                marcadas.add(cod)
        if marcadas >= pendentes:
            break
        prox = (cont if cont.count() else fr).locator("li.paginate_button.next").first
        if not prox.count() or "disabled" in (prox.get_attribute("class") or ""):
            break
        antes = desc.first.input_value() if desc.count() else ""
        _clicar(pg, prox.locator("a"))
        mudou = False
        for _ in range(30):
            pg.wait_for_timeout(700)
            if desc.count() and desc.first.input_value() != antes:
                mudou = True
                break
        if not mudou:
            break
    faltando = pendentes - marcadas
    if faltando:
        raise ErroRobo("Empresas não encontradas na lista do relatório: " + ", ".join(sorted(faltando)) +
                       f" ({len(vistos)} empresas verificadas na lista)")
    passo(pg, "Empresa marcada na lista do relatório: " + ", ".join(sorted(marcadas)))


def _ids_processos(fr):
    ids = fr.locator("input[id='d_lib_proc_processos:proc_id']")
    out = []
    for i in range(ids.count()):
        v = re.sub(r"\D", "", ids.nth(i).input_value())
        if v:
            out.append(int(v))
    return out


def _aba_processos(pg, fr):
    fr.locator("[id='safdwcm4:w_lib_proc_rel_conf_docs_rttabpage_processos']").click()
    fr.locator("[id='d_lib_proc_processos_header:pb_listar']").wait_for(timeout=60000)
    pg.wait_for_timeout(2500)


def _listar(pg, fr):
    fr.locator("[id='d_lib_proc_processos_header:pb_listar']").click()
    pg.wait_for_timeout(3000)


def _fechar_modal(pg, fr, descricao=None):
    for _ in range(20):
        ok = fr.get_by_role("button", name=re.compile(r"^\s*OK\s*$")).locator("visible=true").first
        if ok.count():
            if descricao:
                passo(pg, descricao)
            msg = ""
            try:
                msg = ok.evaluate("b => (b.closest('.modal-content,.modal,[role=dialog]') || b.parentElement.parentElement.parentElement).innerText").strip()
            except Exception:
                pass
            ok.click()
            pg.wait_for_timeout(1500)
            return msg
        pg.wait_for_timeout(1000)
    return ""


def _baixar_arquivos(pg, fr, idx, proc_id, destino_dir, log, evid=None):
    _log(log, f"Processo {proc_id} encerrado. Preparando arquivos...")
    fr.locator("button[id='d_lib_proc_processos:pb_abrir']").nth(idx).click()
    pg.wait_for_timeout(4000)
    if evid:
        try:
            fr.locator("[id$='rttabpage_log']").first.click(timeout=10000)
            pg.wait_for_timeout(3000)
            shot(pg, evid, "fig05", recorte=area_taxone(pg))
        except Exception:
            pass
    fr.locator("[id='safdwcm4:w_lib_proc_rel_conf_docs_rttabpage_arq']").click()
    fr.locator("input[id='d_lib_proc_lista_arquivos_header_taxbr:todos']").wait_for(timeout=60000)
    pg.wait_for_timeout(2000)
    fr.locator("input[id='d_lib_proc_lista_arquivos_header_taxbr:todos']").check()
    pg.wait_for_timeout(800)
    shot(pg, evid, "fig06", recorte=area_taxone(pg))
    fr.locator("button[id='d_lib_proc_lista_arquivos_header_taxbr:pb_salvar']").click()
    _fechar_modal(pg, fr, "Arquivos salvos – enviados para a Transferência de arquivos")
    pg.wait_for_timeout(10000)

    _log(log, "Abrindo Transferência de arquivos para baixar...")
    f = _frame(pg)
    alvo = f"Download\\{proc_id}_"
    baixados = {}
    f.evaluate("""() => { const a=[...document.querySelectorAll('a.topbar-icon')].find(e=>/Transf/.test(e.getAttribute('aria-label')||'')); a.click(); }""")
    fr.locator("button[ng-click='refreshListNasFiles()']").wait_for(timeout=60000)
    pg.wait_for_timeout(2000)
    for tentativa in range(30):
        if tentativa:
            _clicar(pg, fr.locator("button[ng-click='refreshListNasFiles()']"))
            pg.wait_for_timeout(4000)
        sel = fr.locator("button[ng-click='refreshListNasFiles()']").locator(
            "xpath=ancestor::*[.//select[@ng-model='itemsPerPage']][1]//select[@ng-model='itemsPerPage']")
        if sel.count():
            try:
                if sel.first.input_value() != sel.first.locator("option", has_text="100").get_attribute("value"):
                    sel.first.select_option(label="100", timeout=5000)
                    pg.wait_for_timeout(2500)
            except Exception:
                pass
        ultima = fr.locator("a[ng-click=\"goToPage('max')\"]").locator("visible=true").first
        if ultima.count():
            _clicar(pg, ultima)
            pg.wait_for_timeout(2000)
        for _pagina in range(20):
            linhas = fr.locator("div.wj-row[role=row]", has_text=alvo)
            if linhas.count() and not os.path.exists(os.path.join(evid or "", "fig07.png")):
                try:
                    linhas.first.scroll_into_view_if_needed(timeout=5000)
                    linhas.first.click(timeout=5000)
                except Exception:
                    pass
                shot(pg, evid, "fig07", recorte=area_taxone(pg))
            for i in range(linhas.count()):
                nome = linhas.nth(i).locator("div[role=gridcell]").first.inner_text().strip().split("\\")[-1]
                tipo = "utilities" if "Utilities" in nome else "fiscais"
                if tipo in baixados:
                    continue
                icone = linhas.nth(i).locator("em.bento-icon-file-download")
                icone.scroll_into_view_if_needed()
                _log(log, f"Baixando {nome} (arquivos grandes podem levar alguns minutos)...")
                d = None
                try:
                    with pg.expect_download(timeout=900000) as dl:
                        _clicar(pg, icone)
                    d = dl.value
                except Exception:
                    _log(log, f"Download de {nome} não iniciou em 15 minutos.")
                if not d:
                    continue
                tipo_real = "utilities" if "Utilities" in d.suggested_filename else "fiscais"
                caminho = os.path.join(destino_dir, d.suggested_filename)
                d.save_as(caminho)
                baixados[tipo_real] = caminho
                _log(log, f"Baixado: {d.suggested_filename}")
            if len(baixados) >= 2:
                break
            ant = fr.locator("li.paginate_button.previous").locator("visible=true").first
            if not ant.count() or "disabled" in (ant.get_attribute("class") or ""):
                break
            _clicar(pg, ant.locator("a"))
            pg.wait_for_timeout(2000)
        if len(baixados) >= 2 or (baixados and tentativa >= 2):
            break
        _log(log, f"Arquivos ainda não disponíveis na transferência, aguardando... ({tentativa + 1}/30)")
        pg.wait_for_timeout(10000)
    if not baixados:
        raise ErroRobo("Os arquivos do processo não apareceram na Transferência de arquivos.")
    passo(pg, "Download concluído: " + ", ".join(os.path.basename(c) for c in baixados.values()))

    resultado = {"processo": proc_id}
    for tipo, caminho in baixados.items():
        if caminho.lower().endswith(".zip"):
            with zipfile.ZipFile(caminho) as zf:
                for n in zf.namelist():
                    zf.extract(n, destino_dir)
                    resultado[tipo] = os.path.join(destino_dir, n)
        else:
            resultado[tipo] = caminho
    return resultado


def gerar_relatorio(usuario, senha, empresa, periodo, destino_dir, estabelecimento="[ Todos ]",
                    origem="Todas", empresas=None, log=None, headless=True, timeout_proc=1800, evid_dir=None,
                    ambiente="QA", tela_real=False, acesso=None):
    definir_ambiente(ambiente)
    definir_evidencias(evid_dir)
    definir_tela_real(tela_real)
    definir_acesso(acesso, usuario)
    if not re.fullmatch(r"\d{2}/\d{4}", periodo or ""):
        raise ErroRobo("Período deve estar no formato MM/AAAA.")
    empresas = empresas or [empresa]
    os.makedirs(destino_dir, exist_ok=True)
    with sync_playwright() as p:
        b = abrir_navegador(p, headless)
        ctx = contexto(b, 1600, 900)
        pg = ctx.new_page()
        pg.on("dialog", lambda d: d.accept())
        try:
            pg = _login(pg, usuario, senha, log)
            novo = sem_janela(p, b, ctx, log, 1600, 900)
            if novo:
                b, ctx, pg = novo
            pg, fr = _abrir_taxone(pg, log)
            amb = info_ambiente(pg)
            for tentativa in range(3):
                try:
                    amb["empresa_nome"] = _selecionar_contexto(pg, fr, empresa, estabelecimento, log, evid_dir)
                    break
                except ErroRobo as e:
                    if "lista vazia" not in str(e) or tentativa == 2:
                        raise
                    pg, fr = reabrir_taxone(pg, log)
            _abrir_relatorio(pg, fr, log, evid_dir)

            _aba_processos(pg, fr)
            existentes = set(_ids_processos(fr))
            fr.locator("[id='safdwcm4:w_lib_proc_rel_conf_docs_rttabpage_parametros']").click()
            pg.wait_for_timeout(2000)

            _preencher_parametros(pg, fr, periodo, origem, empresas, log)
            shot(pg, evid_dir, "fig03", recorte=area_taxone(pg))
            _log(log, "Executando o relatório...")
            fr.locator("[id='d_lib_proc_par_header:pb_executar']").click()
            msg = _fechar_modal(pg, fr, "Relatório executado – confirmação de execução agendada e iniciada")
            if msg:
                _log(log, "TAX ONE: " + msg.replace("\n", " "))
            if msg and not re.search(r"agendad|iniciad", msg, re.I):
                raise ErroRobo("O TAX ONE não aceitou a execução: " + msg)

            _aba_processos(pg, fr)
            _log(log, "Aguardando o processamento...")
            t0 = time.time()
            proc_id, idx = None, None
            registrou_andamento = False
            while time.time() - t0 < timeout_proc:
                _listar(pg, fr)
                ids = _ids_processos(fr)
                novos = [i for i in ids if i not in existentes]
                if novos:
                    proc_id = max(novos)
                    idx = ids.index(proc_id)
                    situacao = fr.locator("input[id='d_lib_proc_processos:compute_1']").nth(idx).input_value().upper()
                    if "ENCERRADO" in situacao:
                        shot(pg, evid_dir, "fig04", recorte=area_taxone(pg))
                        break
                    if "ERRO" in situacao or "CANCEL" in situacao:
                        raise ErroRobo(f"Processo {proc_id} terminou com erro no TAX ONE.")
                    _log(log, f"Processo {proc_id} em andamento...")
                    if not registrou_andamento:
                        passo(pg, f"Aba Processos – processo {proc_id} em andamento")
                        registrou_andamento = True
                pg.wait_for_timeout(10000)
            else:
                raise ErroRobo("Tempo esgotado aguardando o processo terminar.")

            res = _baixar_arquivos(pg, fr, idx, proc_id, destino_dir, log, evid_dir)
            res["ambiente"] = amb
            return res
        except ErroRobo:
            raise
        except Exception as ex:
            registrar_falha(pg, destino_dir, log)
            raise ErroRobo(f"Falha na automação: {resumo_erro(ex)}")
        finally:
            encerrar(b)


if __name__ == "__main__":
    import sys
    destino = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.environ.get("TEMP", "."), "txdev", "out")
    print(gerar_relatorio(os.environ["TAXONE_TEST_USER"], os.environ["TAXONE_TEST_PASSWORD"],
                          sys.argv[1], sys.argv[2], destino))
